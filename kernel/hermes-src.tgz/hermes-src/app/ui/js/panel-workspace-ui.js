/* One shared workspace store. Profiles remain global; experts are scoped to a conversation. */
(function(){
'use strict';
var state={folders:[],sessions:{},favorites:[],identity:{user_name:'Vector',user_avatar:'👤',assistant_name:'Hermes',assistant_avatar:'🤖'},voice:{engine:'windows',fallback:true}};
/* 头像/名称的唯一来源（2026-11-19）：其他模块（讨论页等）改头像后要立刻跟着变，
 * 一律通过这个 getter 读当前身份，不要各自缓存一份 avatar 字符串。 */
window.pwLiveIdentity=function(){return state.identity||{};};
var _pwApi=null,ready,searchTimer,searchSeq=0,searchRows=[],expertList=[],speechJob=0,speechAudio=null,speechAbort=null,speechUrl=null;
var E=escapeHtml;
async function request(path,method,body){var r=await api('/api/workspace-ui'+path,method||'GET',body);if(r.error||r.ok===false)throw Error(r.error||'操作失败');return r;}
async function reload(){var next=await request('');if(!next.sessions||!Array.isArray(next.folders))throw Error('会话工作区数据未就绪，请刷新重试');state=next;renderRail();return state;}
/* 对外只暴露两个只读入口（2026-11-16）：
   state 与 reload 都在本 IIFE 内部，外部文件（tabs.js 的会话分流、
   new-dialog.js 创建后刷新）拿不到。只放查询和刷新，不放整份 state——
   避免别处直接改写导致渲染不同步。 */
window.pwSessionType=function(sid){var ss=state.sessions||{};if(!ss[sid])return null;return ss[sid].type||'chat';};
window.pwReload=reload;
/* 写入口（2026-11-19）：new-dialog.js 建完会话要把归类写进 workspace，原来它直接调
   request() —— 那是本 IIFE 的私有函数，跨文件根本调不到，归类就一直静默丢失。
   这里把同一套封装（统一前缀 + 统一错误语义）放出来，别再让外部自己拼 URL。 */
window.pwRequest=request;
function modal(title,body,foot){
  /* 适配器：唯一实现是 core/ui-kit.js 的 UI.modal。
     id='pwOverlay' 和 .pw-modal 类名都保留——close() 靠 id 定位，CSS 靠类名。*/
  if(close()===false)throw Error('声音设置正在保存，请稍候');
  var opener=document.activeElement;
  _pwApi=window.ui.modal({title:title,bodyHTML:body,footerHTML:foot,
    overlayClass:'modal-overlay',className:'modal pw-modal',id:'pwOverlay',
    onClose:function(){_pwApi=null;}});
  var d=_pwApi.backdropEl;
  d._pwOpener=opener;
  return d;
}
// 名称/标题类输入框：Enter = 点主按钮（中文输入法组合中的 Enter 不算，否则选词就误提交）。
// 2026-11-19：会话名称面板先加，随后统一到新建会话/文件夹/房间/资料。
function enterSubmits(d,inputId,btnId){
  var i=d.querySelector('#'+inputId),b=d.querySelector('#'+btnId);
  if(!i||!b)return;
  i.addEventListener('keydown',function(ev){
    if(ev.key==='Enter'&&!ev.isComposing&&ev.keyCode!==229){ev.preventDefault();b.click();}
  });
}
function close(){
  clearTimeout(searchTimer);searchSeq++;
  var d=document.getElementById('pwOverlay');
  if(!d)return;
  if(d._voiceSaving)return false;
  if(d._speechAbort)d._speechAbort.abort();
  var a=d.querySelector('audio');
  if(a){a.pause();if(a.src)URL.revokeObjectURL(a.src);}
  if(_pwApi)_pwApi.close();else d.remove();
}
function fail(e){toast(e.message||String(e));}
function field(label,id,value,type){return '<div class="field"><label for="'+id+'">'+E(label)+'</label><input id="'+id+'" type="'+(type||'text')+'" value="'+E(value||'')+'"></div>';}
function folderPath(id){var names=[],seen=new Set();while(id&&!seen.has(id)){seen.add(id);var f=state.folders.find(x=>x.id===id);if(!f)break;names.unshift(f.name);id=f.parent_id;}return names.join(' / ');}
function folderOptions(value){return '<option value="">未分类</option>'+state.folders.map(f=>'<option value="'+E(f.id)+'"'+(f.id===value?' selected':'')+'>'+E(folderPath(f.id))+'</option>').join('');}
window.pwFolderOptions=folderOptions;   /* 给 index.html 的新建会话弹窗复用（同一份文件夹数据源，别另造一套） */
window.pwFolders=function(){return (state.folders||[]).slice();};  /* 工作区选择器要列归类树，同一份数据 */
window.pwFolderPath=folderPath;
function activeExpert(){return (state.sessions[currentSession]||{}).expert||null;}
window.pwSessionContext=async function(sid){await ready;const meta=state.sessions[sid]||{},e=meta.expert;return {expert:e||null,plan:meta.plan||null,identity:meta.plan?{sender:meta.plan.name,sender_avatar:'🧭',sender_kind:'coordinator'}:e?{sender:e.name,sender_avatar:e.emoji,sender_kind:'expert'}:{sender:state.identity.assistant_name,sender_avatar:state.identity.assistant_avatar,sender_kind:'default'},user_identity:{sender:state.identity.user_name,sender_avatar:state.identity.user_avatar,sender_kind:'user'}};};
function avatarShapeClass(){return state.identity?.avatar_shape==='circle'?' circle':'';}
function avatarHTML(value,shape){shape=shape||state.identity?.avatar_shape;var cls='pw-avatar-image'+(shape==='circle'?' circle':'');
 var v=String(value==null?'':value);
 if(/^\/api\/workspace-ui\/avatars\/[a-f0-9]{64}\.(png|jpg|gif|webp)$/.test(v))return '<img class="'+cls+'" src="'+E(apiUrl(v))+'" alt="" loading="lazy">';
 // 外链头像：浏览器直接取远端图；referrerpolicy 不把面板地址带给图床，图片挂了退化成图标
 if(/^https?:\/\//i.test(v))return '<img class="'+cls+'" src="'+E(v)+'" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.outerHTML=\'🖼️\'">';
 return E(v||'🤖');}
function updateComposerIdentity(){var e=activeExpert(),plan=(state.sessions[currentSession]||{}).plan;var planBar=document.getElementById('sessionPlanBar');if(plan&&!planBar){planBar=document.createElement('div');planBar.id='sessionPlanBar';planBar.className='selected-expert-bar';document.getElementById('chatComposer')?.prepend(planBar);}if(planBar){planBar.hidden=!plan;if(plan){planBar.replaceChildren();var text=document.createElement('span'),details=document.createElement('button'),clear=document.createElement('button');text.textContent='本会话方案：'+plan.name;details.textContent='查看快照';details.onclick=function(){var d=modal('会话任务方案','<pre id="sessionPlanContents" style="white-space:pre-wrap;overflow-wrap:anywhere"></pre>');d.querySelector('pre').textContent=plan.name+'\n'+(plan.description||'')+'\n\n'+(plan.kind==='team'?(plan.members||[]).map(m=>(m.name||m.id)+'\n'+m.prompt).join('\n\n'):(plan.steps||[]).map((step,i)=>'步骤 '+(i+1)+' · '+step.id+'\n职责：'+step.expert+'\n依赖：'+((step.depends_on||[]).join('、')||'无')+'\n'+step.task).join('\n\n'));};clear.textContent='结束方案';clear.onclick=async function(){try{await request('/session','PUT',{id:currentSession,clear_plan:true});await reload();toast('后续消息恢复普通会话；已排队任务保留快照');}catch(error){fail(error);}};planBar.append(text,details,clear);}}var button=document.getElementById('btnExpert');if(button){var btnTip='本会话专家：'+(e?e.name:'默认助手');button.setAttribute('data-tip',btnTip);button.removeAttribute('title');/* 保持 HTML 的 openMini(this,'expert') 吸附层，工具栏六个按钮全走同一套弹层 *//* 按钮保持纯图标，专家名只进 hover 提示，避免工具栏出现带字按钮 */
button.querySelectorAll('.expert-label').forEach(function(n){n.remove();});button.setAttribute('aria-label',btnTip);if(!button.querySelector('svg'))button.insertAdjacentHTML('afterbegin','<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>');}var bar=document.getElementById('selectedExpertBar');if(bar){bar.style.display='none';bar.innerHTML='';}}
var PW_FOLDER_ICO='<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false"><path d="M2.6 6.4A2.4 2.4 0 0 1 5 4h3.7c.64 0 1.25.25 1.7.7L11.9 6.1H19a2.4 2.4 0 0 1 2.4 2.4v9.1A2.4 2.4 0 0 1 19 20H5a2.4 2.4 0 0 1-2.4-2.4z"/></svg>';
window.pwRailHTML=function(){
 var ex=activeExpert(),identity=state.identity;
 updateComposerIdentity();var html='';
 function item(s){var streaming=!!_tabStreaming[s.id];
 /* 2026-11-13：圆点只表示状态——needs_input(等 clarify) > running(正在跑) > interrupted(上轮中断/失败) > idle。
   _tabStreaming 是本页内存里的实时态，s.state 是服务端落盘态（刷新后仍然准），两者取先到的那个。 */
 var dst=(s.needs_input||s.state==='needs_input')?'needs_input':((streaming||s.running)?'running':(s.state==='interrupted'?'interrupted':'idle')),
 title=s.title&&s.title!=='New Chat'?s.title:'新会话',id=E(s.id),
 meta=fmtDateTime(s.updated_at)+(s.message_count?' · '+s.message_count+' 条':'')+(s.queued_count>0?' · 排队 '+s.queued_count:''),
 /* 画板会话单独标记（2026-11-16 用户需求）：左树一眼能分辨，点进去就是画板。
    类型存在 workspace.sessions[sid].type，跟聊天会话同一份数据，没有第二套体系。 */
 isCv=((state.sessions[s.id]||{}).type==='canvas'),
 cvTag=isCv?'<span class="si-type" title="画板会话" aria-label="画板会话"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg></span>':'';
 return '<div class="session-item '+(s.id===currentSession?'active ':'')+(dst==='running'?'streaming ':'')+(isCv?'is-canvas ':'')+'" data-sid="'+id+'" data-type="'+(isCv?'canvas':'chat')+'"><button class="session-open" type="button" onclick="railSessionClick(\''+id+'\',event)" title="双击编辑名称与归类" ondblclick="renameSession(\''+id+'\',event)" aria-current="'+(s.id===currentSession?'page':'false')+'"><span class="dot" data-state="'+dst+'" aria-label="'+({idle:'空闲',running:'正在回复',needs_input:'等你决定',interrupted:'上轮中断'}[dst])+'"></span><span class="si-body"><span class="title">'+cvTag+'<span class="t-txt">'+E(title)+'</span><i class="si-unread" hidden></i></span><span class="meta">'+E(meta)+'</span></span></button><button class="del" type="button" aria-label="归档会话：'+E(title)+'" title="归档会话" onclick="delSession(\''+id+'\',event)">×</button></div>';}
 function sessions(id){return _sessions.filter(s=>((state.sessions[s.id]||{}).folder_id||'')===id).map(item).join('');}
 function tree(parent,seen,d){d=d||0;return state.folders.filter(f=>(f.parent_id||'')===parent&&!seen.has(f.id)).map(f=>{var next=new Set(seen);next.add(f.id);return PwTree.node({key:'folder:'+f.id,depth:d,icon:PW_FOLDER_ICO,label:f.name,body:tree(f.id,next,d+1)+sessions(f.id),acts:'<button type="button" aria-label="编辑文件夹：'+E(f.name)+'" title="编辑文件夹" onclick="pwFolder(\''+f.id+'\')">⋯</button>'+'<button type="button" aria-label="新建子文件夹：'+E(f.name)+'" title="新建子文件夹" onclick="pwFolder(null,\''+f.id+'\')">＋</button>'});}).join('');}
 html+=tree('',new Set());html+=PwTree.node({key:'folder:none',icon:'🗂',label:'未分类',body:sessions(''),def:true}); 
 // An externally removed folder must not hide its conversations.
 html+=_sessions.filter(s=>{var id=(state.sessions[s.id]||{}).folder_id;return id&&!state.folders.some(f=>f.id===id);}).map(item).join('');
 // 已归档会话：入口已上移到 rail-head（新建文件夹图标左侧，只留图标），列表末尾不再占一行
 return html;
};
window.pwArchivedSessions=async function(){
 try{
  var out=await api('/api/sessions/archived','GET'),rows=(out&&out.sessions)||[];
  /* 2026-11-15：压缩掉的原文也归这个归档区管（同一个 chat/compressed 目录树、
     同一个弹窗、同一条彻底删除），所以这里给一个直达入口，不再单开一个归档系统。 */
  var compRows=[];
  try{var comp=await api('/api/sessions/compressed','GET');compRows=(comp&&comp.sessions)||[];}catch(e){}
  var compBatches=compRows.reduce(function(n,s){return n+((s.batches||[]).length);},0);
  var compRemoved=compRows.reduce(function(n,s){return n+(s.total_removed||0);},0);
  var compBar=compRows.length
    ?'<div class="pw-arch-compressed"><div class="pw-arch-compressed-txt">压缩原文 <b>'+compBatches+'</b> 批 · '
      +compRows.length+' 个会话 · 累计压掉 '+compRemoved+' 条<em>压缩不会删你的话，只是把早段换成了摘要，原文都在这儿</em></div>'
      +'<button type="button" class="btn" data-compressed>查看 / 彻底删除</button></div>'
    :'<div class="pw-arch-compressed is-empty"><div class="pw-arch-compressed-txt">压缩原文<em>还没有会话被压缩过</em></div></div>';
  var body=compBar+(rows.length?'<div class="pw-archived">'+rows.map(function(s){
    return '<div class="pw-archived-row pw-arch-pick">'
      +'<input type="checkbox" class="pw-arch-cb" data-id="'+E(s.id)+'" aria-label="选择该会话">'
      +'<div class="pw-archived-main"><span class="pw-archived-title">'+E(s.title||'新会话')+'</span><span class="pw-archived-meta">'+E(fmtDateTime(s.updated_at))+(s.message_count?' · '+s.message_count+' 条消息':' · 0 条消息')+'</span></div>'
      +'<button type="button" class="btn pw-archived-act" data-restore="'+E(s.id)+'">恢复</button></div>';
   }).join('')+'</div>':'<div class="pw-hint">没有已归档会话。</div>');
  var foot=rows.length
    ?'<label class="pw-arch-all"><input type="checkbox" id="pwArchAll">全选</label>'
     +'<button type="button" class="btn" data-dismiss>关闭</button>'
     +'<button type="button" class="btn danger" id="pwArchDel" disabled>彻底删除</button>'
    :'<button type="button" class="btn" data-dismiss>关闭</button>';
  var d=modal('已归档会话',body,foot);
  var delBtn=d.querySelector('#pwArchDel'),allCb=d.querySelector('#pwArchAll'),dismiss=d.querySelector('[data-dismiss]');
  var cbs=Array.prototype.slice.call(d.querySelectorAll('.pw-arch-cb'));
  function picked(){return cbs.filter(function(c){return c.checked;});}
  function sync(){
    var n=picked().length;
    cbs.forEach(function(c){var r=c.closest('.pw-archived-row');if(r)r.classList.toggle('is-picked',c.checked);});
    if(delBtn){delBtn.disabled=!n;delBtn.textContent=n?'彻底删除 ('+n+')':'彻底删除';}
    if(allCb){allCb.checked=n>0&&n===cbs.length;allCb.indeterminate=n>0&&n<cbs.length;}
  }
  cbs.forEach(function(c){c.onchange=sync;});
  if(allCb)allCb.onchange=function(){cbs.forEach(function(c){c.checked=allCb.checked;});sync();};
  if(dismiss)dismiss.onclick=function(){close();};
  var compBtn=d.querySelector('[data-compressed]');
  if(compBtn)compBtn.onclick=function(){close();if(window.openCompressArchive)window.openCompressArchive();};
  d.querySelectorAll('[data-restore]').forEach(function(btn){btn.onclick=async function(){
    btn.disabled=true;
    try{var r=await api('/api/sessions/'+encodeURIComponent(btn.dataset.restore)+'/restore','POST',{});if(!r.ok)throw Error(r.error||'恢复失败');await loadSessions();close();openTab(btn.dataset.restore);toast('会话已恢复');}
    catch(e){btn.disabled=false;fail(e);}
  };});
  if(delBtn)delBtn.onclick=async function(){
    var ids=picked().map(function(c){return c.dataset.id;});
    if(!ids.length)return;
    var msg=ids.length===1?'彻底删除这个会话？聊天记录和会话文件（含表情）会一并删除，不能恢复。':('彻底删除选中的 '+ids.length+' 个会话？聊天记录和会话文件（含表情）会一并删除，不能恢复。');
    if(!(await ui.confirm(msg,{danger:true})))return;
    var old=delBtn.textContent;delBtn.disabled=true;delBtn.textContent='删除中…';
    try{
      var r=await api('/api/sessions/archived/purge','POST',{ids:ids});
      if(!r.purged)throw Error(r.error||'删除失败');
      await loadSessions();close();await window.pwArchivedSessions();
      toast(r.failed?('已彻底删除 '+r.purged+' 个，'+r.failed+' 个失败'):('已彻底删除 '+r.purged+' 个会话'));
    }catch(e){delBtn.disabled=false;delBtn.textContent=old;fail(e);}
  };
  sync();
 }catch(e){fail(e);}
};
window.pwToggleFolder=function(id){var btn=document.querySelector('.pw-tree-node[data-tree-key="folder:'+id+'"] > .pw-tree-head > .pw-tree-toggle');if(btn)PwTree.toggle(btn);}; 
window.pwNewMenu=function(){var d=modal('新建','<div class="pw-row"><button class="btn primary" id="pwNewChat">＋ 新会话</button><button class="btn" id="pwNewFolder">＋ 文件夹</button></div>');d.querySelector('#pwNewChat').onclick=function(){close();setTimeout(function(){if(window.openNewSessionModal)openNewSessionModal();},60);};d.querySelector('#pwNewFolder').onclick=function(){pwFolder();};};
window.pwPersonality=async function(value){try{await ready;if(!currentSession)throw Error('请先创建或打开会话');const list=(await request('/personalities')).personalities;if(value){const choice=list.find(p=>p.id===value||p.name===value);if(!choice)throw Error('可用表达风格：'+list.map(p=>p.id+'（'+p.name+'）').join('、'));await request('/session','PUT',{id:currentSession,personality:choice.id});await reload();toast('后续消息采用'+choice.name);return true;}const selected=state.sessions[currentSession]?.personality||'default',d=modal('表达风格','<p class="pw-hint">只调整当前会话的表达方式，保留 SOUL 与专家职责。已排队消息保留发送时的设定。</p><div class="field"><label for="pwPersonality">风格</label><select id="pwPersonality">'+list.map(p=>'<option value="'+p.id+'"'+(p.id===selected?' selected':'')+'>'+E(p.name)+'</option>').join('')+'</select></div><p id="pwPersonalityFeedback" class="maintenance-feedback" role="status" aria-live="polite"></p>','<button class="btn primary" id="pwSavePersonality">保存</button>');d.querySelector('#pwSavePersonality').onclick=async function(){const save=this,status=d.querySelector('#pwPersonalityFeedback');save.disabled=true;status.textContent='正在保存本会话表达风格…';try{await pwPersonality(d.querySelector('#pwPersonality').value);close();}catch(error){status.textContent=error.message||'表达风格保存失败';}finally{if(d.isConnected)save.disabled=false;}};return d;}catch(e){if(value)throw e;fail(e);}};
function inputAction(title,label,initial,callback){const d=modal(title,field(label,'pwActionInput',initial||''),'<button class="btn primary" id="pwActionConfirm">确定</button>');d.querySelector('#pwActionConfirm').onclick=async function(){const text=d.querySelector('#pwActionInput').value.trim();if(!text){fail(Error('请输入内容'));return;}this.disabled=true;try{await callback(text);close();}catch(e){fail(e);}finally{this.disabled=false;}};}
window.handleSlashCommand=async function(raw){const match=String(raw||'').trim().match(/^\/(\S+)(?:\s+([\s\S]*))?$/);if(!match){sendRaw(raw);return;}const name=match[1].toLowerCase(),arg=(match[2]||'').trim();try{
 if(name==='new'){openNewSessionModal(arg);return;}   /* 2026-11-24：并到同一个新建弹窗 */
 if(name==='stop'||name==='interrupt'){await chatStop();return;}
 if(name==='queue'){if(window.slashRun&&slashRun.queue){slashRun.queue(arg);return;}if(!arg)throw Error('用法：/queue [all]　不带参数看当前会话队列，带 all 看全部');return;}
 if(name==='steer'){if(window.slashRun&&slashRun.steer){slashRun.steer(arg);return;}throw Error('用法：/steer <补充要求>');}
 if(name==='goal'){if(window.slashRun&&slashRun.goal){slashRun.goal(arg);return;}throw Error('用法：/goal <目标>');} if(name==='compress'){if(!currentSession)throw Error('请先打开会话');if(!window.runCompress)throw Error('压缩模块未加载，请刷新页面');await window.runCompress(arg,currentSession);return;}
 if(name==='personality'){await pwPersonality(arg);return;}
 if(name==='title'){if(!currentSession)throw Error('请先打开会话');if(!arg){renameSession(currentSession);return;}const r=await api('/api/sessions/rename','POST',{id:currentSession,title:arg});if(!r.ok)throw Error(r.error);await loadSessions();updateHeader();return;}
 if(name==='plan'){const run=text=>sendRaw('请先为下面的请求编写可审阅的执行计划，说明步骤、依赖、风险与验证方式；本轮先给计划。\n\n'+text);if(arg)run(arg);else inputAction('编写计划','你希望规划什么','',run);return;}
 if(name==='model'||name==='provider'){var _mb=document.getElementById('btnModel');if(_mb&&window.openMini){window.openMini(_mb,'model');return;}switchPage('models');return;}
 if(name==='usage'||name==='insights'){switchPage('usage');return;}
 if(name==='status'){if(window.slashRun&&slashRun.status){slashRun.status(arg);return;}switchPage('overview');return;}
 if(name==='help'){modal('命令表','<p><b>会话</b>：/new、/title、/stop（/interrupt 同义）、/queue、/steer、/goal、/compress</p><p><b>计划</b>：/plan</p><p><b>设置</b>：/model（就地选）、/personality</p><p><b>查看</b>：/usage、/status、/help</p><p class="pw-hint">输入 / 会弹补全列表：↑↓ 选、Enter 或 Tab 确认、Esc 关。带参数的命令选中后变成标签，只需在输入框打参数。</p><p class="pw-hint">/steer 中止当前回合并按你的补充重发；/goal 目标存本地，之后每轮自动带上；/compress 真压缩上下文（早段消息换摘要、保留最近一批，原会话先备份；加「预览」只看不写）。</p>');return;}
 throw Error('不认识 /'+name+'。输入 / 看全部命令，或 /help。原文已保留在输入框。');
 }catch(e){const ta=document.getElementById('chatInput');ta.value=raw;autoResize(ta);saveDraft(currentSession);fail(e);}};
window.handlePanelSlashCommand=window.handleSlashCommand;
window.pickQuick=function(command){closeMini();handleSlashCommand(command);};
PV.quickGroups=[{title:'会话',commands:[{ico:'＋',title:'新建会话',cmd:'/new',sub:'填写名称与归类'},{ico:'✎',title:'名称与归类',cmd:'/title',sub:'编辑当前会话'},{ico:'⇲',title:'压缩上下文',cmd:'/compress',sub:'早段换成摘要、保留最近一批'},{ico:'■',title:'停止执行',cmd:'/stop',sub:'停止当前会话正在执行的一轮'}]},{title:'回答方式',commands:[{ico:'◌',title:'表达风格',cmd:'/personality',sub:'简洁、技术、教学或创意'},{ico:'☷',title:'编写计划',cmd:'/plan',sub:'填写目标，先获得执行计划'}]},{title:'查看',commands:[{ico:'◈',title:'模型服务',cmd:'/model',sub:'服务、模型与辅助任务'},{ico:'↗',title:'实际用量',cmd:'/usage',sub:'查看记录中的使用情况'},{ico:'?',title:'操作帮助',cmd:'/help',sub:'面板支持的快捷操作'}]}];
window.pwFolder=function(id,parent){var f=state.folders.find(f=>f.id===id),d=modal(f?'编辑文件夹':'新建文件夹',field('名称','pwFolderName',f?f.name:'')+'<div class="field"><label>上级文件夹</label><select id="pwFolderParent">'+folderOptions(f?f.parent_id:parent)+'</select></div>',(f?'<button class="btn" id="pwDeleteFolder">删除文件夹</button>':'')+'<button class="btn primary" id="pwSaveFolder">保存</button>');d.querySelector('#pwFolderParent option').textContent='顶层';enterSubmits(d,'pwFolderName','pwSaveFolder');d.querySelector('#pwSaveFolder').onclick=async function(){try{await request('/folders',f?'PUT':'POST',{id:id,name:d.querySelector('#pwFolderName').value,parent_id:d.querySelector('#pwFolderParent').value});await reload();close();}catch(e){fail(e);}};if(f)d.querySelector('#pwDeleteFolder').onclick=async function(){if(!(await ui.confirm('删除文件夹后，会话和子文件夹移到上一级，内容会保留。')))return;try{await request('/folders','DELETE',{id:id});await reload();close();}catch(e){fail(e);}};};
window.__pwRenameSession=function(sid,e){if(e)e.stopPropagation();var s=_sessions.find(x=>x.id===sid);if(!s)return;var meta=state.sessions[sid]||{};var d=modal('会话名称与归类',field('会话名称','pwSessionTitle',s.title==='New Chat'?'':s.title)+'<div class="field"><label>文件夹</label><select id="pwSessionFolder">'+folderOptions(meta.folder_id)+'</select></div>','<button class="btn primary" id="pwSaveSession">保存</button>');d.querySelector('#pwSaveSession').onclick=async function(){try{var title=d.querySelector('#pwSessionTitle').value.trim();if(!title)throw Error('请输入会话名称');var r=await api('/api/sessions/rename','POST',{id:sid,title:title});if(!r.ok)throw Error(r.error);await request('/session','PUT',{id:sid,folder_id:d.querySelector('#pwSessionFolder').value});s.title=r.title;await reload();renderSessionTabs();updateHeader();close();}catch(e){fail(e);}};enterSubmits(d,'pwSessionTitle','pwSaveSession');};
window.renameSession=window.__pwRenameSession;  /* 兼容旧调用；index.html 里的同名函数是转发器 */
function avatarField(label,id,value,shape){return '<div class="field pw-avatar-field"><label>'+E(label)+'</label><div class="pw-avatar-input"><span class="pw-avatar '+(shape==='circle'?'circle':'')+'" id="'+id+'Preview">'+avatarHTML(value,shape)+'</span><div class="pw-avatar-actions"><button type="button" class="btn pw-avatar-pick" data-pick="'+id+'">选择图片</button><span class="pw-avatar-tip">PNG/JPG/WebP/GIF<br>&gt;5 MB 自动压缩 · GIF 保动图</span></div><input type="file" id="'+id+'File" accept="image/png,image/jpeg,image/webp,image/gif" hidden><input type="hidden" id="'+id+'" value="'+E(value)+'"></div></div>';}
function bindAvatar(d,id){var _fi=d.querySelector('#'+id+'File');if(!_fi)return;
 function _apply(url){d.querySelector('#'+id).value=url;var _pv=d.querySelector('#'+id+'Preview');_pv.innerHTML=avatarHTML(url);var _ck=d.querySelector('[name="pwAvatarShape"]:checked');_pv.classList.toggle('circle',!!_ck&&_ck.value==='circle');}
 async function _upload(file){var form=new FormData();form.append('file',file,file.name||'avatar.png');var r=await fetch(apiUrl('/api/workspace-ui/avatars'),{method:'POST',headers:{'X-Monitor-Token':monitorToken||''},body:form});var out=await r.json();if(!r.ok)throw Error(out.error||'头像上传失败');_apply(out.url);}
 var _pb=d.querySelector('[data-pick="'+id+'"]');if(_pb)_pb.onclick=function(e){e.preventDefault();_fi.click();};
 _fi.onchange=async function(){var file=this.files[0];if(!file)return;try{
  /* accept 只是选择器的筛选提示，用户可以切到"所有文件"，所以这里必须硬拦类型 */
  if(!file.type||file.type.indexOf('image/')!==0)throw Error('只能上传图片文件（PNG / JPEG / WebP / GIF）');
  if(file.type==='image/gif'){
   /* GIF 绝不能过 canvas：createImageBitmap 只给首帧，画出来就是静态图。原样上传保动图 */
   if(file.size>6*1024*1024)throw Error('GIF 动图最大 6 MB（压缩会丢动画，请先裁小再传）');
   this.disabled=true;await _upload(file);
  }else{
   /* 非 GIF 一律居中裁方 + 缩到 256×256 PNG，>5 MB 的大图在这里被压到几十 KB，不再报错 */
   var bitmap=await createImageBitmap(file).catch(function(){throw Error('这张图片解不开，换一张或转成 PNG 再传');});
   var canvas=document.createElement('canvas');canvas.width=canvas.height=256;
   var ctx=canvas.getContext('2d'),side=Math.min(bitmap.width,bitmap.height);
   ctx.drawImage(bitmap,(bitmap.width-side)/2,(bitmap.height-side)/2,side,side,0,0,256,256);bitmap.close();
   var blob=await new Promise(function(resolve){canvas.toBlob(resolve,'image/png')});
   if(!blob)throw Error('图片压缩失败，换一张试试');
   this.disabled=true;await _upload(blob);
  }
  if(_pb){_pb.textContent='重新选择';}
  try{if(window.ui&&ui.toast)ui.toast('头像已上传，点保存生效');}catch(_){}
 }catch(e){fail(e);}finally{this.disabled=false;}};}
/* 头像设置：scope='me' 只给我的那半，'bot' 只给当前角色那半，不传则两栏都给。
   聊天里点头像就是按这个分流——点自己的头像不该看见"默认助手"的字段。 */
window.pwIdentity=function(scope){var i=state.identity,_s=scope||'all';var _me='<div class="pw-row">'+field('你的显示名称','pwUserName',i.user_name)+avatarField('你的头像','pwUserAvatar',i.user_avatar,i.avatar_shape)+'</div>';var _bot='<div class="pw-row">'+field('当前角色名称','pwAssistantName',i.assistant_name)+avatarField('当前角色头像','pwAssistantAvatar',i.assistant_avatar,i.avatar_shape)+'</div>';var _body=(_s==='bot')?_bot:(_s==='me')?_me:(_me+_bot);var _rd=(i.avatar_shape!=='circle');_body+='<div class="field pw-shape-field"><label>头像外形</label><div class="pw-shape-opts"><label class="pw-shape-opt'+(_rd?' is-on':'')+'"><input type="radio" name="pwAvatarShape" value="rounded"'+(_rd?' checked':'')+'><span class="pw-shape-glyph sq"></span><span class="pw-shape-name">圆角方形</span></label><label class="pw-shape-opt'+(_rd?'':' is-on')+'"><input type="radio" name="pwAvatarShape" value="circle"'+(_rd?'':' checked')+'><span class="pw-shape-glyph ci"></span><span class="pw-shape-name">圆形</span></label></div></div>';_body+='<p class="pw-hint">图片裁成方形并保留中心区域；GIF 动画保持原样。保存后当前会话的历史消息也会立刻换成新头像（专家消息保留各自的图标）；名称只影响之后发出的消息。</p>';var d=modal(_s==='me'?'我的资料':_s==='bot'?'当前角色':'名称与头像',_body,'<button class="btn primary" id="pwSaveIdentity">保存</button>');bindAvatar(d,'pwUserAvatar');bindAvatar(d,'pwAssistantAvatar');d.querySelectorAll('[name="pwAvatarShape"]').forEach(function(option){option.onchange=function(){if(!option.checked)return;d.querySelectorAll('.pw-shape-opt').forEach(function(o){o.classList.toggle('is-on',o.contains(option));});d.querySelectorAll('.pw-avatar-input .pw-avatar').forEach(function(preview){preview.classList.toggle('circle',option.value==='circle');preview.querySelector('img')?.classList.toggle('circle',option.value==='circle');});};});enterSubmits(d,'pwUserName','pwSaveIdentity');enterSubmits(d,'pwAssistantName','pwSaveIdentity');d.querySelector('#pwSaveIdentity').onclick=async function(){try{if(d.querySelector('input[type=file]:disabled'))throw Error('头像正在上传，请稍候');var patch={};var un=d.querySelector('#pwUserName'),ua=d.querySelector('#pwUserAvatar'),an=d.querySelector('#pwAssistantName'),aa=d.querySelector('#pwAssistantAvatar');if(un&&ua){patch.user_name=un.value;patch.user_avatar=ua.value;}if(an&&aa){patch.assistant_name=an.value;patch.assistant_avatar=aa.value;}patch.avatar_shape=d.querySelector('[name="pwAvatarShape"]:checked').value;await request('/preferences','PUT',{identity:patch});await reload();if(currentSession)loadSessionMessages(currentSession,false,true);close();}catch(e){fail(e);}};};
window.chatSenderName=function(){var e=activeExpert();return E(e?e.name:state.identity.assistant_name);};
window.chatUserName=function(){return E((state.identity||{}).user_name||'你');};
var oldWelcome=welcomeHTML;
window.welcomeHTML=function(){var e=activeExpert();if(!e)return oldWelcome();return '<div class="pw-welcome"><span class="pw-avatar'+avatarShapeClass()+'">'+avatarHTML(e.emoji)+'</span><h2>'+E(e.name)+'</h2><p>说说你要解决的问题、期望的结果和限制条件。</p><div class="pw-quick-prompts">'+(e.quick_prompts||[]).map((q,i)=>'<button class="btn" data-expert-question="'+i+'">'+E(q)+'</button>').join('')+'</div></div>';};
window.pwDecorateMsg=function(html,m){var d=document.createElement('div');d.innerHTML=html;var identity=state.identity||{},expert=activeExpert();/* 主身份消息的头像跟设置实时走（2026-11-12）：以前头像在发消息那一刻写死进 sender_avatar，改完头像后当前会话整屏历史还是旧图，看起来就是「改了不生效」。专家/协调者消息仍用自己的图标。 */var _k=m.sender_kind||'',_own=(m.role!=='user')&&(_k==='default'||(_k!=='expert'&&_k!=='coordinator'&&(!m.sender_avatar||m.sender===identity.assistant_name)));var name=m.sender||m.persona_name||(m.role==='user'?identity.user_name:expert?expert.name:identity.assistant_name)|| (m.role==='user'?'你':'Hermes'),avatar=(m.role==='user'?(identity.user_avatar||'👤'):(_own?(identity.assistant_avatar||'🤖'):(m.sender_avatar||(expert?expert.emoji:identity.assistant_avatar))))||(m.role==='user'?'👤':'🤖');if(d.querySelector('.cron-lead'))return d.innerHTML;var meta=d.querySelector('.msg-meta');if(meta)meta.textContent=name+' · '+fmtDateTime(m.ts||m.created_at||Date.now());var h=d.querySelector('.chat-sender');if(h){h.innerHTML='<span class="pw-avatar'+avatarShapeClass()+'">'+avatarHTML(avatar)+'</span><span>'+E(name)+'</span>';}if(d.firstElementChild&&m.request_id)d.firstElementChild.dataset.requestId=m.request_id;return d.innerHTML;};
window.pwDecorateLive=function(){document.querySelectorAll('#chatBody .chat-sender').forEach(h=>{if(h.querySelector('.pw-avatar')||h.closest('.cron-lead'))return;var user=h.closest('.msg.user'),e=activeExpert();h.innerHTML='<span class="pw-avatar'+avatarShapeClass()+'">'+avatarHTML(user?state.identity.user_avatar:e?e.emoji:state.identity.assistant_avatar)+'</span><span>'+E(user?state.identity.user_name:e?e.name:state.identity.assistant_name)+'</span>';});};
async function experts(){var r=await request('/experts?limit=400');expertList=r.experts;window.BUILTIN_EXPERTS_ARR=expertList;return expertList;}
function normalized(e){return {id:e.slug||e.id,name:e.name||e.label,emoji:_wfEmoji(e.emoji||e.icon),prompt:e.prompt||'',skills:e.skills||[]};}
async function bindExpert(e,newChat){await ready;if(newChat||!currentSession){saveDraft(currentSession);var s=await api('/api/sessions','POST',{});currentSession=s.id;_sessions.unshift(s);_openTabs.push(s.id);persistTabs();}await request('/session','PUT',{id:currentSession,expert_id:e?(e.id||e.slug):null});await reload();_selectedExpert=null;document.getElementById('chatComposer').hidden=false;_channelViewActive=false;renderSelectedExpertBar();renderSessionTabs();restoreDraft(currentSession);updateHeader();switchPage('chat');scrollChatToBottom();loadSessionMessages(currentSession);close();toast(e?'后续消息使用 '+(e.name||e.label):'后续消息使用默认助手');}
window.pwOpenRole=async function(){try{await experts();var d=modal('选择本会话角色','<p class="pw-hint">专家提供职责、方法和表达方式；共享当前环境的技能与工具，不切换全局 SOUL。已有消息保留原署名，选择只影响接下来的回复。</p><input id="pwRoleQuery" placeholder="搜索专家名称、专长…"><div class="pw-results" id="pwRoleList" style="margin-top:10px"></div>');function render(){var q=d.querySelector('#pwRoleQuery').value.toLowerCase();var list=expertList.filter(e=>((e.name||'')+' '+(e.desc||'')+' '+(e.scene||'')).toLowerCase().includes(q));var b=d.querySelector('#pwRoleList');b.innerHTML='<button class="pw-result" data-default="1">'+E(state.identity.assistant_avatar)+' '+E(state.identity.assistant_name)+'<small> · 默认角色</small></button>'+list.map((e,i)=>'<button class="pw-result" data-expert="'+i+'"><b>'+E(_wfEmoji(e.emoji))+' '+E(e.name)+'</b><p>'+E(e.desc||(e.prompt||'').slice(0,100))+'</p></button>').join('');b.querySelector('[data-default]').onclick=()=>bindExpert(null,false).catch(fail);b.querySelectorAll('[data-expert]').forEach(x=>x.onclick=()=>bindExpert(list[Number(x.dataset.expert)],false).catch(fail));}d.querySelector('#pwRoleQuery').oninput=render;render();}catch(e){fail(e);}};
window.pwExpertChat=async function(id){try{var e=(await request('/experts/'+encodeURIComponent(id))).expert;await bindExpert(e,true);}catch(e){fail(e);}};
window.pwStartRoleChat=async function(profile){try{await ready;if(!profile||!profile.id)throw Error('角色资料不可用，请刷新列表');saveDraft(currentSession);var s=await api('/api/sessions','POST',{});if(!s.id)throw Error(s.error||'创建会话失败');await request('/session','PUT',{id:s.id,expert:{id:profile.id,name:profile.name||profile.id,emoji:profile.emoji||'🤖',prompt:profile.prompt||'',quick_prompts:profile.quick_prompts||[],skills:[]}});_sessions.unshift(s);_openTabs.push(s.id);persistTabs();await reload();close();switchPage('chat');openTab(s.id);toast('已创建会话，角色设定按快照保存；全局环境未切换');}catch(error){fail(error);}};
window.pwProfileChatById=function(id){var profile=(_profiles||[]).find(function(item){return item.id===id;});if(!profile)throw Error('角色资料不可用，请刷新列表');return pwStartRoleChat(profile);};
window.pwExpertTemplateChat=function(id){return pwExpertChat(id);};
window.pwUseExpert=async function(id){var e=id?(await request('/experts/'+encodeURIComponent(id))).expert:null;await bindExpert(e,false);};
window.pwWorkspaceRefresh=reload;
window.pickItemExpert=function(id){closeMini();pwExpertChat(id);};window.useExpert=function(id){pwExpertChat(id);};
window.clearSelectedExpert=function(){bindExpert(null,false).catch(fail);};
window.openBuiltinExpertEditor=async function(id){try{
 const e=(await request('/experts/'+encodeURIComponent(id))).expert;
 const d=modal('专家设定 · '+e.name,field('名称','ee_name',e.name)+avatarField('头像','ee_emoji',e.emoji)+field('简介','ee_desc',e.desc)+'<div class="field"><label for="ee_prompt">专家职责与方法</label><textarea id="ee_prompt" rows="12"></textarea></div><div class="field"><label for="ee_quick">快速提问（每行一个）</label><textarea id="ee_quick" rows="4"></textarea></div><p class="pw-hint">保存后用于新选择的专家。已有会话、排队消息和讨论成员保留各自快照。技能与工具由环境提供。</p>','<button class="btn primary" id="ee_save">保存设定</button>');
 d.querySelector('#ee_prompt').value=e.prompt;d.querySelector('#ee_quick').value=(e.quick_prompts||[]).join('\n');bindAvatar(d,'ee_emoji');
 d.querySelector('#ee_save').onclick=async function(){this.disabled=true;try{if(d.querySelector('input[type=file]:disabled'))throw Error('头像正在上传');await request('/experts/'+encodeURIComponent(id),'PUT',{revision:e.revision,name:d.querySelector('#ee_name').value,emoji:d.querySelector('#ee_emoji').value,desc:d.querySelector('#ee_desc').value,prompt:d.querySelector('#ee_prompt').value,quick_prompts:d.querySelector('#ee_quick').value.split('\n')});close();await renderBuiltinExperts();toast('专家设定已保存');}catch(err){fail(err);}finally{this.disabled=false;}};
 }catch(e){fail(e);}};
window._allBuiltinExperts=function(){return expertList;};
window.renderExpertsPage=function(){renderMineExperts();renderBuiltinExperts();};
window.refreshExperts=async function(){await experts();await renderBuiltinExperts();await renderMineExperts();};
window.renderBuiltinExperts=async function(){const grid=document.getElementById('expBuiltinGrid');if(!grid)return;try{const list=await experts();_renderExpertList('builtin',list,{kind:'builtin',searchId:'expBuiltinSearch'});}catch(e){grid.innerHTML='<div class="empty-state">'+E(e.message)+'<button class="btn" onclick="renderBuiltinExperts()">重试</button></div>';}};
var oldCard=_expertCardHtml;
window._expertCardHtml=function(e,kind){if(kind!=='builtin')return oldCard(e,kind);var id=e.slug||e.id,fav=state.favorites.includes(id);return '<div class="exp-card"><div class="exp-card-head"><div class="exp-card-avatar">'+E(_wfEmoji(e.emoji))+'</div><div><div class="exp-card-title">'+E(e.name)+'</div><div class="exp-card-scene">'+E(e.scene||'通用')+'</div></div></div><div class="exp-card-desc">'+E(e.desc||(e.prompt||'').slice(0,140))+'</div><div class="pw-expert-action"><button class="btn sm primary" data-pw-chat="'+E(id)+'">开始对话</button><button class="btn sm" data-pw-room="'+E(id)+'">加入群聊</button><button class="btn sm" data-pw-fav="'+E(id)+'">'+(fav?'★ 已收藏':'☆ 收藏')+'</button><button class="btn sm" data-pw-edit="'+E(id)+'">查看设定</button></div></div>';};
window.renderMineExperts=function(){var grid=document.getElementById('expMineGrid');if(!grid)return;experts().then(list=>{var q=(document.getElementById('expMineSearch').value||'').toLowerCase();var fav=list.filter(e=>state.favorites.includes(e.slug||e.id)&&((e.name||'')+' '+(e.desc||'')).toLowerCase().includes(q));grid.innerHTML=fav.map(e=>_expertCardHtml(e,'builtin')).join('')||'<div class="empty-state">在内置专家中收藏常用角色，即可在这里快速开始对话或组建群聊。</div>';}).catch(fail);};
window.pwProfiles=function(){pwPersonality();};
window.filterRail=function(q){clearTimeout(searchTimer);if(!q.trim())return;searchTimer=setTimeout(()=>pwSearch(q),250);};
window.pwSearch=async function(q,offset){q=String(q||'').trim();var d=document.getElementById('pwOverlay');if(!d||!d.querySelector('#pwSearchQ')){d=modal('搜索所有会话','<input id="pwSearchQ" placeholder="搜索会话标题和消息内容"><div class="pw-hint" id="pwSearchStatus">搜索中…</div><div class="pw-results" id="pwResults"></div><button class="btn" id="pwSearchMore" hidden>更多结果</button>');d.querySelector('#pwSearchQ').oninput=function(){clearTimeout(searchTimer);searchTimer=setTimeout(()=>pwSearch(this.value),250);};}d.querySelector('#pwSearchQ').value=q;if(!q){searchSeq++;var zr=document.getElementById('pwResults');if(zr)zr.innerHTML='';var zs=document.getElementById('pwSearchStatus');if(zs)zs.textContent='输入关键词，搜索所有会话的标题和消息内容';try{d.querySelector('#pwSearchQ').focus();}catch(e){}return;}var seq=++searchSeq;try{var r=await request('/search?q='+encodeURIComponent(q)+'&offset='+(offset||0));if(seq!==searchSeq||!document.getElementById('pwResults'))return;if(!offset)searchRows=[];searchRows=searchRows.concat(r.results);var label={panel:'面板',channel:'渠道',room:'专家讨论'};function hi(t){var at=t.toLowerCase().indexOf(q.toLowerCase());return at<0?E(t):E(t.slice(0,at))+'<mark>'+E(t.slice(at,at+q.length))+'</mark>'+E(t.slice(at+q.length));}d.querySelector('#pwSearchStatus').textContent='找到 '+r.total+' 条结果'+(r.partial?' · 部分渠道检索超时，可缩小关键词重试':'');d.querySelector('#pwResults').innerHTML=searchRows.map((x,i)=>'<button class="pw-result" data-hit="'+i+'"><b>'+E(x.title)+'</b> <small>'+label[x.kind]+' · '+E(fmtDateTime(x.ts))+'</small><p>'+hi(x.snippet)+'</p></button>').join('')||'<p class="pw-hint">没有找到匹配内容。</p>';d.querySelectorAll('[data-hit]').forEach(b=>b.onclick=()=>jump(searchRows[Number(b.dataset.hit)]).catch(fail));var more=d.querySelector('#pwSearchMore');more.hidden=!r.has_more;more.onclick=()=>pwSearch(q,searchRows.length);}catch(e){if(d.querySelector('#pwSearchStatus'))d.querySelector('#pwSearchStatus').textContent=e.message;}};
var suppressLoad=false, jumpSeq=0;
var oldLoad=loadSessionMessages;
/* 参数必须原样转发（2026-11-20）：这个包装器以前只转发三个参数，把「只追加新消息」的
   appendOnly 吞掉了，结果轮询里每一次都退化成整片重绘 —— 图片全部重建、高度归零再撑开。 */
window.loadSessionMessages=function(sid,silent,keep,appendOnly){if(suppressLoad)return Promise.resolve();return oldLoad(sid,silent,keep,appendOnly);};
async function jump(hit){
 close();var seq=++jumpSeq;
 if(hit.kind==='panel'){
  _channelViewActive=false;var rb=document.getElementById('chReturnBtn');if(rb)rb.style.display='none';
  suppressLoad=true;try{switchPage('chat');openTab(hit.session_id);}finally{suppressLoad=false;}
  if(window.innerWidth<=768)closeRailDrawer();pauseChatFollow();_foldHoldUntil=Date.now()+600000;
  var s=await apiGet('/api/sessions/'+encodeURIComponent(hit.session_id));if(seq!==jumpSeq||currentSession!==hit.session_id)return;
  var body=document.getElementById('chatBody');body.innerHTML=(s.messages||[]).map(function(m,i){var d=document.createElement('div');d.innerHTML=msgHTML(m);var msg=d.firstElementChild;if(msg)msg.dataset.messageIndex=i;return d.innerHTML;}).join('');
  _chatHTML[currentSession]=body.innerHTML;var target=body.querySelector('[data-message-index="'+Math.max(0,hit.message_index)+'"]');
  if(target){target.classList.add('pw-hit');target.scrollIntoView({block:'center'});setTimeout(()=>target.classList.remove('pw-hit'),4500);}return;
 }
 if(hit.kind==='room'){
  if(window.panelJumpRoom){await window.panelJumpRoom(hit);return;}
  switchPage('rooms');await loadRoomsList();await selectRoom(hit.session_id);if(seq!==jumpSeq||currentRoom!==hit.session_id)return;
  var target=document.querySelectorAll('#roomMsgs > .msg, #roomMsgs > .rm')[Math.max(0,hit.message_index)];if(target){target.scrollIntoView({block:'center'});target.classList.add('pw-hit');setTimeout(()=>target.classList.remove('pw-hit'),4500);}return;
 }
 switchPage('chat');_channelViewActive=true;document.getElementById('chatComposer').hidden=true;pauseChatFollow();var data=await request('/channel-context?id='+encodeURIComponent(hit.session_id)+'&message='+hit.message_index);if(seq!==jumpSeq)return;
 var body=document.getElementById('chatBody');body.innerHTML='<div class="system-tip">'+E(hit.title)+' · 渠道会话搜索定位（只读，显示命中附近消息）</div>'+data.messages.map(function(m){var d=document.createElement('div');d.innerHTML=msgHTML({role:m.role,content:m.content,ts:m.timestamp*1000});if(d.firstElementChild)d.firstElementChild.dataset.channelMessage=m.id;return d.innerHTML;}).join('');
 var rb=document.getElementById('chReturnBtn');if(rb)rb.style.display='inline-flex';document.getElementById('chatTitle').textContent=hit.title;document.getElementById('chatSubtitle').textContent='渠道会话 · 搜索定位';
 var target=body.querySelector('[data-channel-message="'+hit.message_index+'"]');if(target){target.scrollIntoView({block:'center'});target.classList.add('pw-hit');}
}
window.pwRoom=async function(preselect){try{var list=await experts();var roomData=await api('/api/rooms','GET');var d=modal('组建专家群聊','<div class="field"><label>目标房间</label><select id="pwRoomTarget"><option value="">创建新房间</option>'+(roomData.rooms||[]).map(r=>'<option value="'+E(r.id)+'">加入：'+E(r.title)+'</option>').join('')+'</select></div>'+field('房间名称','pwRoomTitle','专家讨论')+'<div class="field"><label>房间默认模型</label><select id="pwRoomModel"><option value="">沿用当前默认模型</option>'+(_cfg.providers||[]).flatMap(p=>(p.models&&p.models.length?p.models:[p.model]).filter(Boolean).map(m=>{var id=typeof m==='string'?m:m.id||m.name;return '<option value="'+E(id)+'">'+E(id+' · '+(p.name||p.id||''))+'</option>';})).join('')+'</select></div>'+'<p class="pw-hint">每位成员使用独立会话，带自己的专家设定，共享同一环境的工具与技能。可以 @ 指定成员，也可以让主持人按任务组织接力。</p><input id="pwRoomQuery" placeholder="搜索所有专家"><div class="pw-check-list" id="pwRoomList" style="margin-top:10px"></div>','<button class="btn primary" id="pwRoomCreate">确认专家成员</button>');var selected=new Set(preselect?[preselect]:[]);function render(){var q=d.querySelector('#pwRoomQuery').value.toLowerCase();var box=d.querySelector('#pwRoomList');box.innerHTML=list.filter(e=>((e.name||'')+' '+(e.desc||'')).toLowerCase().includes(q)).map(e=>{var id=e.slug||e.id;return '<label><input type="checkbox" value="'+E(id)+'"'+(selected.has(id)?' checked':'')+'><span>'+E(_wfEmoji(e.emoji))+' '+E(e.name)+'</span></label>';}).join('');box.querySelectorAll('input').forEach(c=>c.onchange=()=>c.checked?selected.add(c.value):selected.delete(c.value));}d.querySelector('#pwRoomQuery').oninput=render;render();enterSubmits(d,'pwRoomTitle','pwRoomCreate');d.querySelector('#pwRoomCreate').onclick=async function(){try{if(!selected.size)throw Error('至少选择一位专家');if(selected.size>12)throw Error('一个房间最多选择12位专家');var chosen=await Promise.all(list.filter(e=>selected.has(e.slug||e.id)).map(e=>request('/experts/'+encodeURIComponent(e.slug||e.id)).then(r=>r.expert)));var members=chosen.map(e=>({key:'exp_'+(e.slug||e.id),label:e.name,emoji:_wfEmoji(e.emoji),persona_id:e.slug||e.id,system:e.prompt}));var rid=d.querySelector('#pwRoomTarget').value;var r=await api(rid?'/api/rooms/'+encodeURIComponent(rid)+'/members':'/api/rooms','POST',{title:d.querySelector('#pwRoomTitle').value,model:d.querySelector('#pwRoomModel').value,members:members});if(!r.ok)throw Error(r.error);close();switchPage('rooms');await loadRoomsList();selectRoom(rid||r.room.id);}catch(e){fail(e);}};}catch(e){fail(e);}};
window.roomCreateDialog=function(){pwRoom();};
// Keep Windows and system synthesis separate: the global TTS provider may itself be Windows.
function speechStatus(btn,message){if(!btn)return;btn.title=message;btn.setAttribute('aria-label',message);btn.dataset.speechStatus=message;}
var oldStop=voiceStopAll;
window.voiceStopAll=function(reset){speechStatus(_voice.curBtn,'播放回复');speechJob++;if(speechAbort){speechAbort.abort();speechAbort=null;}if(speechAudio){speechAudio.pause();speechAudio.src='';speechAudio=null;}if(speechUrl){URL.revokeObjectURL(speechUrl);speechUrl=null;}_bargeInStop();if(window.speechSynthesis)speechSynthesis.cancel();return oldStop(reset);};
window._voiceStreamOpen=function(){}; // Both selected engines synthesize completed replies.
async function speechBlob(text,engine,signal,voice){var id=(globalThis.crypto?.randomUUID?crypto.randomUUID():'speech-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2)),cancel=function(){fetch(apiUrl('/api/workspace-ui/speech-cancel'),{method:'POST',headers:{'Content-Type':'application/json','X-Monitor-Token':monitorToken||''},body:JSON.stringify({request_id:id}),keepalive:true}).catch(()=>{});},payload={text:text,request_id:id};if(engine==='system'&&voice)payload.voice=voice;if(signal?.aborted)throw new DOMException('朗读已取消','AbortError');signal?.addEventListener('abort',cancel,{once:true});try{var r=await fetch(apiUrl('/api/workspace-ui/'+(engine==='windows'?'speak':'system-speak')),{method:'POST',headers:{'Content-Type':'application/json','X-Monitor-Token':monitorToken||''},body:JSON.stringify(payload),signal:signal});if(!r.ok){var j=await r.json();throw Error(j.error||'语音服务暂不可用');}var blob=await r.blob();blob.speechEngine=r.headers.get('X-Speech-Engine')||(engine==='windows'?'windows':'edge');return blob;}finally{signal?.removeEventListener('abort',cancel);}}
function browserSpeak(text,btn,job){if(!window.speechSynthesis){voiceStopAll(true);toast('系统朗读暂不可用');return;}var utter=new SpeechSynthesisUtterance(text);utter.lang='zh-CN';utter.rate=Number(localStorage.getItem('pw_voice_rate')||1);_voice.curBtn=btn;_voice.playing=true;btn.classList.add('speaking');btn.innerHTML=voiceBtnHtml('stop');utter.onend=function(){if(job===speechJob){voiceStopAll(true);_voiceChatMaybeRestart();}};utter.onerror=function(){if(job===speechJob)voiceStopAll(true);};speechStatus(btn,'浏览器朗读中，点击停止');toast('语音服务未能合成，已使用浏览器朗读');speechSynthesis.speak(utter);_bargeInStart();}
window.speakMsg=async function(btn){
 try{await ready;}catch(e){fail(e);return;}var text=voiceGetText(btn);if(!text){toast('没有可朗读的内容');return;}if(_voice.curBtn===btn){voiceStopAll(true);return;}
 voiceStopAll(true);var job=speechJob;_voice.curBtn=btn;btn.classList.add('speaking');btn.innerHTML=voiceBtnHtml('stop');speechAbort=new AbortController();speechStatus(btn,'正在合成，点击取消');var blob;
 try{
  try{blob=await speechBlob(text,state.voice.engine,speechAbort.signal);}catch(e){if(job!==speechJob||e.name==='AbortError')return;if(state.voice.engine==='windows'&&!state.voice.fallback)throw e;if(state.voice.engine==='windows'){toast(e.message+'，正在使用系统朗读');try{blob=await speechBlob(text,'system',speechAbort.signal);}catch(second){if(job!==speechJob||second.name==='AbortError')return;browserSpeak(text,btn,job);return;}}else{browserSpeak(text,btn,job);return;}}
  if(job!==speechJob)return;var url=URL.createObjectURL(blob),audio=new Audio(url);speechAudio=audio;speechUrl=url;audio.playbackRate=Number(localStorage.getItem('pw_voice_rate')||1);
  audio.onended=function(){if(job===speechJob){voiceStopAll(true);_voiceChatMaybeRestart();}};audio.onerror=function(){if(job===speechJob){voiceStopAll(true);toast('音频播放失败，请重试');}};
  await audio.play();speechStatus(btn,(blob.speechEngine==='windows'?'Windows':'系统')+'朗读中，点击停止');_voice.playing=true;_bargeInStart();
 }catch(e){if(job!==speechJob||e.name==='AbortError')return;voiceStopAll(true);if(e.name==='NotAllowedError')toast('浏览器暂停了自动播放，请再点击播放');else fail(e);}
};
window.openVoiceSettings=async function(){
 if(document.getElementById('pwOverlay')?._voiceSaving)return;
 await ready;var d=modal('声音与朗读',
 '<div class="field"><label>朗读引擎</label><select id="pwVoiceEngine"><option value="windows">Windows · IndexTTS（默认）</option><option value="system">系统 · Edge TTS</option></select></div>'+
 '<div class="field"><label>Windows 音色</label><select id="pwVoiceId"><option value="">加载现有音色库…</option></select></div><p class="pw-hint" id="pwVoiceHint">复用语音工作台的当前音色；切换会同步影响使用该音色的其他渠道。</p>'+
 '<div class="pw-row"><label><input type="checkbox" id="pwVoiceFallback"> Windows 失败后回退系统朗读</label><label><input type="checkbox" id="pwVoiceEmotion"> 自动判断语气</label></div>'+
 '<div class="field"><label>系统回退音色</label><select id="pwSystemVoice"><option value="zh-CN-XiaoxiaoNeural">晓晓（女·温暖）</option><option value="zh-CN-YunxiNeural">云希（男·自然）</option></select></div>'+
 '<div class="field"><label>播放速度（本浏览器）</label><select id="pwVoiceRate">'+[0.75,1,1.15,1.3,1.5].map(v=>'<option value="'+v+'">'+v+'×</option>').join('')+'</select></div>'+
 '<div class="pw-row"><label><input type="checkbox" id="pwAutoplay"> 回复完成后自动朗读</label><label><input type="checkbox" id="pwAutosend"> 语音输入自动发送</label><label><input type="checkbox" id="pwVoiceChat"> 连续语音对话</label><label><input type="checkbox" id="pwVoiceBarge"> 说话打断朗读</label></div>'+
 '<p class="pw-hint">Windows 按完整回复合成后播放。精细音色与情绪参数可在 <a href="https://example.com/pick/" target="_blank" rel="noopener">语音工作台</a> 调整。系统服务也不可用时，继续尝试浏览器朗读。</p>'+
 '<button class="btn" id="pwVoiceTest">试听已保存声音</button><audio id="pwVoicePreview" controls style="display:none;width:100%;margin-top:12px"></audio>'+
 '<p id="pwVoiceSaveStatus" class="maintenance-feedback" role="status"></p>',
 '<button class="btn primary" id="pwSaveVoice">保存</button><button class="btn" id="pwVoiceReview">核对最新设置</button><button class="btn" id="pwVoiceDiscard">放弃草稿</button>');
 var base=null,voiceLoaded=false,draftKey='panel-voice-draft',status=d.querySelector('#pwVoiceSaveStatus'),saving=false,confirmedPayload=null;
 var ids=['pwVoiceEngine','pwVoiceFallback','pwVoiceId','pwVoiceEmotion','pwSystemVoice','pwVoiceRate','pwAutoplay','pwAutosend','pwVoiceChat','pwVoiceBarge'];
 d.querySelector('#pwVoiceEngine').value=state.voice.engine;d.querySelector('#pwVoiceFallback').checked=state.voice.fallback;d.querySelector('#pwSystemVoice').value=state.voice.system_voice||'zh-CN-XiaoxiaoNeural';d.querySelector('#pwVoiceRate').value=localStorage.getItem('pw_voice_rate')||'1';
 [['pwAutoplay','fnos-voice-autoplay',false],['pwAutosend','fnos-voice-autosend',true],['pwVoiceChat','fnos-voice-chat',false],['pwVoiceBarge','fnos-voice-barge',true]].forEach(([id,key,def])=>d.querySelector('#'+id).checked=def?localStorage.getItem(key)!=='0':localStorage.getItem(key)==='1');
 function values(){var out={};ids.forEach(id=>{var e=d.querySelector('#'+id);out[id]=e.type==='checkbox'?e.checked:e.value;});return out;}
 function fill(v){Object.entries(v||{}).forEach(([id,value])=>{var e=d.querySelector('#'+id);if(!e||!ids.includes(id))return;if(e.type==='checkbox')e.checked=value===true;else{if(e.tagName==='SELECT'&&!Array.from(e.options).some(o=>o.value===value)){var opt=document.createElement('option');opt.value=value;opt.textContent=value+' · 已保留选择';e.append(opt);}e.value=value;}});}
 function persist(){try{localStorage.setItem(draftKey,JSON.stringify({version:1,base,values:values()}));status.textContent='未保存的声音选择已保留';}catch(_){status.textContent='浏览器无法保存草稿，请完成保存后再关闭';}}
 function adopt(view,keep){confirmedPayload=null;base=view;voiceLoaded=!!view.current;d.querySelector('#pwVoiceId').innerHTML=(view.voices||[]).map(x=>'<option value="'+E(x.id)+'">'+E(x.name)+'</option>').join('');d.querySelector('#pwVoiceId').disabled=!voiceLoaded;d.querySelector('#pwVoiceEmotion').disabled=!voiceLoaded;d.querySelector('#pwVoiceHint').textContent=view.bridge_error||view.bridge_warning||'Windows音色与自动语气由工作台共享，修改会影响使用它的其他渠道。';if(!keep)fill({pwVoiceEngine:view.preferences.engine,pwVoiceFallback:view.preferences.fallback,pwSystemVoice:view.preferences.system_voice,pwVoiceId:view.current?.id||'',pwVoiceEmotion:view.current?.emo_auto!==false});else fill(keep);if(['saving','needs_review'].includes(view.last_save?.status))status.textContent='上次声音保存未全部确认，请核对当前工作台声音后保存。';}
 try{adopt(await request('/voice'));var draft=JSON.parse(localStorage.getItem(draftKey)||'null');if(draft?.version===1){fill(draft.values);base=draft.base||base;status.textContent='已恢复未保存的声音选择；保存前会核对版本。';}}catch(e){status.textContent=e.message;d.querySelector('#pwVoiceId').disabled=true;d.querySelector('#pwVoiceEmotion').disabled=true;}
 ids.forEach(id=>d.querySelector('#'+id).addEventListener('change',persist));
 d.querySelector('#pwVoiceReview').onclick=async function(){try{var keep=values(),latest=await request('/voice');var text='当前已保存：'+(latest.preferences.engine==='windows'?'Windows':'系统')+'；回退'+(latest.preferences.fallback?'开':'关')+'；系统音色 '+latest.preferences.system_voice+'；Windows '+(latest.current?.id||'暂不可读取')+'；自动语气'+(latest.current?.emo_auto?'开':'关')+'。采用该版本并保留当前输入？';if(!(await ui.confirm(text)))return;adopt(latest,keep);persist();status.textContent='已核对最新版本，请检查输入后保存。';}catch(e){status.textContent=e.message;}};
 d.querySelector('#pwVoiceDiscard').onclick=async function(){if(!(await ui.confirm('放弃未保存的声音选择？')))return;try{localStorage.removeItem(draftKey);}catch(_){status.textContent='浏览器无法清除草稿，请恢复存储后重试';return;}close();openVoiceSettings();};
 async function saveVoice(){
  if(!base)throw Error('请先核对最新设置');
  var selected={id:d.querySelector('#pwVoiceId').value,emo_auto:d.querySelector('#pwVoiceEmotion').checked},payload={preference_revision:base.preference_revision,bridge_revision:base.bridge_revision,preferences:{engine:d.querySelector('#pwVoiceEngine').value,fallback:d.querySelector('#pwVoiceFallback').checked,system_voice:d.querySelector('#pwSystemVoice').value}};
  if(voiceLoaded&&payload.preferences.engine==='windows'&&JSON.stringify(selected)!==JSON.stringify(base.current))payload.windows=selected;
  var signature=JSON.stringify({preferences:payload.preferences,windows:payload.windows||null});
  if(confirmedPayload!==signature){var result=await request('/voice','PUT',payload);state.voice={...state.voice,...payload.preferences};base={...base,preferences:payload.preferences,preference_revision:result.preference_revision||base.preference_revision,bridge_revision:result.bridge_revision||base.bridge_revision,current:payload.windows||base.current};confirmedPayload=JSON.stringify({preferences:payload.preferences,windows:null});}
  try{localStorage.setItem('pw_voice_rate',d.querySelector('#pwVoiceRate').value);
  [['pwAutoplay','fnos-voice-autoplay'],['pwAutosend','fnos-voice-autosend'],['pwVoiceChat','fnos-voice-chat'],['pwVoiceBarge','fnos-voice-barge']].forEach(([id,key])=>localStorage.setItem(key,d.querySelector('#'+id).checked?'1':'0'));
  if(!d.querySelector('#pwVoiceChat').checked)_voice.chatLoop=false;
  localStorage.removeItem(draftKey);
  }catch(_){persist();throw Error('服务端声音设置已保存；本浏览器的播放速度或语音开关未全部保存，请恢复浏览器存储后重试保存。');}
 }
 d.querySelector('#pwSaveVoice').onclick=async function(){if(saving)return;saving=true;d._voiceSaving=true;persist();d.querySelectorAll('button,input,select').forEach(e=>e.disabled=true);try{await saveVoice();d._voiceSaving=false;close();toast('声音设置已保存');}catch(e){status.textContent=e.message;}finally{saving=false;d._voiceSaving=false;d.querySelectorAll('button,input,select').forEach(e=>e.disabled=false);d.querySelector('#pwVoiceId').disabled=!voiceLoaded;d.querySelector('#pwVoiceEmotion').disabled=!voiceLoaded;}};
 d.querySelector('#pwVoiceTest').onclick=async function(){var button=this;try{button.disabled=true;button.textContent='合成中…';status.textContent='正在按当前选择合成试听…';d._speechAbort?.abort();d._speechAbort=new AbortController();var engine=d.querySelector('#pwVoiceEngine').value,systemVoice=d.querySelector('#pwSystemVoice').value,selectedWindowsVoice=d.querySelector('#pwVoiceId').value,blob;if(engine==='windows'&&selectedWindowsVoice!==base?.current?.id)throw Error('当前 Windows 音色尚未保存；先保存后再试听，避免试听时改动共享语音工作台。');try{blob=await speechBlob('你好，这是语音试听。',engine,d._speechAbort.signal,systemVoice);}catch(e){if(e.name==='AbortError'||!d.isConnected||engine!=='windows'||!d.querySelector('#pwVoiceFallback').checked)throw e;blob=await speechBlob('你好，这是系统回退语音。','system',d._speechAbort.signal,systemVoice);d.querySelector('#pwVoiceHint').textContent=e.message+'；本次试听已使用 '+systemVoice+' 系统回退。';}var a=d.querySelector('#pwVoicePreview');if(!d.isConnected)return;if(a.src)URL.revokeObjectURL(a.src);a.src=URL.createObjectURL(blob);a.style.display='block';a.playbackRate=Number(localStorage.getItem('pw_voice_rate')||1);await a.play();status.textContent='试听播放中：'+(blob.speechEngine==='windows'?'Windows 音色 '+selectedWindowsVoice:'系统音色 '+systemVoice);}catch(e){if(e.name!=='AbortError'&&d.isConnected){status.textContent=e.message;fail(e);}}finally{button.disabled=false;button.textContent='试听当前选择';}};
};

function roomIdentity(el,label,isMe){if(!el)return;var room=roomsStore.find(r=>r.id===currentRoom),member=room&&(room.members||[]).find(m=>m.label===label);var av=el.querySelector('.av,.rs-av'),name=el.querySelector('.meta b,.room-sender .sn');if(!av&&isMe){av=document.createElement('span');av.className='rs-av';var sender=el.querySelector('.room-sender');if(sender)sender.prepend(av);}if(av){av.classList.toggle('circle',state.identity?.avatar_shape==='circle');av.innerHTML=avatarHTML(isMe?state.identity.user_avatar:member?member.emoji:state.identity.assistant_avatar);}if(name&&isMe)name.textContent=state.identity.user_name;}
window.pwDecorateRoom=function(el,label,isMe){roomIdentity(el,label,isMe);return el;};
/* 渠道记录预览态：以前用 window.switchTab / openTab / newTab / sendRaw 四处覆盖去拦，
   谁后加载谁赢。现在只提供 tabs.js 外壳认的这一个接口，基础实现回 tabs.js。
   active 读的是 tabs.js 里的全局 _channelViewActive，两边看同一个值。 */
window.chatChannel={
  get active(){return !!_channelViewActive;},
  leave:function(){
    _channelViewActive=false;
    var c=document.getElementById('chatComposer'); if(c) c.hidden=false;
    var rb=document.getElementById('chReturnBtn'); if(rb) rb.style.display='none';
  },
  afterSwitch:function(id){ if(String(id)===String(currentSession)) loadSessionMessages(id); }
};

document.addEventListener('click',async function(e){var b=e.target.closest('[data-pw-chat],[data-pw-room],[data-pw-fav],[data-pw-edit]');if(!b)return;if(b.dataset.pwChat)pwExpertChat(b.dataset.pwChat);if(b.dataset.pwRoom)pwRoom(b.dataset.pwRoom);if(b.dataset.pwEdit)openBuiltinExpertEditor(b.dataset.pwEdit);if(b.dataset.pwFav){try{var id=b.dataset.pwFav,f=state.favorites.slice(),i=f.indexOf(id);if(i<0)f.push(id);else f.splice(i,1);await request('/preferences','PUT',{favorites:f});await reload();renderBuiltinExperts();renderMineExperts();}catch(err){fail(err);}}});






function init(){ready=fetchToken().then(reload);ready.then(function(){if(currentSession&&!_tabStreaming[currentSession]&&!_channelViewActive)loadSessionMessages(currentSession,false,true);}).catch(fail);/* 侧栏顶部只留两个图标（2026-11-11 用户要求）：文件夹=新建文件夹、加号=新建会话。
   原来自这里动态注入的 ⚙(名称与头像) 和 🔍(搜索消息内容) 已删除，head 改为 index.html 静态两按钮，
   同时把「第一个 .icon-btn 改成新建菜单」的劫持也去掉（会把文件夹按钮指错）。
   全文搜索仍可从会话树列表顶部的搜索框进。
   （2026-11-24 用户点名删掉工具栏那个搜索按钮：会话树顶上已经有了，重复。
   同时给剩下的两个按钮补 data-tip（工作区 / 多会话标签栏）——原来只有 title，面板的提示层不认它。） */var mineSearch=document.getElementById('expMineSearch');if(mineSearch)mineSearch.placeholder='搜索收藏的专家…';var page=document.querySelector('#page-experts .page-body');if(page&&!page.querySelector('.expert-library-grid')){var info=document.createElement('div');info.className='pw-expert-info';info.innerHTML='<div><strong>单专家对话</strong>按专长组织答案和工作方法。共享当前技能与工具，角色跟随会话。</div><div><strong>专家群聊</strong>多位专家各自回复，主持人组织讨论；适合方案评审、对比和分工。</div>';page.prepend(info);var tabs=page.querySelectorAll('#expTabs button');if(tabs[0])tabs[0].textContent='常用专家';var a=page.querySelector('.exp-actions');if(a){var b=document.createElement('button');b.className='btn';b.textContent='组建群聊';b.onclick=()=>pwRoom();a.prepend(b);}}var body=document.getElementById('chatBody');if(body){var _pwP=0,_pwN=-1;var _pwRun=function(){_pwP=0;var s=body.querySelectorAll('.chat-sender');if(s.length===_pwN)return;_pwN=s.length;pwDecorateLive();};new MutationObserver(function(){if(_pwP)return;_pwP=1;requestAnimationFrame(_pwRun);}).observe(body,{childList:true,subtree:true});}}
document.addEventListener('click',function(e){const button=e.target.closest('[data-expert-question]');if(!button)return;const prompt=activeExpert()?.quick_prompts?.[Number(button.dataset.expertQuestion)];if(prompt){const input=document.getElementById('chatInput');input.value=prompt;autoResize(input);saveDraft(currentSession);input.focus();}});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&document.getElementById('pwOverlay'))close();});
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
