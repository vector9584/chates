import {recordGatewaySession,usageSummary} from './panel-chat-accounting.js';
import {PanelDrain} from './panel-drain.js';
import {ServiceHealth} from './panel-service-health.js';
import {createServiceProcesses} from './panel-service-process.js';
import {createRestartIngress} from './panel-restart-ingress.js';
import {createChannelRuntime} from './panel-channel-runtime.js';
import {inspectServicePortConflicts} from './panel-process-guard.js';
// Hermes Agent 监控服务 — 基于 Node.js 的 HTTP 服务（Unix Socket），WebSocket 由 ws 库提供
import { spawn, spawnSync, execSync, execFile } from "child_process";
import { createRequire } from "module";
import { Readable } from "stream";
import { writeFileSync, readFileSync, unlinkSync, existsSync, mkdirSync, statSync, symlinkSync, watch, chmodSync, chownSync, readdirSync, createReadStream, openSync, readSync, closeSync, rmSync, copyFileSync, appendFileSync, renameSync } from "fs";
import { randomBytes, createHash } from "crypto";
import { networkInterfaces } from "os";
import { resolve as resolvePath, dirname, join } from "path";
import { fileURLToPath } from "url";
import { handleCustomRoute } from "./custom_routes.js";
import { skillInstallName } from "./panel-skill-path.js";
import { handleWorkspace, sessionSystem, sessionIdentity, sessionSnapshot, readWorkspace, ensureSessionUploadDir, sessionGroupDir, resolveSessionFileDir, SESSION_SUBDIRS } from "./panel-workspace.js";
import {preserveSessionStickers, stickerSource, isRasterSticker, sessionSticker, moveSessionWorkdir, existingSessionWorkdir} from "./panel-session-media.js";
import { UI_CAPABILITIES_PROMPT, buildChatHistory } from "./panel-chat-prompt.js";
import { createChatCompress } from "./panel-chat-compress.js";
import { atomicWriteJSON, safeId } from "./panel-state.js";
import { ChatQueue } from "./panel-queue.js";
import { createQueueHandler } from "./panel-queue-http.js";
import { createPushHub } from "./panel-push.js";
import { createClientDiag } from "./panel-client-diag.js";
import { createUsageHandler } from "./panel-usage.js";
import { createCronUpdateHandler, cronRevision } from "./panel-cron.js";
import { CronHooks, createCronHookHandler, webhookText } from "./panel-cron-hooks.js";
import { createCronHistoryHandler } from "./panel-cron-history.js";
import { ModelChecks, createModelSource, createModelChecksHandler } from "./panel-model-checks.js";
import {LibraryReviews,createLibraryReviewHandler} from './panel-library-reviews.js';
import {LibraryStore,createLibraryHandler} from './panel-library.js';
import {createUpdateHandler} from './panel-update.js';
import {createLibrarySources} from './panel-library-sources.js';
import {createArchiveVault} from './panel-archive.js';
import {PlanStore,createPlanHandler,createPlanLaunch} from './panel-plans.js';
import {bindSessionPlan} from './panel-workspace.js';
import { RoomStore, RoomRunner, createRoomHandler } from "./panel-rooms.js";
import { createRoomExecution } from "./panel-room-execution.js";
import { expertCatalog, saveExpert, getExpert } from "./panel-experts.js";
import { createAuxiliaryHandler } from "./panel-auxiliary.js";
import { createSpeechConfigHandler } from "./panel-speech-config.js";
import { createConnectorToolsHandler } from "./panel-connector-tools.js";
import { ConnectorStore, createConnectorHandler } from "./panel-connectors.js";
import { createConnectorProbeHandler } from "./panel-connector-probe.js";
import { createMaintenanceHandler } from "./panel-maintenance.js";
import { createEchoHandler } from "./panel-echo.js";
import { PanelAuth, panelPath } from "./panel-auth.js";
import {dispatchPanel,authorizePanelUpgrade} from "./panel-http.js";
import {createRestartReceipt} from './panel-restart-receipt.js';
import {PanelRuntime,createRuntimeHandler} from "./panel-runtime.js";
import {createConfigRecovery} from "./panel-config-recovery.js";
import {createChannelsService} from "./panel-channels.js";
import {ChannelPairing,createPairingHandler} from "./panel-channel-pairing.js";
import {createChannelIngress} from "./panel-channel-ingress.js";
import {createTypingHandler} from "./panel-typing.js";
import {createModelsService,resolveModelRoutes} from "./panel-models.js";
import {createMcpHandler} from "./panel-mcp.js";
import {configTransaction,configReaderWriter} from "./panel-config-txn.js";
import {envReaderWriter,channelConfigWriter} from "./panel-env-txn.js";
import {parseEnv,envValue,setEnvValue} from "./panel-env-format.js";
import {createFileRoots,createFileHandler,fileReference,openStaticFile} from "./panel-files.js";
import { CONNECTOR_CATALOG, getConnector, callConnectorTool, probeConnector } from "./connectors.js";
import { BUILTIN_EXPERTS_ALL } from "./experts-data.js";
import { interruptAssistantMessage, recoverInterruptedAssistantMessage } from "./panel-chat-recovery.js";
import {LogClearStore} from './panel-log-clear.js';

// 加载 vendor 目录内置的 ws 库（Node.js 无内置 WebSocket 服务器）
const _require = createRequire(import.meta.url);
const wsLib = _require("./_vendor/ws/index.js");
const { WebSocketServer, WebSocket } = wsLib;

const APP_DIR        = process.env.APP_DIR       || "/var/apps/hermes-agent";
const DATA_DIR       = process.env.DATA_DIR      || `${APP_DIR}/home/data`;
const VAR_DIR        = process.env.VAR_DIR       || `${APP_DIR}/var`;
const LOG_FILE       = `${VAR_DIR}/hermes.log`;
const panelLogClear=new LogClearStore({varDir:VAR_DIR,dataDir:DATA_DIR});
const PID_GATEWAY    = `${VAR_DIR}/gateway.pid`;
const PID_DASHBOARD  = `${VAR_DIR}/dashboard.pid`;
const TOKEN_FILE     = `${VAR_DIR}/monitor.token`;
const VERSION_FILE   = `${VAR_DIR}/hermes_version.txt`;
const MANIFEST_FILE  = `${APP_DIR}/manifest`;
const START_TIME     = Date.now();

// Refuse a second Monitor of this exact installation before touching sockets,
// PID files, service state or queues. Never take over another application's
// monitor merely because its command contains the same filename.
try {
  const script=fileURLToPath(import.meta.url);
  for(const entry of readdirSync('/proc')){
    if(!/^\d+$/.test(entry)||Number(entry)===process.pid)continue;
    try {
      const argv=readFileSync(`/proc/${entry}/cmdline`,'utf8').split('\0').filter(Boolean);
      const raw=readFileSync(`/proc/${entry}/stat`,'utf8'),state=raw.slice(raw.lastIndexOf(')')+2).split(/\s+/)[0];
      if(argv[1]===script&&argv[0]===process.execPath&&!['Z','X'].includes(state)){
        console.error('[monitor] 此安装已有Monitor运行，未接管或停止任何进程');process.exit(1);
      }
    }catch{}
  }
}catch{}


// ── Cloudflare Tunnel（隧道/外网访问）──
const TUNNEL_BIN_DIR   = `${VAR_DIR}/bin`;
const TUNNEL_BIN       = `${TUNNEL_BIN_DIR}/cloudflared`;
const TUNNEL_STATE_PATH= `${VAR_DIR}/tunnel-state.json`;
const TUNNEL_LOG_PATH  = `${VAR_DIR}/logs/tunnel.log`;
const TUNNEL_CF_VERSION= "2026.7.3";
const TUNNEL_DL_URL    = `https://github.com/cloudflare/cloudflared/releases/download/${TUNNEL_CF_VERSION}/cloudflared-linux-amd64`;
// 下载源候选列表（顺序尝试）：ghfast.top 加速镜像优先（中国大陆网络实测 2.6MB/s），GitHub 直连兜底
const TUNNEL_DL_SOURCES = [
  `https://ghfast.top/${TUNNEL_DL_URL}`,
  `https://ghproxy.net/${TUNNEL_DL_URL}`,
  TUNNEL_DL_URL,
];
let _tunnelProc = null;   // 当前 cloudflared 子进程（模块级，避免热更/重启丢失引用）

// ── TTS 可选音色（Edge 语音，用于语音设置弹窗的声音选择）──
const TTS_VOICE_OPTIONS = [
  { id: "zh-CN-XiaoxiaoNeural", name: "晓晓（女·温暖）", desc: "标准普通话，温柔自然" },
  { id: "zh-CN-XiaoyiNeural",   name: "晓伊（女·活泼）", desc: "年轻灵动" },
  { id: "zh-CN-YunxiNeural",    name: "云希（男·阳光）", desc: "青年男声" },
  { id: "zh-CN-YunjianNeural",  name: "云健（男·沉稳）", desc: "成熟男声" },
  { id: "zh-CN-YunxiaNeural",   name: "云夏（男·少年）", desc: "少年音" },
  { id: "zh-CN-liaoning-XiaobeiNeural", name: "晓北（女·东北）", desc: "东北口音" },
  { id: "en-US-AriaNeural",     name: "Aria（英文女声）", desc: "英语语音" },
];

// 应用包版本（来自 manifest，与应用中心安装包版本一致）。
// 注意：它和「hermes-agent PyPI 版本」(HERMES_VERSION) 是两个不同概念，UI 必须分开展示，避免混淆。
// 版本覆盖文件：热更/完整更新写入 manifest 失败时（如 manifest 不存在/不可写）的兜底持久化位置，优先级最高。
const VERSION_OVERRIDE_FILE = `${VAR_DIR}/app_version`;
function readAppVersion() {
  const candidates = [
    VERSION_OVERRIDE_FILE,
    MANIFEST_FILE,
    "/var/apps/hermes-agent/manifest",
    `${process.cwd()}/manifest`,
  ];
  // Windows 安装器把版本写在 app/version.json（install.ps1），没有 manifest，这里补上
  for (const jf of [`${APP_DIR}/version.json`, `${APP_DIR}/../version.json`]) {
    try {
      const j = JSON.parse(readFileSync(jf, "utf8"));
      if (j && j.version) return String(j.version).trim();
    } catch {}
  }
  // 尝试从 monitor.js 位置向上推导（兼容 ESM 与不同安装路径）
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    candidates.push(join(here, "../../manifest"));
    candidates.push(join(here, "../manifest"));
  } catch {}
  for (const fp of candidates) {
    try {
      const txt = readFileSync(fp, "utf8");
      const m = txt.match(/^version\s*=\s*(\S+)/m);
      if (m) {
        const v = m[1].trim();
        if (v && v !== "unknown") return v;
      }
    } catch {}
  }
  return "unknown";
}
// 版本号比较：返回 -1/0/1
function compareVersions(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0, nb = pb[i] || 0;
    if (na < nb) return -1;
    if (na > nb) return 1;
  }
  return 0;
}
let APP_VERSION = readAppVersion();
log(`[启动检测] 应用包版本(manifest): ${APP_VERSION}`);

// 内置技能固化部署：hermes 技能系统只发现 $HERMES_HOME/skills（+ config external_dirs），
// hermes-src/skills 的 bundled 技能默认不可见。启动时把应用依赖的内置技能复制到
// DATA_DIR/skills（缺失才补，不覆盖用户已有/修改），保证每台机器装上应用即有、
// 即使被删除也会在下次启动自动恢复（"无法删除"的内置技能）。
const BUILTIN_SKILLS = ["note-taking/obsidian"];
function _deployBuiltinSkills(){
  try {
    const srcRoot = `${APP_DIR}/hermes-src/skills`;
    const dstRoot = `${DATA_DIR}/skills`;
    if (!existsSync(srcRoot)) return;
    BUILTIN_SKILLS.forEach(rel => {
      const src = `${srcRoot}/${rel}`;
      const dst = `${dstRoot}/${rel}`;
      if (!existsSync(src)) return;
      try {
        if (existsSync(`${dst}/SKILL.md`)) return;   // 已存在：不覆盖用户内容
        mkdirSync(dirname(dst), { recursive: true });
        cpSync(src, dst, { recursive: true });
        log(`[skills] 内置技能已固化: ${rel} → ${dstRoot}/${rel}`);
      } catch (e) {
        log(`[skills] 固化 ${rel} 失败: ${e.message}`);
      }
    });
  } catch (e) { log(`[skills] 内置技能固化扫描失败: ${e.message}`); }
}
_deployBuiltinSkills();
// 技能市场安装目录自愈：面板技能市场安装的技能存放在 VAR_DIR/skills，并注册到
// extensions.json skills_dirs + config.yaml skills.external_dirs。应用升级/配置重置
// 可能清空注册信息，导致已装技能成为"孤儿"（文件在但 Hermes 不加载）。启动时扫描
// VAR_DIR/skills 下含 SKILL.md 的目录，自动补全注册（含历史遗留与升级丢失场景）。
function _reconcileMarketSkills(){
  try {
    const skillsRoot = join(VAR_DIR, "skills");
    if (!existsSync(skillsRoot)) return;
    let dirs = [];
    try {
      dirs = readdirSync(skillsRoot).filter(n => {
        try {
          const d = join(skillsRoot, n);
          return statSync(d).isDirectory() && existsSync(join(d, "SKILL.md"));
        } catch (e) { return false; }
      }).map(n => join(skillsRoot, n));
    } catch (e) { log(`[skills] 市场技能目录扫描失败: ${e.message}`); return; }
    if (!dirs.length) return;
    // 1) extensions.json skills_dirs 补全
    let ext = null;
    try { ext = JSON.parse(readFileSync(`${VAR_DIR}/extensions.json`, "utf8")); } catch (e) {}
    if (!ext) ext = { toolsets: {}, mcp_servers: [], skills_dirs: [], persona: "default", memory: { enabled: true, char_limit: 2200 } };
    ext.skills_dirs = ext.skills_dirs || [];
    let changed = false;
    dirs.forEach(d => { if (!ext.skills_dirs.includes(d)) { ext.skills_dirs.push(d); changed = true; } });
    if (changed) { try { writeFileSync(`${VAR_DIR}/extensions.json`, JSON.stringify(ext, null, 2)); } catch (e) { log(`[skills] extensions.json 写入失败: ${e.message}`); } }
    // 2) config.yaml skills.external_dirs 补全（简化 YAML 合并：仅处理 skills 块内 external_dirs 键）
    const yamlPath = `${DATA_DIR}/config.yaml`;
    if (existsSync(yamlPath)) {
      try {
        let y = readFileSync(yamlPath, "utf8");
        const y2 = _simpleMergeExternalDirs(y, ext.skills_dirs);
        if (y2 !== y) { writeFileSync(yamlPath, y2); changed = true; }
      } catch (e) { log(`[skills] config.yaml external_dirs 写入失败: ${e.message}`); }
    }
    if (changed) log(`[skills] 市场技能目录自愈注册 ${dirs.length} 个: ${dirs.join(", ")}`);
  } catch (e) { log(`[skills] 市场技能自愈失败: ${e.message}`); }
}

// 顶层简化版：把 dirs 合并进 config.yaml 的 skills.external_dirs（保留 skills 段其它字段）
function _simpleMergeExternalDirs(content, dirs){
  const lines = content.split("\n");
  const out = [];
  let i = 0, inSkills = false, replaced = false;
  const scalarSafe = v => {
    const s = String(v == null ? "" : v);
    const risky = s === "" || /^[\s>|@`"'%#&*!?\[\]{},-]/.test(s) || /\s$/.test(s) || /:(\s|$)/.test(s) || /\s#/.test(s);
    return risky ? JSON.stringify(s) : s;
  };
  while (i < lines.length){
    const line = lines[i];
    if (line === "skills:"){ inSkills = true; out.push(line); i++; continue; }
    if (inSkills && !line.startsWith("  ") && line.trim() !== ""){
      if (!replaced){ out.push("  external_dirs:"); dirs.forEach(d => out.push("    - " + scalarSafe(d))); replaced = true; }
      inSkills = false;
      out.push(line); i++; continue;
    }
    if (inSkills && /^\s*external_dirs:/.test(line)){
      out.push("  external_dirs:");
      dirs.forEach(d => out.push("    - " + scalarSafe(d)));
      replaced = true;
      i++;
      while (i < lines.length && (lines[i].startsWith("    ") || /^\s+-\s/.test(lines[i]))) i++;
      continue;
    }
    out.push(line); i++;
  }
  if (inSkills && !replaced){ out.push("  external_dirs:"); dirs.forEach(d => out.push("    - " + scalarSafe(d))); }
  return out.join("\n");
}
_reconcileMarketSkills();

// 同步 fnOS 应用中心运行状态（app 表 status='running'）——monitor 实际运行中，防应用中心 UI 误显示未启动
try {
  execSync(`sudo -n sudo -u postgres /usr/bin/psql -d appcenter -c "UPDATE app SET status='running' WHERE app_name='hermes-agent'" 2>&1`, { timeout: 10000 });
} catch (e) {}

// 知识库/记忆种子：首次启动时写入基础内容（仅文件不存在时），让知识库与记忆页不空
function _kbRootForSeed(){
  try {
    const envText = readFileSync(`${DATA_DIR}/.env`, "utf8");
    const m = envText.match(/^OBSIDIAN_VAULT_PATH\s*=\s*(.+)$/m);
    if (m && m[1].trim()) return m[1].trim();
  } catch {}
  return `${DATA_DIR}/knowledge`;
}
function _seedKnowledgeAndMemory(){
  try {
    const kroot = _kbRootForSeed();
    mkdirSync(kroot, { recursive: true });
    const readme = `${kroot}/README.md`;
    if (!existsSync(readme)) {
      writeFileSync(readme,
`# 📚 Hermes 知识库

这是 Hermes 的持久化知识库（Obsidian 兼容：.md + frontmatter + [[wikilink]]）。

## 使用方式

- 左侧菜单「知识库」浏览 / 编辑笔记
- 正文用 \`[[笔记名]]\` 串联相关笔记（自动生成反向链接）
- 对话中的技能使用、重要结论会自动沉淀到本库
- 与 AI 的 Obsidian 技能共用同一 vault（OBSIDIAN_VAULT_PATH）

## 建议目录

- \`概念/\` — 领域知识、术语
- \`技能使用/\` — 每次对话调用的技能记录（自动）
- \`对话沉淀/\` — 重要对话的要点提炼（自动）
- \`项目/\` — 项目上下文、决策记录
`, "utf8");
      log(`[kb] 知识库种子 README 已创建`);
    }
    const notes = `${DATA_DIR}/notes.md`;
    if (!existsSync(notes)) {
      writeFileSync(notes,
`# 笔记（notes.md）

Agent 的项目笔记、用户偏好与环境信息。对话中说「记住……」的内容会自动追加到这里。

## 用户偏好

## 环境信息

## 项目上下文
`, "utf8");
      log(`[memory] 记忆笔记种子已创建`);
    }
  } catch (e) { log(`[seed] 种子写入失败: ${e.message}`); }
}
_seedKnowledgeAndMemory();

// 知识镜像兜底（Hermes 知识整合方案）：mirror.py 存在则启动时执行一次
// （memories → knowledge 单向镜像；配合 crontab 每 30 分钟 + 安装/升级 init.sh 部署）
try {
  const _mirrorPy = `${DATA_DIR}/scripts/knowledge-sync/mirror.py`;
  if (existsSync(_mirrorPy)) {
    execSync(`HERMES_DATA_DIR=${DATA_DIR} python3 ${_mirrorPy} >> ${DATA_DIR}/logs/knowledge-mirror.log 2>&1`, { timeout: 60000 });
    log(`[kb] 知识镜像兜底完成（memories → knowledge）`);
  }
} catch (e) { log(`[kb] 知识镜像兜底失败: ${e.message}`); }
// 热更新/完整更新写入 manifest 后调用，令运行中的进程立即上报新版本号，
// 避免「更新完成但概览页仍显示旧版本」的问题。
function reloadAppVersion() {
  const v = readAppVersion();
  if (v && v !== "unknown") {
    if (v !== APP_VERSION) log(`[版本] 应用包版本已刷新: ${APP_VERSION} → ${v}`);
    APP_VERSION = v;
  }
  return APP_VERSION;
}

// 热更新/完整更新后持久化新版本号：优先更新已存在的 manifest（用启动时实际读到的路径），
// 全部失败则写版本覆盖文件；最后刷新当前进程的 APP_VERSION。
function writeAppVersion(version) {
  let wrote = false;
  const targets = [MANIFEST_FILE, "/var/apps/hermes-agent/manifest", `${process.cwd()}/manifest`];
  try {
    const here = dirname(fileURLToPath(import.meta.url));
    targets.push(join(here, "../../manifest"), join(here, "../manifest"));
  } catch {}
  for (const fp of targets) {
    try {
      if (!existsSync(fp)) continue;
      let mf = readFileSync(fp, "utf8");
      if (/^version\s*=/m.test(mf)) {
        mf = mf.replace(/^version\s*=\s*.+$/m, "version               = " + version);
        writeFileSync(fp, mf);
        wrote = true;
        log(`[版本] manifest 已更新: ${fp} → ${version}`);
        break;
      }
    } catch {}
  }
  if (!wrote) {
    // 兜底：manifest 不存在或不可写，写入版本覆盖文件（readAppVersion 优先读它）
    try {
      writeFileSync(VERSION_OVERRIDE_FILE, "version = " + version + "\n");
      log(`[版本] manifest 不可写，已写入覆盖文件: ${VERSION_OVERRIDE_FILE} → ${version}`);
    } catch (e) {
      log(`[版本] 版本号持久化失败: ${e.message}`);
    }
  }
  return reloadAppVersion();
}

// hermes-agent 版本对应的发布日期，仅用于 UI 展示区分（例如 v0.20.0 (2026.8.3)）。
// 默认值取 0.20.0 的发布日期（2026-08-03，tag v2026.8.3）；0.20.0 起官方停止 PyPI 分发，
// 后台 PyPI 拉取将失败并保留默认值。
let HERMES_VERSION_DATE = "2026.8.3";
(function fetchHermesReleaseDate() {
  try {
    const v = HERMES_VERSION.replace(/^v/, "").split(" ")[0];
    fetch(`https://pypi.org/pypi/hermes-agent/${encodeURIComponent(v)}/json`, {
      signal: AbortSignal.timeout(8000),
    }).then((r) => (r.ok ? r.json() : null)).then((data) => {
      const urls = data && data.urls;
      if (urls && urls[0] && urls[0].upload_time) {
        const d = new Date(urls[0].upload_time);
        HERMES_VERSION_DATE = `${d.getFullYear()}.${d.getMonth() + 1}.${d.getDate()}`;
        log(`[启动检测] Hermes 版本发布日期已更新: ${HERMES_VERSION_DATE}`);
      }
    }).catch(() => {});
  } catch {}
})();

// 默认上下文窗口（tokens）。无法精确获知模型 tokenizer，这里取常见默认值用于进度条展示。
const DEFAULT_CONTEXT_WINDOW = 128000;

// 与 app/ui/index.html 保持一致的人格定义
const EXT_PERSONAS = {
  default:    { emoji: "🤖", label: "默认助手",   prompt: "" },
  coder:      { emoji: "💻", label: "程序员",     prompt: "你是一位资深全栈工程师。优先给出可直接运行的代码与命令，注重安全性、可维护性与生产实践；遇到模糊需求先给出最小可行方案再迭代。" },
  researcher: { emoji: "🔬", label: "研究员",     prompt: "你是一位严谨的研究员。回答须基于证据、引用来源，并明确区分事实、推测与不确定信息；避免臆断。" },
  writer:     { emoji: "✍️", label: "写作助手",   prompt: "你是一位专业的写作助手。擅长结构化、清晰、有感染力的中文表达，依据场景调整语气与篇幅。" },
  analyst:    { emoji: "📊", label: "数据分析师", prompt: "你是一位数据分析师。善于从数据 / 文件中提取洞察，优先给出量化结论与可执行建议。" },
};

// 轻量 token 估算：中文/全角字符 1:1，其他按 4 字符≈1 token。
// 仅用于 UI 上下文用量条，不用于计费或精确截断。
function estimateTokens(text) {
  if (text == null) return 0;
  const s = typeof text === "string" ? text : JSON.stringify(text);
  let tokens = 0;
  for (const ch of s) {
    const code = ch.codePointAt(0);
    // CJK 统一表意文字、韩文、日文、全角符号
    if ((code >= 0x4E00 && code <= 0x9FFF) ||
        (code >= 0x3400 && code <= 0x4DBF) ||
        (code >= 0x3040 && code <= 0x309F) ||
        (code >= 0x30A0 && code <= 0x30FF) ||
        (code >= 0xAC00 && code <= 0xD7AF) ||
        (code >= 0xFF00 && code <= 0xFFEF) ||
        (code >= 0x20000 && code <= 0x2EBEF)) {
      tokens += 1;
    } else {
      tokens += 0.25;
    }
  }
  return Math.ceil(tokens);
}

// 汇总一次请求的上下文用量各组成部分
function computeSessionUsage(session, options = {}) {
  const msgs = (session && session.messages) || [];
  const ext = options.extensions || {};
  const persona = options.persona || {};

  // 系统提示词 = UI 能力提示 + 人格提示
  const systemText = (options.systemPrompt || UI_CAPABILITIES_PROMPT || "") + (persona.prompt || "");
  const systemTokens = estimateTokens(systemText);

  // 对话历史（按 buildChatHistory 规则近似）
  // 2026-11-23 修：① 已被压缩掉的消息（active === false）不再算进上下文，否则压缩越多数字越大；
  //              ② 工具调用参数在 tool_calls 里，content 往往是空串，漏了这块会严重低估。
  const keptMessages = buildChatHistory({ messages: msgs.filter(m => m.active !== false) }, "").slice(1);
  let conversationTokens = 0;
  for (const m of keptMessages) {
    let text = typeof m.content === "string" ? m.content : (m.content == null ? "" : JSON.stringify(m.content));
    if (m.tool_calls) text += (typeof m.tool_calls === "string" ? m.tool_calls : JSON.stringify(m.tool_calls));
    if (m.tool_name) text += m.tool_name;
    conversationTokens += estimateTokens(text) + 4; // +4 角色/格式开销
  }

  // 记忆（按字符估算）
  const memoryEnabled = ext.memory && ext.memory.enabled;
  const memoryTokens = memoryEnabled ? estimateTokens(options.memoryText || "") : 0;

  // 工具定义占位：每个启用的 toolset 约 800 tokens（实际由 Gateway 生成，这里仅做视觉估算）
  const toolsets = ext.toolsets || {};
  const enabledToolsets = Object.keys(toolsets).filter(k => toolsets[k]);
  const toolTokens = enabledToolsets.length * 800;

  // 已安装技能占位：每个技能约 1000 tokens
  const skillDirs = ext.skills_dirs || [];
  const skillCount = Math.max(0, (options.localSkillCount || 0));
  const skillTokens = skillCount * 1000;

  // 子代理 / 工作流占位
  const subagentTokens = toolsets.delegation ? 1200 : 0;

  const total = systemTokens + toolTokens + skillTokens + subagentTokens + memoryTokens + conversationTokens;

  /* 2026-11-23（当日两次校准，最终结论）：
     lastUsage.prompt_tokens 是网关响应头报的【累计计费输入量】，含每轮重复发送的
     系统提示词/工具定义/技能索引 + history 累积，不是「此刻上下文水位」。
     曾把它当 total 用，直接把 2.2 万 token 的会话报成 107 万 / 840%，比原 bug 更离谱。
     因此：total 永远用估算（它就是按「现在这一轮要发多少字」算的），
     prompt_tokens 只作为 measured 参考字段返回，供对照，不参与 pct 计算。 */
  const measured = Number((session && session.lastUsage && session.lastUsage.prompt_tokens) || 0);
  const result = {
    system: systemTokens,
    tools: toolTokens,
    skills: skillTokens,
    subagents: subagentTokens,
    memory: memoryTokens,
    conversation: conversationTokens,
    measured: measured > 0 ? measured : null,
    total,
    window: options.contextWindow || DEFAULT_CONTEXT_WINDOW,
    /* 2026-11-13：pct 原来被 Math.min(100) 夹住，超窗也显示 100%，看不出「已经超了」。
       pct 保持夹紧值兼容旧前端，pctRaw 给真值（可 >100），over 标记是否超窗。 */
    pct: Math.min(100, Math.round((total / (options.contextWindow || DEFAULT_CONTEXT_WINDOW)) * 100)),
    pctRaw: Math.round((total / (options.contextWindow || DEFAULT_CONTEXT_WINDOW)) * 1000) / 10,
    over: total > (options.contextWindow || DEFAULT_CONTEXT_WINDOW),
  };
  return result;
}

// ── Hermes 自更新状态 ──
let updateState = "idle";       // idle | checking | updating | done | error
let updateOutput = [];           // 最近的 stdout/stderr 输出行
let updateExitCode = null;
let updateProc = null;
// 获取本机 LAN IP（排除 loopback）
function getLANIP() {
  const ifs = networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const iface of ifs[name]) {
      if (iface.internal || iface.family !== "IPv4") continue;
      return iface.address;
    }
  }
  return "127.0.0.1";
}

function formatUptime(ms) {
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const parts = [];
  if (d > 0) parts.push(`${d}天`);
  if (h > 0) parts.push(`${h}小时`);
  parts.push(`${m}分钟`);
  return parts.join(" ");
}

const GATEWAY_PORT   = Number(process.env.GATEWAY_PORT || "8742");
const UI_PORT        = Number(process.env.UI_PORT || "8650");
// Windows 本地部署默认只监听 loopback：局域网打不开是刻意的，面板没有密码体系，
// 靠 loopback + 设备 cookie 挡人。要给局域网用就显式设 UI_HOST=0.0.0.0，
// 那时浏览器要先用 auth.json 里的设备 cookie，别裸奔。
const UI_BIND        = process.env.UI_HOST || "127.0.0.1";
const SOCKET_PATH    = (process.env.MONITOR_SOCKET_PATH || "").trim();
// 未设置 socket 路径时降级为纯 TCP 模式（跨平台 / 独立部署用；飞牛上始终会设这个变量）
const UNIX_MODE      = SOCKET_PATH.length > 0;
// 纯 TCP 独立部署没有 fnos gateway 签名，loopback 就是「本机用户」，应直接放行，
// 否则 /api/panel-auth/bootstrap 恒 401，而生成授权码又必须先登录 —— 死锁。
// 走 frp / 公网隧道部署时对端也可能是 127.0.0.1，那种场景把 UI_HOST 设 0.0.0.0
// 或显式 HERMES_PANEL_TRUST_LOOPBACK=0 关掉。
if(!UNIX_MODE&&UI_BIND==="127.0.0.1"&&process.env.HERMES_PANEL_TRUST_LOOPBACK===undefined)process.env.HERMES_PANEL_TRUST_LOOPBACK="1";
if (!UNIX_MODE) {
  console.warn("[WARN] MONITOR_SOCKET_PATH 未设置，进入纯 TCP 模式（UI_PORT 可直连，无 unix socket）");
}
const BASE_PATH      = (process.env.BASE_PATH || "").replace(/\/+$/, "");
const DASHBOARD_PORT = Number(process.env.DASHBOARD_PORT || "9219");
const STATIC_DIR     = `${APP_DIR}/ui`;
// Windows 的 venv 布局是 Scripts/ 不是 bin/，可执行文件要带 .exe，解释器叫 python.exe。
// 这三处写死过一次 POSIX 路径，结果 Windows 上面板起不来 —— 别再改回常量。
const IS_WIN         = process.platform === "win32";
// 运行时位置允许被 CHATES_PYTHON_DIR 覆盖。
// 独立桌面版把 python 打包在 <root>/runtime/python（和 data 平级，不在 data 下），
// 跟 fpk 版「venv 在 data/venv」完全不同。写死前者会让独立版一直报
// `Hermes Agent 版本: unknown`，因为它找不到可以执行 --version 的入口。
// 独立桌面版把 python 解压成「独立解释器」形态：python.exe 在 runtime/python/，
// 启动器（hermes.exe 等 console script shim）在 runtime/python/Scripts/。
// 这两个位置在 fpk 版里是同一个目录（venv/Scripts 同时放 python.exe 和 hermes.exe），
// 所以必须拆成两个变量，否则总有一半功能找不到入口。
const CHATES_PY_ROOT   = process.env.CHATES_PYTHON_ROOT || "";   // .../runtime/python
const CHATES_PY_SCRIPT = process.env.CHATES_PYTHON_SCRIPT || ""; // .../runtime/python/Scripts
const VENV_BIN       = CHATES_PY_ROOT
  ? CHATES_PY_ROOT
  : (IS_WIN ? `${DATA_DIR}/venv/Scripts` : `${DATA_DIR}/venv/bin`);
const SCRIPT_BIN     = CHATES_PY_SCRIPT || VENV_BIN;
const PY_BIN         = IS_WIN ? "python.exe" : "python3";
const HERMES_BIN     = IS_WIN ? `${SCRIPT_BIN}/hermes.exe` : `${SCRIPT_BIN}/hermes`;
const UV_BIN_PATH    = IS_WIN ? `${VENV_BIN}/uv.exe` : `${VENV_BIN}/uv`;
const HERMES_CONFIG  = `${DATA_DIR}/config.yaml`;
const HERMES_ENV     = `${DATA_DIR}/.env`;

// 平台频道定义（与 hermes-studio 的 Platform Channels 对齐）
// 凭证写 ~/.hermes/.env（env），行为写 config.yaml platforms.<id>（path，支持 extra.x 嵌套）
// fields: 凭证输入项；toggles: 行为开关；qrLogin: 微信扫码登录
// 平台频道定义（与 hermes-studio 的 Platform Channels 对齐；2026-07-24 同步 hermes-studio 0.6.30 通讯字段）
// 凭证写 ~/.hermes/.env（env），行为写 config.yaml platforms.<id>.<path>（支持 extra.x 嵌套）
// fields: 凭证输入项（env→.env + platforms.<id>.<path>）
// toggles: 布尔行为开关（platforms.<id>.<path> = true/false）
// behavior: 非凭证字符串/列表行为项（platforms.<id>.<path>；list:true 表示逗号分隔多值）
const CHANNEL_DEFS = {
  telegram: {
    name: "Telegram", icon: "✈️", qrLogin: true,
    fields: [
      { env: "TELEGRAM_BOT_TOKEN", path: "token", label: "Bot Token", placeholder: "（扫码创建机器人后自动填入，也可手动输入 BotFather Token）", secret: true },
      { env: "TELEGRAM_PROXY", path: "proxy", label: "代理 (可选)", placeholder: "socks5://127.0.0.1:7890" },
    ],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" }, { path: "reactions", label: "启用消息反应" } ],
    behavior: [
      { path: "free_response_chats", label: "自由回复的会话 (多个用逗号分隔)", placeholder: "chat_id1,chat_id2" },
      { path: "mention_patterns", label: "提及匹配规则 (正则，多个用逗号分隔)", placeholder: "@hermes,hermes" },
    ],
    note: "Telegram 支持「扫码创建机器人」自动获取 Token（调用 Nous 托管服务），也支持手动填入 BotFather 创建的 Token。",
  },
  discord: {
    name: "Discord", icon: "🎮",
    fields: [
      { env: "DISCORD_BOT_TOKEN", path: "token", label: "Bot Token", placeholder: "Bot token...", secret: true },
      { env: "DISCORD_PROXY", path: "proxy", label: "代理 (可选)", placeholder: "socks5://127.0.0.1:7890" },
    ],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" }, { path: "auto_thread", label: "自动线程" }, { path: "reactions", label: "启用反应" } ],
    behavior: [
      { path: "free_response_channels", label: "自由回复的频道 (多个用逗号分隔)", placeholder: "channel_id1,channel_id2" },
      { path: "allowed_channels", label: "仅允许的频道 (多个用逗号分隔，留空=全部)", placeholder: "channel_id1,channel_id2" },
      { path: "ignored_channels", label: "忽略的频道 (多个用逗号分隔)", placeholder: "channel_id1,channel_id2" },
      { path: "no_thread_channels", label: "不创建线程的频道 (多个用逗号分隔)", placeholder: "channel_id1,channel_id2" },
    ],
  },
  slack: {
    name: "Slack", icon: "💼",
    fields: [ { env: "SLACK_BOT_TOKEN", path: "token", label: "Bot Token", placeholder: "xoxb-...", secret: true } ],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" }, { path: "allow_bots", label: "允许机器人消息" } ],
    behavior: [
      { path: "free_response_channels", label: "自由回复的频道 (多个用逗号分隔)", placeholder: "channel_id1,channel_id2" },
    ],
  },
  whatsapp: {
    name: "WhatsApp", icon: "💬", qrLogin: true,
    fields: [],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" } ],
    behavior: [
      { path: "free_response_chats", label: "自由回复的会话 (多个用逗号分隔)", placeholder: "chat_id1,chat_id2" },
      { path: "mention_patterns", label: "提及匹配规则 (正则，多个用逗号分隔)", placeholder: "@hermes,hermes" },
    ],
    note: "WhatsApp 通过本地 Baileys bridge 扫码配对。选择「独立号码」或「自用号码」模式，用 WhatsApp 扫描弹出的二维码即可完成关联。",
  },
  matrix: {
    name: "Matrix", icon: "🔷",
    fields: [
      { env: "MATRIX_ACCESS_TOKEN", path: "token", label: "Access Token", placeholder: "syt_...", secret: true },
      { env: "MATRIX_PROXY", path: "proxy", label: "代理 (可选)", placeholder: "socks5://127.0.0.1:7890" },
      { env: "MATRIX_HOMESERVER", path: "extra.homeserver", label: "Homeserver", placeholder: "https://matrix.org" },
      { env: "MATRIX_USER_ID", path: "extra.user_id", label: "User ID (可选)", placeholder: "@user:matrix.org" },
    ],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" }, { path: "auto_thread", label: "自动线程" }, { path: "dm_mention_thread", label: "私信提及线程" } ],
    behavior: [
      { path: "extra.password", label: "密码 (Password，可选)", placeholder: "Matrix 密码", type: "password" },
      { path: "free_response_rooms", label: "自由回复的房间 (多个用逗号分隔)", placeholder: "room_id1,room_id2" },
    ],
  },
  feishu: {
    name: "飞书 (Lark)", icon: "🪽",
    fields: [
      { env: "FEISHU_APP_ID", path: "extra.app_id", label: "App ID", placeholder: "cli_..." },
      { env: "FEISHU_APP_SECRET", path: "extra.app_secret", label: "App Secret", placeholder: "...", secret: true },
      { env: "FEISHU_ENCRYPT_KEY", path: "extra.encrypt_key", label: "Encrypt Key (可选)", placeholder: "..." },
      { env: "FEISHU_VERIFICATION_TOKEN", path: "extra.verification_token", label: "Verification Token (可选)", placeholder: "..." },
    ],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" } ],
    behavior: [
      { path: "free_response_chats", label: "自由回复的会话 (多个用逗号分隔)", placeholder: "chat_id1,chat_id2" },
    ],
  },
  dingtalk: {
    name: "钉钉 (DingTalk)", icon: "🔔",
    fields: [
      { env: "DINGTALK_CLIENT_ID", path: "extra.client_id", label: "Client ID (AppKey)", placeholder: "ding..." },
      { env: "DINGTALK_CLIENT_SECRET", path: "extra.client_secret", label: "Client Secret (AppSecret)", placeholder: "...", secret: true },
      { env: "DINGTALK_APP_KEY", path: "extra.app_key", label: "App Key (可选)", placeholder: "..." },
    ],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" }, { path: "allow_all_users", label: "允许所有用户" } ],
    behavior: [
      { path: "extra.card_template_id", label: "AI 卡片模板 ID (可选)", placeholder: "Card Template ID" },
      { path: "allowed_users", label: "允许的用户 (多个用逗号分隔，留空=仅创建者)", placeholder: "user_id1,user_id2" },
      { path: "free_response_chats", label: "自由回复的会话 (多个用逗号分隔)", placeholder: "chat_id1,chat_id2" },
    ],
  },
  qqbot: {
    name: "QQ 机器人 (QQBot)", icon: "🐧", qrLogin: true,
    fields: [
      { env: "QQ_APP_ID", path: "extra.app_id", label: "App ID", placeholder: "q.qq.com 注册应用后获得" },
      { env: "QQ_CLIENT_SECRET", path: "extra.client_secret", label: "Client Secret", placeholder: "...", secret: true },
      { env: "QQ_STT_API_KEY", path: "extra.stt.apiKey", label: "STT 语音转文字 Key (可选)", placeholder: "GLM-ASR 或 Whisper Key", secret: true },
      { env: "QQ_STT_PROVIDER", path: "extra.stt.provider", label: "STT 提供商 (可选)", placeholder: "zai（GLM-ASR）/ openai" },
      { env: "QQ_STT_BASE_URL", path: "extra.stt.baseUrl", label: "STT Base URL (可选)", placeholder: "https://open.bigmodel.cn/api/coding/paas/v4" },
      { env: "QQ_STT_MODEL", path: "extra.stt.model", label: "STT 模型 (可选)", placeholder: "glm-asr" },
    ],
    toggles: [ { path: "allow_all_users", label: "允许所有用户" }, { path: "qq_markdown", label: "使用 Markdown 消息" } ],
    behavior: [
      { path: "allowed_users", label: "允许的用户 (多个用逗号分隔，留空=仅创建者)", placeholder: "openid1,openid2" },
    ],
    note: "QQ 机器人：q.qq.com 注册应用获取 App ID/Secret；语音消息优先走 QQ 内置 ASR（免费），可配 GLM-ASR 备用。",
  },
  weixin: {
    name: "微信 (WeChat)", icon: "💬",
    qrLogin: true,
    fields: [
      { env: "WEIXIN_TOKEN", path: "token", label: "Token", placeholder: "（扫码登录后自动填入）", secret: true },
      { env: "WEIXIN_ACCOUNT_ID", path: "extra.account_id", label: "Account ID", placeholder: "（扫码登录后自动填入）" },
      { env: "WEIXIN_BASE_URL", path: "extra.base_url", label: "Base URL (可选)", placeholder: "默认 https://ilinkai.weixin.qq.com" },
      { env: "WEIXIN_CDN_BASE_URL", path: "extra.cdn_base_url", label: "CDN Base URL (可选)", placeholder: "默认 https://novac2c.cdn.weixin.qq.com/c2c" },
      { env: "WEIXIN_DM_POLICY", path: "extra.dm_policy", label: "私信策略", placeholder: "open / allowlist / disabled / pairing" },
      { env: "WEIXIN_GROUP_POLICY", path: "extra.group_policy", label: "群组策略", placeholder: "open / allowlist / disabled（默认 disabled）" },
      { env: "WEIXIN_ALLOWED_USERS", path: "extra.allow_from", label: "私信白名单 (逗号分隔)", placeholder: "user_id1,user_id2（dm_policy=allowlist 时生效）" },
      { env: "WEIXIN_GROUP_ALLOWED_USERS", path: "extra.group_allow_from", label: "群组白名单 (逗号分隔群 ID)", placeholder: "group_id1,group_id2（group_policy=allowlist 时生效）" },
      { env: "WEIXIN_HOME_CHANNEL", path: "extra.home_channel", label: "Home Channel (cron/通知投递聊天 ID)", placeholder: "可选" },
      { env: "WEIXIN_HOME_CHANNEL_NAME", path: "extra.home_channel_name", label: "Home Channel 名称", placeholder: "Home" },
    ],
    toggles: [
      { path: "require_mention", label: "需 @提及 才回复" },
      { path: "extra.split_multiline_messages", label: "多行回复拆分为多条消息（旧版行为）" },
    ],
    behavior: [
      { path: "extra.dm_policy", label: "私信策略", placeholder: "open / allowlist / disabled / pairing" },
      { path: "extra.group_policy", label: "群组策略", placeholder: "open / allowlist / disabled" },
    ],
    note: "微信个人号通过腾讯 iLink 扫码登录。支持图片/文件/视频/语音、Markdown、4000 字符分块、AES 加密 CDN。私信默认 open，群组默认 disabled（iLink 限制）。",
  },
  wecom: {
    name: "企业微信 (WeCom)", icon: "💼", qrLogin: true,
    fields: [
      { env: "WECOM_BOT_ID", path: "extra.bot_id", label: "Bot ID", placeholder: "（扫码授权后自动填入）" },
      { env: "WECOM_SECRET", path: "extra.secret", label: "Secret", placeholder: "（扫码授权后自动填入）", secret: true },
      { env: "WECOM_CORP_ID", path: "extra.corp_id", label: "Corp ID (可选)", placeholder: "传统自建应用模式才需要" },
      { env: "WECOM_AGENT_ID", path: "extra.agent_id", label: "Agent ID (可选)", placeholder: "传统自建应用模式才需要" },
    ],
    toggles: [ { path: "require_mention", label: "需 @提及 才回复" } ],
    note: "企业微信「AI 智能机器人」扫码授权：点下方「企业微信扫码登录」，用企业微信扫码后在手机端确认，Bot ID / Secret 自动填入（与 Octop 一致，无需自备 Corp ID）。",
  },
  signal: {
    name: "Signal", icon: "🔐",
    fields: [
      { env: "SIGNAL_ACCOUNT", path: "extra.account", label: "Signal 账号/号码", placeholder: "+8613800000000" },
      { env: "SIGNAL_HTTP_URL", path: "extra.http_url", label: "signal-cli REST API URL", placeholder: "http://127.0.0.1:8080" },
      { env: "SIGNAL_ALLOWED_USERS", path: "extra.allowed_users", label: "私信白名单 (逗号分隔)", placeholder: "user_id1,user_id2" },
      { env: "SIGNAL_GROUP_ALLOWED_USERS", path: "extra.group_allowed_users", label: "群组白名单 (逗号分隔)", placeholder: "group1,group2" },
    ],
    toggles: [ { path: "extra.reactions", label: "启用表情反应" }, { path: "extra.require_mention", label: "需 @提及 才回复" } ],
    note: "Signal：需本地 signal-cli 服务（SIGNAL_HTTP_URL）。支持图片/文件/流式输出。",
  },
  yuanbao: {
    name: "腾讯元宝", icon: "🧧",
    fields: [
      { env: "YUANBAO_DM_POLICY", path: "extra.dm_policy", label: "私信策略", placeholder: "open / allowlist / disabled" },
      { env: "YUANBAO_GROUP_POLICY", path: "extra.group_policy", label: "群组策略", placeholder: "open / allowlist / disabled" },
      { env: "YUANBAO_DM_ALLOW_FROM", path: "extra.dm_allow_from", label: "私信白名单", placeholder: "逗号分隔" },
      { env: "YUANBAO_GROUP_ALLOW_FROM", path: "extra.group_allow_from", label: "群组白名单", placeholder: "逗号分隔" },
      { env: "YUANBAO_HOME_CHANNEL", path: "extra.home_channel", label: "Home Channel", placeholder: "cron/通知投递目标" },
    ],
    toggles: [ { path: "extra.allow_all_users", label: "允许所有用户" } ],
    note: "腾讯元宝渠道：支持语音/图片/文件/流式输出。",
  },
  bluebubbles: {
    name: "BlueBubbles (iMessage)", icon: "💬",
    fields: [
      { env: "BLUEBUBBLES_SERVER_URL", path: "extra.server_url", label: "BlueBubbles Server URL", placeholder: "http://127.0.0.1:1234" },
      { env: "BLUEBUBBLES_WEBHOOK_HOST", path: "extra.webhook_host", label: "Webhook Host", placeholder: "0.0.0.0" },
      { env: "BLUEBUBBLES_WEBHOOK_PATH", path: "extra.webhook_path", label: "Webhook Path", placeholder: "/bluebubbles" },
      { env: "BLUEBUBBLES_WEBHOOK_PORT", path: "extra.webhook_port", label: "Webhook Port", placeholder: "8099" },
    ],
    toggles: [ { path: "extra.require_mention", label: "需 @提及 才回复" } ],
    note: "BlueBubbles：通过 BlueBubbles 接入 iMessage，支持图片/文件/表情反应。",
  },
  google_chat: {
    name: "Google Chat", icon: "💬",
    fields: [
      { env: "GOOGLE_CHAT_SERVICE_ACCOUNT", path: "extra.service_account", label: "Service Account JSON 路径", placeholder: "/path/to/service-account.json" },
      { env: "GOOGLE_CHAT_SPACE_ID", path: "extra.space_id", label: "Space ID", placeholder: "spaces/xxx" },
    ],
    note: "Google Chat：需 Google Cloud Service Account。支持图片/文件/线程。以 Hermes 官方文档为准。",
  },
  sms: {
    name: "SMS (Twilio)", icon: "📱",
    fields: [
      { env: "TWILIO_ACCOUNT_SID", path: "extra.account_sid", label: "Twilio Account SID", placeholder: "AC..." },
      { env: "TWILIO_AUTH_TOKEN", path: "extra.auth_token", label: "Twilio Auth Token", placeholder: "...", secret: true },
      { env: "TWILIO_FROM", path: "extra.from_number", label: "发送号码", placeholder: "+1..." },
    ],
    note: "SMS：通过 Twilio 收发短信，基础文本消息。",
  },
  email: {
    name: "Email", icon: "✉️",
    fields: [
      { env: "EMAIL_IMAP_HOST", path: "extra.imap_host", label: "IMAP 服务器", placeholder: "imap.qq.com" },
      { env: "EMAIL_IMAP_PORT", path: "extra.imap_port", label: "IMAP 端口", placeholder: "993" },
      { env: "EMAIL_IMAP_USER", path: "extra.imap_user", label: "IMAP 用户名", placeholder: "you@example.com" },
      { env: "EMAIL_IMAP_PASSWORD", path: "extra.imap_password", label: "IMAP 密码/授权码", placeholder: "...", secret: true },
      { env: "EMAIL_SMTP_HOST", path: "extra.smtp_host", label: "SMTP 服务器", placeholder: "smtp.qq.com" },
      { env: "EMAIL_SMTP_PORT", path: "extra.smtp_port", label: "SMTP 端口", placeholder: "465" },
      { env: "EMAIL_SMTP_USER", path: "extra.smtp_user", label: "SMTP 用户名", placeholder: "you@example.com" },
      { env: "EMAIL_SMTP_PASSWORD", path: "extra.smtp_password", label: "SMTP 密码/授权码", placeholder: "...", secret: true },
    ],
    note: "Email：IMAP 收信 + SMTP 发信，支持图片/文件/线程。",
  },
  mattermost: {
    name: "Mattermost", icon: "🔗",
    fields: [
      { env: "MATTERMOST_SERVER", path: "extra.server", label: "Mattermost 服务器", placeholder: "https://mattermost.example.com" },
      { env: "MATTERMOST_TOKEN", path: "extra.token", label: "访问 Token", placeholder: "...", secret: true },
      { env: "MATTERMOST_TEAM", path: "extra.team", label: "团队名", placeholder: "team" },
      { env: "MATTERMOST_CHANNEL", path: "extra.channel", label: "默认频道", placeholder: "town-square" },
    ],
    note: "Mattermost：支持语音/图片/文件/线程。",
  },
  teams: {
    name: "Microsoft Teams", icon: "🧩",
    fields: [
      { env: "TEAMS_APP_ID", path: "extra.app_id", label: "App ID", placeholder: "..." },
      { env: "TEAMS_APP_PASSWORD", path: "extra.app_password", label: "App Password", placeholder: "...", secret: true },
      { env: "TEAMS_TENANT_ID", path: "extra.tenant_id", label: "Tenant ID", placeholder: "..." },
    ],
    note: "Microsoft Teams：支持图片/线程/输入提示。",
  },
  homeassistant: {
    name: "Home Assistant", icon: "🏠",
    fields: [
      { env: "HOME_ASSISTANT_URL", path: "extra.url", label: "HA 地址", placeholder: "http://homeassistant.local:8123" },
      { env: "HOME_ASSISTANT_TOKEN", path: "extra.token", label: "长期访问 Token", placeholder: "...", secret: true },
    ],
    note: "Home Assistant：集成 HA，并提供 HA 设备控制工具。",
  },
  webhooks: {
    name: "Webhooks", icon: "🔗",
    fields: [
      { env: "WEBHOOK_SECRET", path: "extra.secret", label: "Webhook Secret", placeholder: "...", secret: true },
      { env: "WEBHOOK_PATH", path: "extra.path", label: "Webhook 路径", placeholder: "/webhook" },
    ],
    note: "Webhooks：接收 Webhook 消息，支持完整工具。",
  },
};

// ─── Node.js 运行时探测（hermes TUI 需要 node；版本在安装期由 install_callback 固定） ───

// 解析 Node 二进制：① 打包内置路径 → ② 系统 nodejs 运行时（fnOS 应用中心） → ③ PATH 探测
function _findNodeInPath() {
  try {
    const r = spawnSync("sh", ["-c", "command -v node"], { stdout: "pipe", stderr: "pipe" });
    const out = (r.stdout || "").toString().trim();
    if (out && existsSync(out) && (statSync(out).mode & 0o111) !== 0) return out;
  } catch {}
  return null;
}
const NODE_CANDIDATES = [
  `${APP_DIR}/runtime/node/bin/node`,            // ① 打包内置（最高优先）
  `${DATA_DIR}/node/bin/node`,                   // ② 安装期 ensure_node 下载并固定的路径
  "/var/apps/nodejs_v24/target/bin/node",        // ③ fnOS 应用中心 Node.js v24
  "/var/apps/nodejs_v22/target/bin/node",        // ④ fnOS 应用中心 Node.js v22
  "/var/apps/nodejs_v20/target/bin/node",        // ⑤ fnOS 应用中心 Node.js v20
  "/var/apps/nodejs/target/bin/node",            // ⑥ 通用 nodejs 路径
];
const resolvedNodeBin = NODE_CANDIDATES.find(p => {
  try { return existsSync(p) && (statSync(p).mode & 0o111) !== 0; } catch { return false; }
}) || _findNodeInPath();
const resolvedNodeDir = resolvedNodeBin ? resolvedNodeBin.replace(/\/[^/]+$/, "") : null;

// ─── 通讯平台 QR 扫码登录相关常量 ────────────────────────────────────────
const TELEGRAM_ONBOARDING_URL = (process.env.TELEGRAM_ONBOARDING_URL || "https://setup.hermes-agent.nousresearch.com").replace(/\/+$/,"");
const WHATSAPP_SESSION_DIR    = `${DATA_DIR}/whatsapp/session`;
const WHATSAPP_ONBOARDING_TTL = 600000; // 10 分钟（与官方一致）
const _telegramPairings = new Map(); // pairing_id -> {poll_token, expires_at_ts, bot_token, bot_username, owner_user_id}
const _whatsappPairings = new Map(); // pairing_id -> {proc, status, qr_payload, mode, account_id, account_name, account_phone, error, expires_at_ts}
const _wecomQrCache = new Map();      // scode -> {ts, bot_id, secret}（腾讯 ai/qc 接口扫码结果缓存，3s TTL）
let _gwRestartTimer = null;            // 网关重启防抖定时器（模块级，handleFetch 内声明会被每请求重置）
let _gwRestartInProgress = false;      // 网关重启进行中标志（防止并发重启互相杀死对方）
const _qqQrCache = new Map();               // QQ 扫码绑定任务缓存（模块级）

// ─── 定时任务 Webhook 出站投递配置 ──────────────────────────────────────
// hermes cron 原生 deliver 只支持内置通道（weixin/telegram/dingtalk/feishu/wecom 等），
// 不支持出站 Webhook POST。本包在 monitor 侧实现：创建任务时把 webhook 投递目标
// 写入 CRON_WEBHOOKS_FILE，后台轮询 jobs.json 的 last_run_at 变化，新输出 POST 到
// 企微机器人/钉钉机器人等任意 webhook 地址（body 兼容 {"msgtype":"text"} 与纯文本）。
// 结构：{ "<job_id>": [ { url, message, label, last_run_at, last_status, last_error } ] }
const CRON_WEBHOOKS_FILE = `${DATA_DIR}/cron-webhooks.json`;
const panelCronHooks = new CronHooks(join(VAR_DIR, 'panel-state/cron-webhooks.json'), CRON_WEBHOOKS_FILE);

// ─── HERMES_TUI_DIR：TUI 运行时 shim 目录 ──────────────────────────────
const TUI_DIR = `${DATA_DIR}/tui`;

// ─── 聊天数据路径（持久化于 VAR_DIR → /vol1/@appdata/） ────────────────
const CHAT_DIR      = `${VAR_DIR}/chat`;
const CONFIG_FILE   = `${CHAT_DIR}/config.json`;
const SESSIONS_DIR  = `${CHAT_DIR}/sessions`;
const ARCHIVED_SESSIONS_DIR = `${CHAT_DIR}/archived-sessions`;

// ─── Web Push：未读角标 + 新回复通知（2026-11-20）───
// 未读 = 助手完成一条回复；靠监听 chat/sessions 的文件变化判定，不轮询、不改 Python 侧。
const pushHub = createPushHub({
  stateDir: `${VAR_DIR}/panel-state`,
  sessionsDir: SESSIONS_DIR,
  log: (msg) => { try { log(`[push] ${msg}`); } catch (e) {} },
});

// ─── 客户端取证收件箱（2026-11-20）───
// iPhone 专有的「切会话上下闪动」在无头浏览器里复现不出来，只能真机抓现场落 JSON。
const clientDiag = createClientDiag({
  dataDir: DATA_DIR,
  log: (msg) => { try { log(`[diag] ${msg}`); } catch (e) {} },
});
const TMP_DIR       = `${VAR_DIR}/tmp`;
const UPLOAD_DIR      = `${DATA_DIR}/uploads`;
const UPLOAD_IMG_DIR  = `${UPLOAD_DIR}/images`;
const UPLOAD_FILE_DIR = `${UPLOAD_DIR}/files`;
const WORKSPACE_DIR   = `${DATA_DIR}/workspace`;
const GATEWAY_API   = `http://localhost:${GATEWAY_PORT}/v1`;
const DASHBOARD_BIND = "127.0.0.1";

// ─── MCP stdio 桥接脚本：让 Hermes 网关通过 stdio 传输调用 gateway 模式连接器 ───
const MCP_BRIDGE_SCRIPT = `${VAR_DIR}/mcp-stdio-bridge.js`;
// 连接器凭证状态文件（模块级定义：模块级 MCP 自动注册必须能直接访问，不能放在 handleFetch 内部）
const CONNECTORS_STATE = `${DATA_DIR}/connectors-state.json`;
const panelConnectorStore = new ConnectorStore(join(VAR_DIR, "panel-state"), CONNECTORS_STATE);
function _ensureMcpBridgeScript() {
  try {
    const script = [
      '// MCP stdio bridge: reads JSON-RPC from stdin, forwards to monitor HTTP, writes to stdout',
      'const http = require("http");',
      'const fs = require("fs");',
      'const tokenFile = ' + JSON.stringify(TOKEN_FILE) + ';',
      'const kind = process.argv[2];',
      'const port = parseInt(process.argv[3] || "8650", 10);',
      'const url = "http://127.0.0.1:" + port + "/mcp-proxy/" + kind;',
      'function forward(body) {',
      '  return new Promise(function(resolve, reject) {',
      '    var data = JSON.stringify(body);',
      '    var u = new URL(url);',
      '    var token = fs.readFileSync(tokenFile, "utf8").trim();',
      '    var opts = { hostname: u.hostname, port: u.port, path: u.pathname, method: "POST", headers: { "Content-Type": "application/json", "X-Monitor-Token": token, "Content-Length": Buffer.byteLength(data) } };',
      '    var req = http.request(opts, function(res) {',
      '      var chunks = [];',
      '      res.on("data", function(c) { chunks.push(c); });',
      '      res.on("end", function() { resolve(Buffer.concat(chunks).toString("utf8")); });',
      '    });',
      '    req.on("error", function(e) { reject(e); });',
      '    req.write(data); req.end();',
      '  });',
      '}',
      'var buf = "";',
      'process.stdin.setEncoding("utf8");',
      'process.stdin.on("data", function(chunk) {',
      '  buf += chunk;',
      '  var lines = buf.split("\\n"); buf = lines.pop() || "";',
      '  lines.forEach(function(line) {',
      '    line = line.trim(); if (!line) return;',
      '    var msg; try { msg = JSON.parse(line); } catch(e) { return; }',
      '    forward(msg).then(function(resp) {',
      '      if (resp && resp.trim()) process.stdout.write(resp.trim() + "\\n");',
      '    }).catch(function(e) {',
      '      if (msg.id != null) process.stdout.write(JSON.stringify({jsonrpc:"2.0",id:msg.id,error:{code:-32603,message:e.message}}) + "\\n");',
      '    });',
      '  });',
      '});',
      'process.stdin.on("end", function() { process.exit(0); });',
    ].join("\n");
    writeFileSync(MCP_BRIDGE_SCRIPT, script, { mode: 0o755 });
  } catch (e) { log("[MCP-BRIDGE] failed to write bridge script: " + e.message); }
}

// 模块级桥接变量：handleFetch 内部赋值，startServer 的 setTimeout 调用
let _autoRegisterGatewayMcpFn = null;

// 模块级：替换 config.yaml 顶层键（兼容 inline `key: {}` 与 block 形态），删除全部重复键
// hermes 官方模板用 inline 形态（如 `mcp_servers: {}`），旧版行级匹配无法命中，
// 导致每次写入都追加新块、config.yaml 被重复顶层键污染（网关解析异常 + 注册失效）。
function _replaceTopLevelKey(raw, key, block) {
  if (!raw) return block;
  const lines = raw.split("\n");
  const idx = [];
  lines.forEach(function (l, i) {
    if (/^\s/.test(l)) return;
    if (l === key + ":" || l.startsWith(key + ":")) idx.push(i);
  });
  if (idx.length === 0) return (raw.endsWith("\n") || raw === "") ? raw + block : raw + "\n" + block;
  const out = [];
  let inserted = false;
  for (let i = 0; i < lines.length; i++) {
    if (idx.indexOf(i) !== -1) {
      if (i === idx[0] && !inserted) { out.push(block); inserted = true; }
      if (lines[i] === key + ":") { let j = i + 1; while (j < lines.length && (lines[j].startsWith(" ") || lines[j].startsWith("\t"))) j++; i = j - 1; }
      continue;
    }
    out.push(lines[i]);
  }
  return out.join("\n");
}

// Only conn-* entries belong to this panel. Native/user MCP definitions keep
// their exact YAML types and nested settings, even on the periodic repair path.
function _moduleLevelAutoRegisterMcp() {
  try {
    const st=panelConnectorStore.all(),entries={};
    for(const cat of CONNECTOR_CATALOG){
      if(cat.mcp_mode!=="gateway")continue;
      const credentials=st[cat.kind]||{};
      if(!(cat.fields||[]).every(field=>!!credentials[field.key]))continue;
      entries["conn-"+cat.kind]={command:resolvedNodeBin||"node",args:[MCP_BRIDGE_SCRIPT,cat.kind,String(UI_PORT)]};
    }
    const result=configTransaction({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),
      state:join(VAR_DIR,'panel-state'),file:HERMES_CONFIG,body:{action:'managed_mcp',entries,reason:'连接器注册核对'}});
    if(result.changed)log(`[MCP-BRIDGE] 已核对 ${Object.keys(entries).length} 个面板连接器，其余MCP配置保留`);
  }catch(error){log('[MCP-BRIDGE] 注册未完成，原配置保留: '+error.message);}
}
// 定期自愈：mcp_servers 被外部写操作（hermes 保存配置等）抹掉/覆盖时自动补回，
// 解决连接器工具"过一段时间消失"的问题
setInterval(function(){ try { _moduleLevelAutoRegisterMcp(); } catch (e) {} }, 180000);
_ensureMcpBridgeScript();
_moduleLevelAutoRegisterMcp();

// ─── API Key 自动生成（12位随机字母数字）─────────────────────────────────────
function generateApiKey() {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  const bytes = randomBytes(12);
  let key = "";
  for (let i = 0; i < 12; i++) key += chars[bytes[i] % chars.length];
  return key;
}

mkdirSync(VAR_DIR, { recursive: true });
initChatData();
// No startup migration of user configuration.

// ─── TUI shim 初始化：确保 TUI_DIR/dist/entry.js 可用 ──────────────────
try {
  mkdirSync(`${TUI_DIR}/dist`, { recursive: true });
  const tuiEntry = `${TUI_DIR}/dist/entry.js`;
  if (!existsSync(tuiEntry)) {
    // 动态探测候选项（不硬编码 python 版本）：
    // ① 旧版 wheel 模式：hermes_cli/tui_dist/entry.js（0.19.0）
    // ② v0.20.0 源码模式：hermes-src/ui-tui/dist/entry.js（打包时预构建）
    const pyResult = spawnSync(
      `${VENV_BIN}/${PY_BIN}`, ["-c", "import hermes_cli,os;print(os.path.dirname(hermes_cli.__file__))"],
      { stdout: "pipe", stderr: "pipe" }
    );
    const hermesCli = pyResult.stdout?.toString().trim();
    const candidates = [];
    if (hermesCli) candidates.push(`${hermesCli}/tui_dist/entry.js`);
    candidates.push(`${APP_DIR}/hermes-src/ui-tui/dist/entry.js`);
    let linked = null;
    for (const cand of candidates) {
      if (cand && existsSync(cand)) { linked = cand; break; }
    }
    if (linked) {
      try { unlinkSync(tuiEntry); } catch {}
      symlinkSync(linked, tuiEntry);
      console.log(`[monitor] tui symlink: ${tuiEntry} -> ${linked}`);
    } else {
      console.log("[monitor] WARNING: TUI bundle not found (checked hermes_cli/tui_dist and hermes-src/ui-tui/dist), TUI may rely on bundled fallback");
    }
  }
} catch (e) {
  console.log(`[monitor] WARNING: TUI shim init failed (${e.message}), non-fatal`);
}

// Existing application services are adopted by exact argv + PID incarnation.
// Startup never kills a process merely because it matches a name or PID file.
const serviceProcesses=createServiceProcesses({hermesBin:HERMES_BIN,venvBin:VENV_BIN,pidFiles:{gateway:PID_GATEWAY,dashboard:PID_DASHBOARD}});
function readPidSync(path){return readPid(path);}
function pidAliveSync(pid){return pidAlive(pid);}

function formatHermesVersion(raw) {
  if (!raw) return "unknown";
  const verMatch = raw.match(/(\d+\.\d+\.\d+)/);
  const dateMatch = raw.match(/(\d{4})[-.\/](\d{1,2})[-.\/](\d{1,2})/);
  if (!verMatch) return raw.trim().split("\n")[0].slice(0, 64) || "unknown";
  let out = `v${verMatch[1]}`;
  if (dateMatch) {
    const y = dateMatch[1], m = Number(dateMatch[2]), d = Number(dateMatch[3]);
    out += ` (${y}.${m}.${d})`;
  }
  return out;
}
let HERMES_VERSION = "unknown";
try {
  // 优先读缓存文件（瞬间完成），让服务器尽快启动
  if (existsSync(VERSION_FILE)) {
    const cached = readFileSync(VERSION_FILE, "utf8").trim();
    if (cached) HERMES_VERSION = cached;
  }
  // 缓存没有时才执行 hermes --version（可能耗时数秒）
  if (HERMES_VERSION === "unknown") {
    // spawnSync 已在顶部从 child_process 导入
    const verResult = spawnSync(HERMES_BIN, ["--version"], { stdout: "pipe", stderr: "pipe" });
    const verOut = ((verResult.stdout ? verResult.stdout.toString() : "").trim())
                || ((verResult.stderr ? verResult.stderr.toString() : "").trim());
    if (verOut) {
      HERMES_VERSION = formatHermesVersion(verOut);
      try { writeFileSync(VERSION_FILE, HERMES_VERSION, { mode: 0o644 }); } catch {}
    }
  }
  // 后台异步刷新版本（解决升级后缓存文件仍是旧版本号的问题）
  setTimeout(() => {
    try {
      // spawnSync 已在顶部从 child_process 导入
      const r = spawnSync(HERMES_BIN, ["--version"], { stdout: "pipe", stderr: "pipe" });
      const out = ((r.stdout ? r.stdout.toString() : "").trim())
               || ((r.stderr ? r.stderr.toString() : "").trim());
      if (out) {
        const realVer = formatHermesVersion(out);
        if (realVer !== HERMES_VERSION) {
          HERMES_VERSION = realVer;
          try { writeFileSync(VERSION_FILE, realVer, { mode: 0o644 }); } catch {}
          log(`版本已刷新: ${realVer}`);
        }
      }
    } catch {}
  }, 3000);
} catch {
  try {
    if (existsSync(VERSION_FILE)) {
      const cached = readFileSync(VERSION_FILE, "utf8").trim();
      if (cached) HERMES_VERSION = cached;
    }
  } catch {}
}
log(`[启动检测] Hermes Agent 版本: ${HERMES_VERSION}`);

// ─── 启动令牌（写入 VAR_DIR 供本机 CLI/脚本读取）────────────────────────────
const MONITOR_TOKEN = (() => {
  try {
    if (existsSync(TOKEN_FILE)) return readFileSync(TOKEN_FILE, "utf8").trim();
  } catch {}
  const t = randomBytes(24).toString("hex");
  writeFileSync(TOKEN_FILE, t, { mode: 0o600 });
  return t;
})();

// ─── 仪表盘会话令牌（与仪表盘共享，代理转发时免 401 鉴权）──────────────────
// monitor 生成并固定写入文件；启动仪表盘时注入 HERMES_DASHBOARD_SESSION_TOKEN，
// 转发 /proxy/dashboard/* 时携带 X-Hermes-Session-Token，使原生 /api/* 调用免鉴权。
const DASHBOARD_TOKEN_FILE = `${VAR_DIR}/dashboard.token`;
const DASHBOARD_SESSION_TOKEN = (() => {
  try {
    if (existsSync(DASHBOARD_TOKEN_FILE)) return readFileSync(DASHBOARD_TOKEN_FILE, "utf8").trim();
  } catch {}
  const t = randomBytes(24).toString("hex");
  writeFileSync(DASHBOARD_TOKEN_FILE, t, { mode: 0o600 });
  return t;
})();

const panelAuth = new PanelAuth({file:join(VAR_DIR,'panel-state/auth.json'),legacyToken:MONITOR_TOKEN,basePath:BASE_PATH});
function checkToken(req) { return !!panelAuth.valid(req); }


const HERMES_TOKEN_MIRROR = `${DATA_DIR}/.monitor_token`;
function syncTokenToHermesHome() {
  try { writeFileSync(HERMES_TOKEN_MIRROR, MONITOR_TOKEN, { mode: 0o600 }); }
  catch (e) { log(`同步 token 到 Hermes home 失败: ${e?.message || e}`); }
}
syncTokenToHermesHome();

function initChatData() {
  mkdirSync(CHAT_DIR, { recursive: true });
  mkdirSync(SESSIONS_DIR, { recursive: true });
  mkdirSync(ARCHIVED_SESSIONS_DIR, { recursive: true });
  mkdirSync(TMP_DIR, { recursive: true });
  mkdirSync(UPLOAD_IMG_DIR, { recursive: true });
  mkdirSync(UPLOAD_FILE_DIR, { recursive: true });
  mkdirSync(WORKSPACE_DIR, { recursive: true });
  // Legacy chat/config.json is retained verbatim; model reads use Gateway YAML.

}

// ── 启动迁移：强制 display.final_response_markdown = gfm（Issue #12）────────
// 旧版本默认 strip，会导致网关剥离所有 Markdown 格式；升级后自动修正。
function readJSON(path) {
  return JSON.parse(readFileSync(path, "utf-8"));
}
function writeJSON(path, data, pretty) {
  writeFileSync(path, pretty ? JSON.stringify(data, null, 2) : JSON.stringify(data));
  try { chmodSync(path, 0o600); } catch {}
}

// Model configuration is read-only here and shared with the model editor.
async function getChatConfig() {
  const result=await panelModels.execute({action:'read'});
  if(!result.ok)throw Error(result.error||'无法读取模型配置');
  return result;
}
async function getActiveProvider() { return resolveModelRoutes(await getChatConfig())[0]; }

// 模块级 YAML 顶层块提取（注意：handleFetch 内部另有一个同名嵌套的 _yamlBlockOf，
// 模块级代码不可访问，此处单独实现）
function _yamlTopBlock(yml, key) {
  const m = yml.match(new RegExp("^" + key + ":[ \\t]*\\n([\\s\\S]*?)(?=^[a-zA-Z_][\\w-]*:|$(?![\\s\\S]))", "m"));
  return m ? m[1] : "";
}

// 定位网关路由索引文件（sessions.json，legacy mirror of gateway_routing 表）。
// 网关实际 HERMES_HOME 可能与 monitor 的 DATA_DIR 不同（如 @appdata vs @apphome），
// 因此依次扫描候选路径，返回第一个存在的位置。
function _gatewayRoutingPath() {
  const candidates = [];
  try { candidates.push(`${DATA_DIR}/sessions/sessions.json`); } catch {}
  try {
    const passwd = readFileSync("/etc/passwd", "utf8");
    for (const line of passwd.split("\n")) {
      const m = line.match(/^(hermes[^:]*|fn_hermes[^:]*):[^:]*:[^:]*:[^:]*:[^:]*:([^:]+):/);
      if (m && m[2]) {
        candidates.push(`${m[2]}/data/sessions/sessions.json`);
        candidates.push(`${m[2]}/.hermes/sessions/sessions.json`);
      }
    }
  } catch {}
  for (const p of candidates) {
    try { if (existsSync(p)) return p; } catch {}
  }
  return null;
}

// 从网关路由索引提取指定平台的全部 chat_id（key 形如 agent:main:weixin:dm:<chat_id>）。
// 用于把通道级模型/系统提示写入网关唯一认的 channel_overrides[chat_id]。
function _gatewayChatIds(platformId) {
  try {
    const p = _gatewayRoutingPath();
    if (!p) return [];
    const raw = readFileSync(p, "utf8");
    const data = JSON.parse(raw);
    if (!data || typeof data !== "object") return [];
    const re = new RegExp("^agent:main:" + String(platformId).replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ":(dm|group|supergroup|thread):(.+)$");
    const ids = [];
    for (const k of Object.keys(data)) {
      const m = k.match(re);
      if (m && m[2]) ids.push(m[2]);
    }
    return [...new Set(ids)];
  } catch (e) { return []; }
}

// 定时同步通道级模型覆盖：网关 0.19 的 PlatformConfig 只认 channel_overrides（按 chat_id），
// 不认 platforms.<id>.model/profile 字段。因此凡配置了通道模型/系统提示的平台，
// 都要把覆盖同步到该平台全部已知 chat_id（含保存后新增的会话）。
function _syncChannelOverrides() {
  try {
    for (const chId of Object.keys(CHANNEL_DEFS)) {
      const cfg = _readPlatformConfig(chId);
      const model = cfg.model ? String(cfg.model).trim() : "";
      const sysPrompt = (cfg.system_prompt != null) ? String(cfg.system_prompt).trim() : "";
      if (!model && !sysPrompt) continue;
      const chatIds = _gatewayChatIds(chId);
      if (!chatIds.length) continue;
      const ov = (cfg.channel_overrides && typeof cfg.channel_overrides === "object") ? cfg.channel_overrides : {};
      let changed = false;
      chatIds.forEach(cid => {
        const cur = (ov[cid] && typeof ov[cid] === "object") ? ov[cid] : {};
        if (model && cur.model !== model) { cur.model = model; changed = true; }
        if (sysPrompt && cur.system_prompt !== sysPrompt) { cur.system_prompt = sysPrompt; changed = true; }
        ov[cid] = cur;
      });
      if (changed) {
        cfg.channel_overrides = ov;
        cfg.updated_at = Date.now();
        _writeHermesConfig(_setPlatformConfig(chId, cfg));
        log(`[ChannelOverride] 已同步 ${chId} 通道模型覆盖到 ${chatIds.length} 个会话 (model=${model}${sysPrompt ? " +sys_prompt" : ""})`);
      }
    }
  } catch (e) {}
}
function resolveChatProviders(cfg,modelOverride){ return resolveModelRoutes(cfg,modelOverride); }

function sessionFile(id) {
  safeId(id);
  return `${SESSIONS_DIR}/${id}.json`;
}
function archivedSessionFile(id) {
  safeId(id);
  return `${ARCHIVED_SESSIONS_DIR}/${id}.json`;
}
// ── 会话列表内存缓存：避免每次 /api/sessions 全量读盘 + JSON.parse 所有会话文件 ──
// 会话文件随对话增长（含全部消息），50 个会话 × 数百 KB 时每次同步解析可达秒级。
// saveSession/deleteSession 主动维护缓存（列表实时），TTL 仅作外部改动兜底。
let _sessionMetaCache = null;                 // { builtAt, map: Map<id,meta> }
const SESSION_META_TTL = 5000;                // ms，兜底重建周期
// 活跃 profile 内存缓存（模块级！handleFetch 每请求执行，若声明在函数内每次请求都会重置而失效）
let _activeProfileCache = null;
function _sessionMetaFromData(s) {
  /* 2026-11-13：列表圆点按「这条会话最后发生了什么」着色，元数据带上末条状态。
     只读数组尾元素，不额外解析，元数据缓存开销不变。 */
  const msgs = s.messages || [];
  const last = msgs.length ? msgs[msgs.length - 1] : null;
  const lastAssistant = last && last.role === 'assistant' ? last : null;
  return {
    id: s.id, title: s.title, created_at: s.created_at, updated_at: s.updated_at, message_count: msgs.length,
    last_role: last ? last.role : null,
    last_ts: last && last.ts ? last.ts : null,
    last_status: lastAssistant ? (lastAssistant.queue_status || 'done') : null,
    last_error_code: lastAssistant && lastAssistant.error_code ? lastAssistant.error_code : null,
    last_duration_ms: lastAssistant && lastAssistant.duration_ms ? lastAssistant.duration_ms : null,
  };
}
function _buildSessionMetaMap() {
  const map = new Map();
  try {
    const files = readdirSync(SESSIONS_DIR).filter(f => f.endsWith(".json"));
    files.forEach(f => {
      try {
        const s = readJSON(`${SESSIONS_DIR}/${f}`);
        if (s && s.group) return; // v0.21.103: 群聊/工作流内部会话不进入主对话列表
        const meta = _sessionMetaFromData(s);
        if (meta.id) map.set(meta.id, meta);
      } catch { /* 忽略损坏/不可读文件 */ }
    });
  } catch { /* 目录不可读时返回空 */ }
  return map;
}
function _buildArchivedMetaMap() {
  const map = new Map();
  try {
    const files = readdirSync(ARCHIVED_SESSIONS_DIR).filter(f => f.endsWith(".json"));
    files.forEach(f => { try { const s = readJSON(`${ARCHIVED_SESSIONS_DIR}/${f}`); if (s?.id) map.set(s.id, {..._sessionMetaFromData(s), archived: true}); } catch {} });
  } catch {}
  return map;
}
function listSessions() {
  const now = Date.now();
  if (!_sessionMetaCache || (now - _sessionMetaCache.builtAt) > SESSION_META_TTL) {
    _sessionMetaCache = { builtAt: now, map: _buildSessionMetaMap() };
  }
  /* 实时态叠加：running 只在内存（activeChatStreams），needs_input 看队列里挂着的 clarify。
     缓存里只有落盘状态，所以每次返回时现叠一层，不写缓存。 */
  const rows = Array.from(_sessionMetaCache.map.values()).sort((a, b) => b.updated_at - a.updated_at);
  return rows.map(m => {
    let jobs = [];
    try { jobs = panelChatQueue.list(m.id) || []; } catch { jobs = []; }
    const running = activeChatStreams.has(m.id);
    const needsInput = jobs.some(j => j && j.pending_clarify);
    const queued = jobs.filter(j => j && j.status === 'pending').length;
    const interrupted = !running && !needsInput && (m.last_status === 'interrupted' || m.last_status === 'failed');
    return { ...m, running, needs_input: needsInput, queued_count: queued,
      state: running ? 'running' : needsInput ? 'needs_input' : interrupted ? 'interrupted' : 'idle' };
  });
}
function getSession(id) {
  const f = sessionFile(id);
  if (!existsSync(f)) return null;
  try { return readJSON(f); } catch { return null; }
}
function getArchivedSession(id) {
  const f = archivedSessionFile(id);
  if (!existsSync(f)) return null;
  try { return readJSON(f); } catch { return null; }
}
function retainStickers(s) {
  return preserveSessionStickers(s, DATA_DIR, () => existingSessionWorkdir(DATA_DIR,s.id,sessionGroupDir(s.id).rel),
    error => log(`[session-stickers] ${s.id}: ${error.code || error.message}`), BASE_PATH);
}
function saveSession(s) {
  // 归档与旧流可能在相邻事件循环中交错；归档文件存在时禁止旧流把活动文件复活。
  if (existsSync(archivedSessionFile(s.id)) && !existsSync(sessionFile(s.id))) {
    throw Object.assign(new Error("会话已归档，拒绝写回旧流数据"), {status: 409, code: "session_archived"});
  }
  retainStickers(s);
  s.updated_at = Date.now();
  atomicWriteJSON(sessionFile(s.id), s);
  if (_sessionMetaCache) _sessionMetaCache.map.set(s.id, _sessionMetaFromData(s));
  try { _sessionSigCache.set(s.id, computeSessionSig(s)); } catch {}
}
function archiveSession(id) {
  const f = sessionFile(id);
  if (!existsSync(f)) throw Object.assign(new Error("会话不存在"), {status: 404});
  if (activeChatStreams.has(id) || panelChatQueue.list(id).some(j => j.status === 'pending' || j.status === 'running')) {
    throw Object.assign(new Error("会话仍有进行中的回复或排队消息，请完成或取消后再归档"), {status: 409});
  }
  const target = archivedSessionFile(id);
  if (existsSync(target)) throw Object.assign(new Error("会话已经归档"), {status: 409});
  const s = readJSON(f);
  if (retainStickers(s)) atomicWriteJSON(f,s);
  moveSessionWorkdir(DATA_DIR, ARCHIVED_SESSIONS_DIR, id, "archive", null, () => renameSync(f,target));
  if (_sessionMetaCache) _sessionMetaCache.map.delete(id);
  _sessionSigCache.delete(id);
  return readJSON(target);
}
function restoreSession(id) {
  const source = archivedSessionFile(id), target = sessionFile(id);
  if (!existsSync(source)) throw Object.assign(new Error("归档会话不存在"), {status: 404});
  if (existsSync(target)) throw Object.assign(new Error("当前已有同 ID 会话，无法覆盖恢复"), {status: 409});
  const s = readJSON(source);
  moveSessionWorkdir(DATA_DIR, ARCHIVED_SESSIONS_DIR, id, "restore", sessionGroupDir(id).rel, () => renameSync(source,target));
  if (_sessionMetaCache) _sessionMetaCache.map.set(id, _sessionMetaFromData(s));
  try { _sessionSigCache.set(id, computeSessionSig(s)); } catch {}
  return s;
}

// 彻底删除归档会话：物理删文件，不可恢复（归档=rename 到 ARCHIVED，这里才是真删）
function purgeArchivedSession(id) {
  const f = archivedSessionFile(id);
  if (!existsSync(f)) throw Object.assign(new Error("归档会话不存在"), {status: 404});
  if (existsSync(sessionFile(id))) throw Object.assign(new Error("存在活动会话，拒绝彻底删除"), {status:409});
  moveSessionWorkdir(DATA_DIR, ARCHIVED_SESSIONS_DIR, id, "purge", null, () => {
    if (!purgeCompressedArchives(id)) throw new Error("无法清理压缩原文");
    unlinkSync(f);
  });
  return true;
}

// ── 压缩原文归档（2026-11-15）──────────────────────────────────────────────
// 会话压缩时被换成摘要的原文落在 `${CHAT_DIR}/compressed/<sid>/<ts>.json`。
// 刻意和「已归档会话」共用同一套归档体系（同一个 CHAT_DIR 根、同一个面板弹窗、
// 同一条彻底删除路径），不再另造一套：压缩 = 把原文从会话里移进归档区。
// 归档原文里有私密对话，只经 monitor API（带 token）读，不做静态文件暴露。
const COMPRESSED_ARCHIVE_DIR = `${CHAT_DIR}/compressed`;
function compressedSessionDir(id) { safeId(id); return `${COMPRESSED_ARCHIVE_DIR}/${id}`; }
function _safeBatchFile(file) {
  const f = String(file || "");
  if (!/^[0-9A-Za-z._-]+\.json$/.test(f) || f === "index.json") throw Object.assign(new Error("批次文件名不合法"), {status: 400});
  return f;
}
function _compressedBatchMeta(dir, f) {
  try {
    const b = readJSON(`${dir}/${f}`);
    return { file: f, at: b.at || 0, removed: b.removed || 0, kept: b.kept || 0,
      before_tokens: b.before_tokens || 0, after_tokens: b.after_tokens || 0,
      focus: b.focus || "", messages: Array.isArray(b.messages) ? b.messages.length : (b.removed || 0) };
  } catch { return null; }
}
function _scanCompressedDir(dir) {
  const rows = [];
  try {
    for (const f of readdirSync(dir)) {
      if (!f.endsWith(".json") || f === "index.json") continue;
      const m = _compressedBatchMeta(dir, f);
      if (m) rows.push(m);
    }
  } catch {}
  return rows.sort((a, b) => b.at - a.at);
}
function _writeCompressedIndex(dir, rows) {
  try { atomicWriteJSON(`${dir}/index.json`, rows.map(r => ({...r}))); } catch {}
}
function listCompressedArchives() {
  let ids = [];
  try { ids = readdirSync(COMPRESSED_ARCHIVE_DIR, {withFileTypes: true}).filter(d => d.isDirectory()).map(d => d.name); }
  catch { return []; }
  const arch = _buildArchivedMetaMap();
  const live = new Map(listSessions().map(m => [m.id, m]));
  const out = [];
  for (const sid of ids) {
    const dir = `${COMPRESSED_ARCHIVE_DIR}/${sid}`;
    // index.json 只是缓存：以目录里真实的批次文件为准，索引丢了/多写了都不会骗前端
    const rows = _scanCompressedDir(dir);
    if (!rows.length) continue;
    const meta = live.get(sid) || arch.get(sid) || null;
    let title = (meta && meta.title) || "";
    if (!title) { try { title = (getSession(sid) || getArchivedSession(sid) || {}).title || ""; } catch {} }
    out.push({
      id: sid, title: title || sid, archived: !!arch.get(sid), batches: rows,
      total_removed: rows.reduce((n, r) => n + (r.removed || 0), 0),
      latest_at: rows[0] ? rows[0].at : 0,
    });
  }
  return out.sort((a, b) => b.latest_at - a.latest_at);
}
function readCompressedBatch(id, file) {
  const f = _safeBatchFile(file);
  const p = `${compressedSessionDir(id)}/${f}`;
  if (!existsSync(p)) throw Object.assign(new Error("这一批原文已经不在了"), {status: 404});
  return readJSON(p);
}
function deleteCompressedBatch(id, file) {
  const f = _safeBatchFile(file);
  const dir = compressedSessionDir(id);
  const p = `${dir}/${f}`;
  if (!existsSync(p)) throw Object.assign(new Error("这一批原文已经不在了"), {status: 404});
  unlinkSync(p);
  const left = _scanCompressedDir(dir);
  if (!left.length) { try { rmSync(dir, {recursive: true, force: true}); } catch {} }
  else _writeCompressedIndex(dir, left);
  return { left: left.length };
}
function purgeCompressedArchives(id) {
  try { rmSync(compressedSessionDir(id), {recursive: true, force: true}); return true; } catch { return false; }
}

// ── 会话同步签名：多窗口/多端消息同步（前端轮询几十字节的签名，变化才拉全量）──
// saveSession 每次落盘时同步刷新，/api/sessions/:id/sync 直接内存命中，零读盘。
let _sessionSigCache = new Map(); // id → sig
function computeSessionSig(s) {
  const msgs = s.messages || [];
  const last = msgs[msgs.length - 1];
  let lastPart = "";
  if (last) {
    const c = typeof last.content === "string" ? last.content : JSON.stringify(last.content || "");
    lastPart = (last.role || "") + ":" + (last.ts || last.created_at || 0) + ":" + c.length + ":" +
      (last._streaming ? 1 : 0) + ":" + ((last.tools || []).length);
  }
  return msgs.length + "|" + lastPart + "|" + (s.updated_at || 0);
}
function sessionSig(id) {
  if (_sessionSigCache.has(id)) return _sessionSigCache.get(id);
  const s = getSession(id);
  if (!s) return null;
  const sig = computeSessionSig(s);
  _sessionSigCache.set(id, sig);
  return sig;
}

function createSSEParser(onDelta, onDone, onError, onToolEvent, onUsage, onReasoning, onClarify) {
  let buffer = "";
  let currentEvent = "";
  let toolData = {};
  let toolDispatched = false;

  // 将 hermes.tool.progress 的字段名映射为中文显示名
  const TOOL_NAME_ZH = {
    execute_code: "执行代码",
    read_file: "读取文件",
    search_files: "搜索文件",
    terminal: "终端命令",
    web: "网页搜索",
    delegate_task: "委派任务",
    session_search: "会话搜索",
  };

  function tryToolEvent() {
    if (currentEvent === "hermes.tool.progress" && toolData.toolCallId && !toolDispatched) {
      toolDispatched = true;
      if (onToolEvent) {
        onToolEvent({
          tool: toolData.tool,
          toolCallId: toolData.toolCallId,
          status: toolData.status,
          emoji: toolData.emoji || "",
          label: toolData.label || "",
          toolZh: TOOL_NAME_ZH[toolData.tool] || toolData.tool,
          command: toolData.command || "",
          summary: toolData.summary || "",
          args: toolData.args || "",
          result: toolData.result || "",
        });
      }
    }
  }

  return {
    feed(chunk) {
      buffer += chunk;
      const parts = buffer.split("\n\n");
      buffer = parts.pop() || "";
      for (const part of parts) {
        let eventData = "";
        currentEvent = "";
        toolData = {};
        toolDispatched = false;

        for (const line of part.split("\n")) {
          if (line.startsWith("event: ")) {
            currentEvent = line.slice(7).trim();
          } else if (line.startsWith("data: ")) {
            eventData = line.slice(6).trim();
          } else if (line.startsWith("data:")) {
            eventData = line.slice(5).trim();
          }
          // 工具事件：逐行累积字段，空行时统一派发
          if (currentEvent === "hermes.tool.progress" && eventData) {
            try {
              const tj = JSON.parse(eventData);
              if (tj.tool) toolData.tool = tj.tool;
              if (tj.toolCallId) toolData.toolCallId = tj.toolCallId;
              if (tj.status) toolData.status = tj.status;
              if (tj.emoji) toolData.emoji = tj.emoji;
              if (tj.label) toolData.label = tj.label;
              if (tj.command) toolData.command = tj.command;
              if (tj.summary) toolData.summary = tj.summary;
              if (tj.args) toolData.args = tj.args;
              if (tj.result) toolData.result = tj.result;
            } catch {}
            eventData = ""; // 不再走普通 delta 路径
          }
        }
        tryToolEvent();

        // 交互式确认卡片（clarify）：网关在 SSE 里发 `event: clarify.request`，
        // data 为 {clarify_id, question, choices, multi_select}。原样转给上层，
        // 不走 delta 通道，否则 JSON 会被当成正文拼进回复。
        if (currentEvent === "clarify.request" && eventData) {
          try {
            const clarifyJson = JSON.parse(eventData);
            if (onClarify) onClarify(clarifyJson);
          } catch {}
          continue;
        }

        if (!eventData) continue;
        if (eventData === "[DONE]") { onDone(); return; }
        try {
          const json = JSON.parse(eventData);
          if (json.usage && onUsage) onUsage(json.usage);
          if (json.error) { onError(typeof json.error === 'string' ? json.error : (json.error.message || JSON.stringify(json.error))); return; }
          const delta = json.choices?.[0]?.delta?.content || "";
          if (delta) onDelta(delta);
          // 推理模型（deepseek-v4-flash 等）：思考内容在 reasoning_content 字段，
          // 必须转发给前端，否则 UI 一直等不到 content 而卡死
          const _rd = json.choices?.[0]?.delta?.reasoning_content || "";
          if (_rd && onReasoning) onReasoning(_rd);
        } catch {
          // 忽略非 JSON 行
        }
      }
    },
    flush() {
      // 处理剩余 buffer 中可能未结束的工具事件
      if (buffer.trim()) {
        currentEvent = "";
        toolData = {};
        toolDispatched = false;
        const lines = buffer.split("\n");
        for (const line of lines) {
          if (line.startsWith("event: ")) {
            currentEvent = line.slice(7).trim();
          } else if (line.startsWith("data: ")) {
            const data = line.slice(6).trim();
            if (currentEvent === "hermes.tool.progress" && data) {
              try {
                const tj = JSON.parse(data);
                if (tj.tool) toolData.tool = tj.tool;
                if (tj.toolCallId) toolData.toolCallId = tj.toolCallId;
                if (tj.status) toolData.status = tj.status;
                if (tj.emoji) toolData.emoji = tj.emoji;
                if (tj.label) toolData.label = tj.label;
              } catch {}
              continue;
            }
            if (data === "[DONE]") { tryToolEvent(); onDone(); return; }
            try {
              const json = JSON.parse(data);
              if (json.usage && onUsage) onUsage(json.usage);
              if (json.error) { onError(typeof json.error === 'string' ? json.error : (json.error.message || JSON.stringify(json.error))); return; }
              const delta = json.choices?.[0]?.delta?.content || "";
              if (delta) onDelta(delta);
              const _rd2 = json.choices?.[0]?.delta?.reasoning_content || "";
              if (_rd2 && onReasoning) onReasoning(_rd2);
            } catch {}
          }
        }
        tryToolEvent();
      }
      onDone();
    },
  };
}

// ─── 聊天：Gateway 代理 ─────────────────────────────────────────────────────
function resolveProviderBase(provider) {
  if(!provider?.viaGateway)throw Error('会话模型路线无效，请重新选择');
  return GATEWAY_API.replace(/\/$/, "");
}

async function autoTitle(userMsg, provider) {
  // userMsg 可能是字符串、多模态 content 数组，或前端旧版对象 {text, images, files}
  // 这里只取文字部分用于生成标题
  let plainMsg = userMsg;
  if (Array.isArray(userMsg)) {
    const textPart = userMsg.find(p => p && p.type === "text");
    plainMsg = (textPart && textPart.text) || "[图片消息]";
  } else if (userMsg && typeof userMsg === "object") {
    // 兼容前端 buildMessageContent 发送的 {text, images, files} 对象
    plainMsg = userMsg.text || "[图片消息]";
  } else if (typeof userMsg !== "string") {
    plainMsg = String(userMsg ?? "");
  }
  const text = plainMsg.slice(0, 200);
  provider = provider || await getActiveProvider();
  try {
    const providerBase = resolveProviderBase(provider);
    // 修复（2026-10-18）：provider 经网关路由时（viaGateway=true，如默认 DeepSeek）必须用
    // MONITOR_TOKEN 鉴权。此前这里无条件 resolveRealApiKey，把上游 DeepSeek key 发到网关，
    // 网关回 401 invalid API key → 每个新会话标题生成失败，errors.log 每会话一条
    // "API server rejected invalid API key: ... user_agent='node'"。与 chatRequest 的 isGateway 判定对齐。
    const _isGatewayBase = providerBase === GATEWAY_API.replace(/\/$/, "");
    const apiKey = MONITOR_TOKEN;
    const headers = { "Content-Type": "application/json" };
    if (apiKey && apiKey !== "none") {
      headers["Authorization"] = `Bearer ${apiKey}`;
    }
    const r = await fetch(`${providerBase}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify((() => {
        const payload = {
          model: provider.gatewayProvider ? provider.model : undefined,
          messages: [
            { role: "system", content: "Generate a concise title (max 8 words, no quotes, no period) for this user message. Reply with ONLY the title text." },
            { role: "user", content: text },
          ],
          temperature: 0.3,
          max_tokens: 30,
          stream: false,
        };
        // 2026-10-28：与 chatRequest 一致，经网关时透传 provider slug（否则裸 model 被忽略）
        if (_isGatewayBase && provider.gatewayProvider && provider.model && provider.model !== "auto") {
          payload.provider = provider.gatewayProvider;
        }
        return payload;
      })()),
      signal: AbortSignal.timeout(8000),
    });
    if (!r.ok) return text.slice(0, 30);
    const data = await r.json();
    const title = data.choices?.[0]?.message?.content?.trim();
    return (title || text.slice(0, 30)).slice(0, 60);
  } catch {
    return text.slice(0, 30);
  }
}

async function chatRequest(provider, message, history, reqSignal, sessionId) {
  const providerBase = resolveProviderBase(provider);
  const isGateway = providerBase === GATEWAY_API.replace(/\/$/, "");
  const apiKey = MONITOR_TOKEN;
  const headers = { "Content-Type": "application/json" };
  if (apiKey && apiKey !== "none") {
    headers["Authorization"] = `Bearer ${apiKey}`;
  }
  // 2026-11-17：把面板会话 UUID 透传给网关，取代网关的兜底哈希。
  // 网关 api_server.py 的 _derive_chat_session_id 用 sha256(系统提示 + 首条用户消息)[:16]
  // 当 session id，于是所有以「你好」开头的面板会话都算同一个会话——实测
  // api-e7ef006cba0d55e9 堆了 7773 条消息、跨 4 天，并共享同一个 task_state，
  // 每轮把 11-13 的「2/2 已完成」当新任务注入。
  // 网关侧 request.headers.get("X-Hermes-Session-Id") 有值就直接采用（api_server.py:4149）。
  // 只在网关链路加；直连上游供应商时这个 header 无意义。
  if (isGateway && sessionId) {
    headers["X-Hermes-Session-Id"] = String(sessionId);
  }
  const upstream = await fetch(`${providerBase}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify((() => {
        const payload = {
          model: provider.gatewayProvider ? provider.model : undefined,
          messages: history,
          stream: true,
          stream_options: { include_usage: true },
        };
        // 2026-10-28：经网关时必须同时透传 provider slug。网关 _request_agent_overrides
        // 只认「带 provider 的请求」里的 model（direct_model_requests 默认 false 时，
        // 裸 model 会被忽略并退回 config.yaml 的 model.default —— 这正是「面板选模型
        // 实际跑另一个」的根源）。透传后网关按 route_source=raw_request 执行所选模型，
        // 无需再改写全局 model.default。
        if (isGateway && provider.gatewayProvider && provider.model && provider.model !== "auto") {
          payload.provider = provider.gatewayProvider;
        }
        /* 思考强度（2026-11-20）：前端展开栏选的档位，原样交给网关。
           只有走网关才有意义 —— 直连上游供应商时 model_options 是网关私有字段。 */
        const _rmo = sessionId ? sessionReasoningOpts.get(String(sessionId)) : null;
        if (isGateway && _rmo) payload.model_options = _rmo;
        return payload;
      })()),
      signal: reqSignal,
    });
  // 请求详情日志：定位「gateway 空流」时 monitor 到底发了什么
  try {
    const _hist = history || [];
    const _sys = _hist.find(m => m.role === "system");
    /* 思考强度（2026-11-20）：用量页要按小时看「这一小时是按哪档想的」，
       所以把实际发出去的档位写进这条日志行。reason=- 表示没带 model_options
       （跟随服务商默认），旧日志行没有这个字段，前端按「未记」处理。 */
    const _rsn = (() => {
      const _opt = sessionId ? sessionReasoningOpts.get(String(sessionId)) : null;
      const _r = _opt && _opt.reasoning;
      if (!_r) return "-";
      if (_r.enabled === false) return "off";
      return String(_r.effort || "on");
    })();
    log(`[Chat] 请求 provider=${provider.name} model=${provider.model || ""} msgs=${_hist.length} sysLen=${_sys ? String(_sys.content).length : 0} reason=${_rsn} ses=${String(sessionId || "").slice(0, 8)}`);
  } catch (e) {}

  if (!upstream.ok || !upstream.body) {
    const errText = await upstream.text().catch(() => "");
    throw new Error(`Gateway ${upstream.status}: ${errText.slice(0, 200)}`);
  }
  return upstream;
}

// ─── 辅助：把前端送来的 {text, images, files} 消息对象规范化为
//      OpenAI 兼容的 content 格式（字符串 或 多模态数组）──────────────────
const MIME_BY_EXT = {
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", gif: "image/gif",
  webp: "image/webp", svg: "image/svg+xml", bmp: "image/bmp", ico: "image/x-icon",
  // 文档/表格/演示
  pdf: "application/pdf", doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ppt: "application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  // 文本/代码/Markdown
  txt: "text/plain", md: "text/markdown", markdown: "text/markdown",
  csv: "text/csv", json: "application/json", yaml: "text/yaml", yml: "text/yaml",
  xml: "application/xml", log: "text/plain", ini: "text/plain", conf: "text/plain",
  js: "text/javascript", mjs: "text/javascript", cjs: "text/javascript", ts: "text/plain",
  tsx: "text/plain", jsx: "text/plain", py: "text/x-python", sh: "text/x-sh", bash: "text/x-sh",
  c: "text/x-c", h: "text/x-c", cpp: "text/x-c", cc: "text/x-c", hpp: "text/x-c",
  java: "text/x-java", go: "text/x-go", rs: "text/x-rust", rb: "text/x-ruby", php: "text/x-php",
  html: "text/html", htm: "text/html", css: "text/css", sql: "text/x-sql",
  zip: "application/zip", tar: "application/x-tar", gz: "application/gzip",
  tgz: "application/gzip", rar: "application/vnd.rar", "7z": "application/x-7z-compressed",
  mp3: "audio/mpeg", wav: "audio/wav", mp4: "video/mp4", mov: "video/quicktime",
  webm: "video/webm",
};
function mimeFromPath(p) {
  const ext = (p.split(".").pop() || "").toLowerCase();
  return MIME_BY_EXT[ext] || "application/octet-stream";
}
// 下载/预览时用于浏览器内联展示的类型白名单（其余强制附件下载）
function isInlinePreviewType(p) {
  const ext = (p.split(".").pop() || "").toLowerCase();
  if (["jpg", "jpeg", "png", "gif", "webp", "svg", "bmp", "pdf", "html", "htm"].includes(ext)) return true;
  const mime = MIME_BY_EXT[ext] || "";
  return mime.startsWith("text/") || mime.startsWith("image/") || mime === "application/pdf";
}
function urlToUploadPath(url) {
  try { return fileReference(url,{roots:panelFileRoots,data:DATA_DIR,varDir:VAR_DIR,basePath:BASE_PATH}).absolute; }
  catch { return null; }
}
/* 2026-11-21 修附件刷新变 [文件…]/[图片:…] 的根因：
   会话产物 2026-11-20 起改用 /api/workspace-ui/session-file/<sid>/[子目录/]<文件名> 这个 URL
   （见 panel-workspace.js:365 的路由），但 urlToUploadPath → fileReference 只认
   /uploads /workspace /tmp /data 等老前缀，不认 session-file。于是附件被当成「读不到」，
   退化成 [文件: URL]/[图片: URL] 裸占位，刷新后前端 splitContent 正则对不上、露馅成
   [文件…]。这里加一个能反推 session-file URL → 本机绝对路径的解析，图片和文件两条
   链路都走它，附件名/图片内容才能在历史里正确还原。 */
async function urlToFsPath(url) {
  if (url && typeof url === 'string' && url.startsWith('/api/workspace-ui/session-file/')) {
    const parts = decodeURIComponent(url).split('/').filter(Boolean);
    // /session-file/<sid>/<文件名>  → uploads；/session-file/<sid>/<子目录>/<文件名> → 该子目录
    if (parts.length !== 5 && parts.length !== 6) return null;
    const sid = parts[3] || '';
    const sub = parts.length === 6 ? parts[4] : 'uploads';
    // 子目录白名单 + 文件名禁分隔符/穿越，防 sub 被塞 .. 逃出会话目录
    if (!SESSION_SUBDIRS.includes(sub)) return null;
    const name = parts.at(-1) || '';
    if (!sid || !name || /[/\\]/.test(name) || name.includes('..')) return null;
    try {
      const dir = await resolveSessionFileDir(sid);
      return join(dir, sub, name);
    } catch (e) { return null; }
  }
  return urlToUploadPath(url);
}
function safeFilename(name) {
  const n = String(name || "file").replace(/[\r\n\x00/\\]/g, "_").replace(/\.\.+/g, ".").slice(-180);
  return n || "file";
}
async function normalizeMessage(message) {
  if (message == null) return "";
  if (typeof message === "string") return message;
  if (typeof message !== "object") return String(message);
  const text = message.text || "";
  const images = Array.isArray(message.images) ? message.images : [];
  const files = Array.isArray(message.files) ? message.files : [];
  if (images.length === 0 && files.length === 0) return text;

  const parts = [];
  if (text) parts.push({ type: "text", text });

  for (const imgUrl of images) {
    const fp = await urlToFsPath(imgUrl);
    if (fp && existsSync(fp)) {
      try {
        const inspected = await handlePanelFiles.inspect(fp, true);
        const mime = mimeFromPath(fp);
        const b64 = inspected.base64;
        parts.push({ type: "image_url", image_url: { url: `data:${mime};base64,${b64}` } });
        continue;
      } catch (e) { log(`[normalizeMessage] image read failed ${fp}: ${e.message}`); }
    }
    parts.push({ type: "text", text: `[图片: ${imgUrl}]` });
  }

  let fileText = "";
  const fileNames = Array.isArray(message.file_names) ? message.file_names : [];
  for (let i = 0; i < files.length; i++) {
    const fileUrl = files[i];
    const fp = await urlToFsPath(fileUrl);
    if (fp && existsSync(fp)) {
      try {
        const inspected = await handlePanelFiles.inspect(fp);
        const st = {size: inspected.bytes};
        // 优先用前端传来的原始文件名（buildMessageContent 的 file_names），
        // 它不带盘上「时间戳_hash_」前缀；拿不到再退回盘上名字。
        const name = fileNames[i] || fp.split("/").pop();
        const sizeStr = st.size < 1024 ? `${st.size}B`
                      : st.size < 1048576 ? `${Math.round(st.size / 1024)}KB`
                      : `${Math.round(st.size / 1048576 * 10) / 10}MB`;
        fileText += `\n\n### 文件: ${name} [${sizeStr}]\n已保存到本机路径: ${fp}\n你读取此文件并分析`;
        continue;
      } catch (e) { log(`[normalizeMessage] file stat failed ${fp}: ${e.message}`); }
    }
    fileText += `\n\n[文件: ${fileUrl}]`;
  }

  if (fileText) {
    if (parts.length > 0 && parts[0].type === "text") {
      parts[0].text += fileText;
    } else {
      parts.unshift({ type: "text", text: fileText.trim() });
    }
  }

  if (parts.length === 0) return "";
  if (parts.length === 1 && parts[0].type === "text") return parts[0].text;
  return parts;
}

// ── 辅助：流式消费 upstream，yield delta ──────────────────────────────────────
async function* streamDeltas(upstream, decoder, reqSignal) {
  const reader = upstream.body.getReader();
  const parser = createSSEParser(
    (delta) => { /* 内联处理 */ },
    () => {},
    () => {},
  );
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      parser.feed(chunk);
      const lines = chunk.split("\n");
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") { return; }
          try {
            const json = JSON.parse(data);
            const delta = json.choices?.[0]?.delta?.content || "";
            if (delta) yield delta;
          } catch {}
        }
      }
    }
  } catch (e) {
    if (e.name !== "AbortError") throw e;
  } finally {
    parser.flush();
    reader.releaseLock();
  }
}


const PROVIDER_TIMEOUT_MS = 300000; // 长任务/多工具链需要更长时间，5 分钟
/* clarify（等人点按钮）的等待窗口：取 config.yaml 的 agent.clarify_timeout，
 * 再留 2 分钟缓冲。读文件失败就退回 12 分钟。别把它并进 PROVIDER_TIMEOUT_MS——
 * 那是「模型不出数据」的判据，等人不算模型卡住。 */
function clarifyWaitMs() {
  try {
    const txt = readFileSync(HERMES_CONFIG, "utf8");
    const m = txt.match(/^\s*clarify_timeout:\s*(\d+)/m);
    const sec = m ? parseInt(m[1], 10) : 600;
    return Math.min(Math.max(sec, 60), 3600) * 1000 + 120000;
  } catch { return 12 * 60 * 1000; }
}
const activeChatStreams = new Map();
let _chatCompress = null;   // /api/chat/compress 的懒加载实例（首次调用时建，复用并发锁）
// 2026-11-13：本轮开始时间（SSE/WS 两个入口各写一次），finalize 时折算 duration_ms 落盘，
// 刷新后 msg-statusbar 才有真实耗时，不再靠前端内存里的 Date.now() 现算。
const _turnStart = new Map();
const wsMessageQueue = new Map(); // session_id → message，WS 连接前暂存
/* 会话级「思考强度」覆盖（2026-11-20）：前端在展开栏选关/低/中/高，
   随请求体 model_options 一起送上来。这里按 session_id 暂存，chatRequest
   拼网关请求时再挂回去 —— 避免把新参数从 ws-send 一路穿过 runChatWS /
   createChatStream / chatRequest 五层签名（那五层已经够长了）。
   网关 api_server.py 的 _runtime_options_from_model_options 认得这个结构。 */
const sessionReasoningOpts = new Map();
/* 思考强度统一入口（2026-11-21 修）：面板真实发聊天请求的路径有三条 ——
   /api/chat/queue（前端默认走这条）、/api/chat/ws-send、/api/chat/stream。
   先前只在后两条里写 Map，queue 那条完全没接，于是「设了中」后台永远记 reason=-。
   现在收敛到一个函数，三条入口都调它，新增入口也必须调它，否则日志必然撒谎。 */
function noteSessionReasoning(sessionId, modelOptions) {
  if (!sessionId) return;
  const sid = String(sessionId);
  if (modelOptions && typeof modelOptions === "object") sessionReasoningOpts.set(sid, modelOptions);
  else sessionReasoningOpts.delete(sid);
}
// 流结果缓存：WS 断开后 SSE fallback 可复用已完成的流结果，避免重新请求 LLM
// 格式: session_id → { status:'running'|'done'|'error', reply:'', tools:[], error:'', waiters:[] }
const _streamResultCache = new Map();
// 清理超时：5 分钟后清除缓存条目，防止内存泄漏
const _CACHE_TTL = 5 * 60 * 1000;
function _cacheCleanup(sid) { const entry=_streamResultCache.get(sid);setTimeout(() => { if(_streamResultCache.get(sid)===entry&&entry?.status!=='running'){_streamResultCache.delete(sid); _streamGenMap.delete(sid);} }, _CACHE_TTL); }

// 竞态修复（2026-08-24 幽灵消息实锤）：缓存代数 + 消息指纹
// - 代数：每次「新消息入队」递增；旧流完成时若代数已变 = 已被新消息取代 → 丢弃结果、不写缓存、不 finalize
// - 指纹：同一条消息的流已 running 时，新请求等待复用，不 abort、不双流
const _streamGenMap = new Map();
const _userStopped = new Set(); // 改动4（2026-09-21）：用户主动停止的流，后续 checkpoint/finalize 跳过，防重复消息
function _bumpGen(sid) { _streamGenMap.set(sid, (_streamGenMap.get(sid) || 0) + 1); }
function _isStale(sid, gen) { return (_streamGenMap.get(sid) || 0) !== gen; }
function _msgFp(m) { return createHash('sha256').update(JSON.stringify(m) || '').digest('hex'); }

function combineSignals(signals) {
  const valid = signals.filter(Boolean);
  if (typeof AbortSignal.any === "function") return AbortSignal.any(valid);
  const ctrl = new AbortController();
  for (const s of valid) {
    if (s.aborted) { ctrl.abort(s.reason); break; }
    s.addEventListener("abort", () => ctrl.abort(s.reason), { once: true });
  }
  return ctrl.signal;
}

// 流式回复增量 checkpoint：把当前部分回复暂存为最后一条 assistant 消息，便于异常恢复
function checkpointAssistantMessage(sessionId, content, streamId, tools, identity) {
  if (streamId && _userStopped.has(streamId)) return; // 改动4：用户已停止，不再 checkpoint
  try {
    const session = getSession(sessionId);
    if (!session) return;
    const msgs = session.messages;
    // 幽灵修复（升级 0.21.149 后重打 2026-08-24）：优先按 streamId 定位自己的流式消息，避免双流并发时互相覆盖
    let target = null;
    if (streamId) {
      for (let i = msgs.length - 1; i >= 0; i--) {
        if (msgs[i].role === "assistant" && msgs[i]._streaming && msgs[i]._streamId === streamId) { target = msgs[i]; break; }
      }
    }
    if (!target) {
      const last = msgs[msgs.length - 1];
      if (last && last.role === "assistant" && last._streaming && !last._streamId) { target = last; }
    }
    if (target) {
      target.content = content;
      target.ts = Date.now();
    } else {
      const msg = { role: "assistant", content, ts: Date.now(), _streaming: true };
      if (streamId) msg._streamId = streamId;
      msgs.push(msg);
      target = msg;
    }
    // 工具事件随进度落盘；进程退出前不必等正常 finalize 才能保留记录。
    if (Array.isArray(tools)) target.tools = tools.map(t => ({ ...t }));
    if (identity) Object.assign(target, identity);
    saveSession(session);
  } catch (e) {
    log(`[checkpoint] failed: ${e.message}`);
  }
}
// 只把尚未结束的调用标为中断，已完成/失败的结果保持原样。
function interruptPendingTools(tools) {
  return (tools || []).map(t => {
    if (!t) return t;
    const terminal = ["done", "completed", "finish", "finished", "error", "failed", "interrupted", "cancelled", "canceled"].includes(t.status);
    return terminal ? { ...t } : { ...t, status: "interrupted", running: false };
  });
}
// 清扫上一轮遗留的流式占位（2026-11-04）：
// 用户在新一轮发消息时，上一轮的 assistant 若还挂着 _streaming（异常中断/竞态没走 finalize），
// 会永远停在「开始处理…」甚至把整段历史渲染成占位。这里统一收尾：
// - 清掉 _streaming/_streamId 标记
// - 若内容只是裸占位符，替换成一句「被打断」的说明，不再误导。
function sweepStaleStreaming(session) {
  if (!session || !Array.isArray(session.messages)) return false;
  let changed = false;
  for (const m of session.messages) {
    if (m.role === "assistant" && m._streaming) {
      changed = interruptAssistantMessage(m, {phrase: '（上一条回复被新消息打断）'}) || changed;
    }
  }
  return changed;
}
// 加载会话时清扫僵尸流式消息（2026-11-04）：gateway 重启/任务卡死会留下 _streaming=true 但 ts 久不更新的半截消息，
// 前端打开会话时把它们收尾成「已中断」，避免一直显示输出中。活跃流的 ts 每 5 秒 checkpoint 一次，
// 所以 60 秒没更新必是僵尸，不会误伤正在流式输出的消息。
function sweepZombieStreams(session) {
  if (!session || !Array.isArray(session.messages)) return false;
  const now = Date.now();
  let changed = false;
  for (const m of session.messages) {
    if (m && m.role === "assistant" && m._streaming && (now - (m.ts || 0) > 60000)) {
      changed = interruptAssistantMessage(m, {now: () => now}) || changed;
    }
  }
  if (changed) saveSession(session);
  return changed;
}
function finalizeAssistantMessage(sessionId, content, options = {}, streamId) {
  if (streamId && _userStopped.has(streamId)) { _userStopped.delete(streamId); return; } // 改动4：用户已停止，收尾已由 /api/chat/stop 完成
  try {
    const session = getSession(sessionId);
    if (!session) return;
    // 从 systemOverride 提取角色名（格式：【专家角色】xxx\n 或 【专家角色】 xxx）
    var _sender = "Hermes";
    if (options.systemOverride) {
      var _m = String(options.systemOverride).match(/【专家角色】\s*(.+)/);
      if (_m && _m[1]) _sender = _m[1].trim().split(/\s|\n/)[0];
    }
    const msgs = session.messages;
    // 幽灵修复（升级 0.21.149 后重打 2026-08-24）：优先按 streamId 定位自己的流式消息
    let target = null;
    if (streamId) {
      for (let i = msgs.length - 1; i >= 0; i--) {
        if (msgs[i].role === "assistant" && msgs[i]._streamId === streamId) { target = msgs[i]; break; }
      }
    }
    if (!target) {
      const last = msgs[msgs.length - 1];
      if (last && last.role === "assistant" && last._streaming && !last._streamId) { target = last; }
    }
    if (target) {
      target.content = content;
      target.ts = Date.now();
      target.sender = target.sender || _sender;
      if (options.identity) Object.assign(target, options.identity);
      if (options.queueStatus) target.queue_status = options.queueStatus;
      if (options.errorCode) target.error_code = options.errorCode;
      /* 2026-11-13：把本轮真实耗时落盘，msg-statusbar 右侧时间刷新后仍然在。 */
      const _t0 = _turnStart.get(sessionId);
      if (_t0) { target.duration_ms = Math.max(0, Date.now() - _t0); target.finished_at = Date.now(); _turnStart.delete(sessionId); }
      delete target._streaming;
      delete target._streamId;
      if (options.tools) target.tools = options.tools;
    } else {
      const msg = { role: "assistant", content, ts: Date.now(), sender: _sender, ...options.identity };
      if (options.queueStatus) msg.queue_status = options.queueStatus;
      if (options.errorCode) msg.error_code = options.errorCode;
      const _t0n = _turnStart.get(sessionId);
      if (_t0n) { msg.duration_ms = Math.max(0, Date.now() - _t0n); msg.finished_at = Date.now(); _turnStart.delete(sessionId); }
      if (options.tools) msg.tools = options.tools;
      msgs.push(msg);
    }
    if (options.title && session.title === "New Chat") {
      session.title = options.title;
    }
    saveSession(session);
  } catch (e) {
    log(`[finalize] failed: ${e.message}`);
  }
}


function createChatStream(sessionId, message, reqSignal, systemOverride, modelOverride) {
  const replyIdentity = sessionIdentity(sessionId, systemOverride);
  systemOverride = sessionSystem(sessionId, systemOverride || "");
  const enc = new TextEncoder();
  // 幽灵修复（升级 0.21.149 后重打 2026-08-24）：每个流唯一 ID，checkpoint/finalize 用它定位自己的流式消息
  const streamId = `${sessionId}:${Date.now()}:${Math.random().toString(36).slice(2, 10)}`;
  const myGen = _streamGenMap.get(sessionId) || 0;
  const myFp = _msgFp(message);
  return new ReadableStream({
    async start(controller) {
      const send = (data, ev = "message") => {
        try { controller.enqueue(enc.encode(`event: ${ev}\ndata: ${data}\n\n`)); }
        catch {}
      };
      const sendJSON = (obj) => send(JSON.stringify(obj));
      const decoder = new TextDecoder();

      // 检查流结果缓存：如果同一会话的 WS 流正在运行或已完成，复用结果
      const cached = _streamResultCache.get(sessionId);
      if (cached) {
        if (cached.status === 'done') {
          log(`[SSE] cache hit (done) session=${sessionId}, reply len=${cached.reply.length}`);
          if (cached.reply) {
            const chunkSize = 200;
            for (let i = 0; i < cached.reply.length; i += chunkSize) {
              sendJSON({ delta: cached.reply.slice(i, i + chunkSize) });
              await new Promise(r => setTimeout(r, 5));
            }
          }
          if (cached.tools && cached.tools.length) {
            cached.tools.forEach(t => sendJSON({ tool_progress: t }));
          }
          sendJSON({ done: true });
          try { controller.close(); } catch {}
          return;
        }
        if (cached.status === 'running') {
          log(`[SSE] cache hit (running) session=${sessionId}, waiting...`);
          // 幽灵修复（升级 0.21.149 后重打 2026-08-24）：不再 30s 超时后 fall-through 自己跑（那会与 WS 流双跑产生重复消息）。
          // 改为持续等待上游 WS 流完成；仅当上游流已死（activeChatStreams 无此 session）才放弃。
          const result = await new Promise(resolve => {
            cached.waiters.push(resolve);
            const checkAlive = setInterval(() => {
              if (!activeChatStreams.has(sessionId)) {
                clearInterval(checkAlive);
                resolve(null);
              }
            }, 5000);
            // 超长兜底：最多等 10 分钟
            setTimeout(() => { clearInterval(checkAlive); resolve(null); }, 10 * 60 * 1000);
          });
          if (result && result.status === 'done') {
            log(`[SSE] cache wait done session=${sessionId}, reply len=${result.reply.length}`);
            if (result.reply) {
              const chunkSize = 200;
              for (let i = 0; i < result.reply.length; i += chunkSize) {
                sendJSON({ delta: result.reply.slice(i, i + chunkSize) });
                await new Promise(r => setTimeout(r, 5));
              }
            }
            if (result.tools && result.tools.length) {
              result.tools.forEach(t => sendJSON({ tool_progress: t }));
            }
            sendJSON({ done: true });
            try { controller.close(); } catch {}
            return;
          }
          log(`[SSE] upstream stream dead session=${sessionId}, no fall-through rerun`);
          sendJSON({ error: '上游回复流已中断，请重新发送消息' });
          sendJSON({ done: true });
          try { controller.close(); } catch {}
          return;
        }
        if (cached.status === 'error') {
          log(`[SSE] cache hit (error) session=${sessionId}`);
          sendJSON({ error: cached.error || 'Stream failed' });
          sendJSON({ done: true });
          try { controller.close(); } catch {}
          return;
        }
      }

      const stopCtrl = new AbortController();
      activeChatStreams.set(sessionId, stopCtrl);
      _turnStart.set(sessionId, Date.now());

      const keepaliveTimer = setInterval(() => {
        try { controller.enqueue(enc.encode(`: keepalive\n\n`)); } catch {}
      }, 8000);

      const cleanup = () => {
        clearInterval(keepaliveTimer);
        if (activeChatStreams.get(sessionId) === stopCtrl) activeChatStreams.delete(sessionId);
      };

      let checkpointInterval = null;
      let fullReply = "";
      let responseTools = [];
      try {
        const normalizedMessage = await normalizeMessage(message);
        const session = getSession(sessionId);
        if (!session) {
          sendJSON({ error: "session not found" }); send("[DONE]", "end"); cleanup(); controller.close(); return;
        }

        // 去重：WS 路径（runChatWS）可能在 XHR 回退前已推送过该用户消息
        const _lastMsg = session.messages[session.messages.length - 1];
        const _isSameUserMsg = _lastMsg && _lastMsg.role === "user" &&
          JSON.stringify(_lastMsg.content) === JSON.stringify(normalizedMessage);
        const _swept = sweepStaleStreaming(session);
        if (!_isSameUserMsg) {
          session.messages.push({ role: "user", content: normalizedMessage, ts: Date.now() });
          saveSession(session);
        } else if (_swept) {
          saveSession(session);
        }

        // 智能上下文：保留首条用户消息 + 最近 MAX_HISTORY_MESSAGES 条
        // systemOverride（persona / 专家团提示）注入 system prompt，避免污染用户消息历史
        const history = buildChatHistory(session, (systemOverride ? systemOverride + "\n\n" : "") + UI_CAPABILITIES_PROMPT);

        // 改动3（2026-09-21）：长任务先推占位消息，让用户知道模型在思考（deepseek 单请求 40-50s 不吐字）
        checkpointAssistantMessage(sessionId, "开始处理…", streamId, undefined, replyIdentity);

        const cfg = await getChatConfig();
        const allProviders = resolveChatProviders(cfg, modelOverride);

        let requestError = null;
        let hadToolCalls = false;
        let idleTimedOut = false;

        // 每 5 秒 / 每 1000 字符做一次增量 checkpoint，异常时也能保留进度
        let lastCheckpointLen = 0;
        let lastCheckpointTs = Date.now();
        checkpointInterval = setInterval(() => {
          // 【2026-09-22 修复】陈旧流也 checkpoint 落盘（不再 _isStale 跳过）；checkpointAssistantMessage 按 streamId 定位自己消息，不覆盖新流
          if ((fullReply.length > 0 || responseTools.length > 0) && (fullReply.length - lastCheckpointLen >= 1000 || Date.now() - lastCheckpointTs >= 5000)) {
            checkpointAssistantMessage(sessionId, fullReply || "开始处理…", streamId, responseTools, replyIdentity);
            lastCheckpointLen = fullReply.length;
            lastCheckpointTs = Date.now();
          }
        }, 1000);

        for (let i = 0; i < allProviders.length; i++) {
          const provider = allProviders[i];
          const isFallback = i > 0;
          if (isFallback) {
            sendJSON({ info: `主模型超时，切换备选: ${provider.name}...` });
          }

          try {
 
            const timeoutController = new AbortController();
            const timeoutTimer = setTimeout(() => timeoutController.abort(), PROVIDER_TIMEOUT_MS);
            const signal = combineSignals([timeoutController.signal, stopCtrl.signal]);

            const upstream = await chatRequest(provider, normalizedMessage, history, signal, sessionId);
            {const linked=getSession(sessionId);if(linked&&recordGatewaySession(linked,upstream,{streamId}))saveSession(linked);}
            clearTimeout(timeoutTimer);

            hadToolCalls = false;
            let usageReported = false;
            const localParser = createSSEParser(
              (delta) => { fullReply += delta; sendJSON({ delta }); },
              () => {},
              (err) => { requestError = err; sendJSON({ error: err }); },
              (toolEvent) => {
                hadToolCalls = true;
                sendJSON({ tool_progress: toolEvent });
                try {
                  const _tName = toolEvent.tool || toolEvent.label || toolEvent.command || "";
                  if (_tName) {
                    appendFileSync(`${DATA_DIR}/skill_usage.jsonl`, JSON.stringify({ ts: Date.now(), skill: String(_tName).slice(0, 100), session_id: sessionId, toolCallId: toolEvent.toolCallId || "", status: toolEvent.status || "done" }) + String.fromCharCode(10));
                  }
                } catch (e) {}
                const _tid = toolEvent.toolCallId || toolEvent.tool || "tool";
                const _ex = responseTools.find(t => (t.toolCallId || t.tool) === _tid);
                if (_ex) {
                  if (toolEvent.status) _ex.status = toolEvent.status;
                  if (toolEvent.result) _ex.result = String(toolEvent.result).slice(0, 4000);
                  if (toolEvent.emoji) _ex.emoji = toolEvent.emoji;
                  const _lbl = toolEvent.label || toolEvent.command || toolEvent.summary;
                  if (_lbl) _ex.label = _lbl;
                  if (toolEvent.toolZh) _ex.toolZh = toolEvent.toolZh;
                } else {
                  responseTools.push({
                    tool: toolEvent.tool,
                    toolCallId: toolEvent.toolCallId,
                    status: toolEvent.status || "done",
                    emoji: toolEvent.emoji || "",
                    label: toolEvent.label || toolEvent.command || toolEvent.summary || "",
                    toolZh: toolEvent.toolZh || toolEvent.tool || "工具",
                    result: (toolEvent.result || "").slice(0, 4000),
                  });
                }
                checkpointAssistantMessage(sessionId, fullReply || "开始处理…", streamId, responseTools, replyIdentity);
              },
              (usage) => {
                usageReported = true;
                try {
                  const s = getSession(sessionId);
                  if (s) {
                    s.lastUsage = usageSummary(usage,{provider});
                    saveSession(s);
                  }
                } catch {}
                sendJSON({ usage });
              },
              (r) => { sendJSON({ reasoning: r }); },
              (clarifyEvent) => { sendJSON({ clarify: clarifyEvent }); },
            );

            const reader = upstream.body.getReader();
            const localDecoder = new TextDecoder();
            // 【2026-11-04 修复】reader.read 无数据超时保护：gateway 的 agent 循环若长时间不吐数据
            //（超长工具调用串行 / gateway 被杀连接半开），reader.read 会永久挂起，消息卡在 streaming。
            // 这里 180 秒没收到任何字节就 cancel reader，让 read 返回 done，走 finalize 落盘已生成部分。
            const IDLE_TIMEOUT_MS = 180000;
            let idleTimer = null;
            const resetIdle = () => {
              if (idleTimer) clearTimeout(idleTimer);
              idleTimer = setTimeout(() => { idleTimedOut = true; try { reader.cancel(); } catch {} }, IDLE_TIMEOUT_MS);
            };
            try {
              resetIdle();
              while (true) {
                const { done, value } = await reader.read();
                if (done) break;
                resetIdle();
                localParser.feed(localDecoder.decode(value, { stream: true }));
              }
            } catch (e) {
              if (e.name !== "AbortError") throw e;
            } finally {
              if (idleTimer) clearTimeout(idleTimer);
              localParser.flush();
              reader.releaseLock();
            }

            // SSE 流内错误事件（如 gateway "No inference provider configured"）仅在
            // 已产出内容时可忽略；空回复 + error 事件 → 保留 requestError，
            // 让下方错误分支展示真实原因，避免 UI 显示误导性的「(Gateway 连接失败)」
            if (fullReply || !requestError) requestError = null;
            break;

          } catch (e) {
            const errMsg = e.message || String(e);
            log(`Chat provider "${provider.name}" failed: ${errMsg}`);
            requestError = errMsg;
            if (isFallback) sendJSON({ info: `备选 "${provider.name}" 失败: ${errMsg}` });
          }
        }
        clearInterval(checkpointInterval);

        if (requestError !== null) {
          if (_isStale(sessionId, myGen)) {
            log(`[SSE] stale stream discarded session=${sessionId} gen=${myGen}`);
            send("[DONE]", "end");
            cleanup();
            controller.close();
            return;
          }
          // 即使失败，也要把已生成的部分回复保存下来，避免用户消息白发
          const partialContent = fullReply || `(请求失败: ${requestError})`;
          finalizeAssistantMessage(sessionId, partialContent, { tools: interruptPendingTools(responseTools), systemOverride, identity: replyIdentity }, streamId);
          sendJSON({ error: `所有模型均失败: ${requestError}` });
          // SSE 路径也写入缓存
          const sseCache = _streamResultCache.get(sessionId) || { status: 'error', reply: '', tools: [], error: '', waiters: [] };
          sseCache.status = 'error'; sseCache.error = requestError; sseCache.reply = fullReply; sseCache.msgFp = myFp;
          _streamResultCache.set(sessionId, sseCache);
          sseCache.waiters.forEach(w => w(sseCache)); sseCache.waiters = [];
          _cacheCleanup(sessionId);
          send("[DONE]", "end");
          cleanup();
          controller.close();
          return;
        }

        // 替换最近的 WS 助手消息（来自 WS→XHR 回退），使会话反映用户实际看到的内容
        //（即 XHR 响应），而非不完整的 WS 响应。
        let _assistantContent = fullReply || (hadToolCalls ? "（已执行工具，未生成文字回复）" : "（Gateway 连接失败）");
        if (idleTimedOut && fullReply) {
          _assistantContent = fullReply + "\n\n> *（这条回复在生成过程中长时间无响应，已被中断）*";
        }
        finalizeAssistantMessage(sessionId, _assistantContent, { tools: idleTimedOut ? interruptPendingTools(responseTools) : responseTools, systemOverride, identity: replyIdentity }, streamId);

        // 修复（2026-10-18）：getSession() 每次都从磁盘读新对象，本函数里的局部 session
        // 只装了自己 push 的那条用户消息（length=1）；助手消息是 finalizeAssistantMessage
        // 另读一份落盘的。因此原判定 `session.messages.length >= 2` 永远为假 → autoTitle
        // 从未触发，会话标题一直停在 "New Chat"。改为触发前重读磁盘拿真实状态。
        const _sTitleNow = getSession(sessionId);
        if (_sTitleNow && _sTitleNow.title === "New Chat" && (_sTitleNow.messages || []).length >= 2) {
          autoTitle(message, allProviders[0]).then(title => {
            const s2 = getSession(sessionId);
            if (s2 && s2.title === "New Chat") {
              s2.title = title;
              saveSession(s2);
            }
          }).catch(() => {});
        }

        // SSE 路径写入缓存
        if (_isStale(sessionId, myGen)) {
          log(`[SSE] stale stream skip cache session=${sessionId} gen=${myGen}`);
        } else {
          const sseCache2 = _streamResultCache.get(sessionId) || { status: 'done', reply: '', tools: [], error: '', waiters: [] };
          sseCache2.status = 'done'; sseCache2.reply = fullReply; sseCache2.tools = responseTools; sseCache2.msgFp = myFp;
          _streamResultCache.set(sessionId, sseCache2);
          sseCache2.waiters.forEach(w => w(sseCache2)); sseCache2.waiters = [];
          _cacheCleanup(sessionId);
        }

        send("[DONE]", "end");
      } catch (e) {
        clearInterval(checkpointInterval);
        if (_isStale(sessionId, myGen)) {
          log(`[SSE] stale stream error ignored session=${sessionId} gen=${myGen}`);
        } else {
          if (fullReply || responseTools.length) finalizeAssistantMessage(sessionId, (fullReply || "（已执行工具，未生成文字回复）") + "\n\n(流式处理异常中断: " + e.message + ")", { tools: interruptPendingTools(responseTools), systemOverride, identity: replyIdentity }, streamId);
          sendJSON({ error: e.message });
          const sseCache3 = _streamResultCache.get(sessionId) || { status: 'error', reply: '', tools: [], error: '', waiters: [] };
          sseCache3.status = 'error'; sseCache3.error = e.message; sseCache3.reply = fullReply || ''; sseCache3.msgFp = myFp;
          _streamResultCache.set(sessionId, sseCache3);
          sseCache3.waiters.forEach(w => w(sseCache3)); sseCache3.waiters = [];
          _cacheCleanup(sessionId);
        }
        send("[DONE]", "end");
      }
      cleanup();
      try { controller.close(); } catch {}
    },
  });
}

// 竞态修复（2026-08-24）：同一条消息已有 WS 流在 running 时，SSE 降级请求返回本「等待流」——
// 挂到缓存 waiters 上，原流完成/失败后按 SSE 格式转发结果，避免起第二个流互相覆盖
function createWaitStream(sessionId, cacheEntry) {
  const enc = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      const send = (data) => { try { controller.enqueue(enc.encode("data: " + JSON.stringify(data) + "\n\n")); } catch {} };
      const finish = () => { try { controller.enqueue(enc.encode("data: [DONE]\n\n")); controller.close(); } catch {} };
      const waiter = (result) => {
        try {
          if (result && result.status === 'done' && result.reply) {
            const chunkSize = 200;
            (async () => {
              for (let i = 0; i < result.reply.length; i += chunkSize) {
                send({ delta: result.reply.slice(i, i + chunkSize) });
                await new Promise(r => setTimeout(r, 5));
              }
              if (result.tools && result.tools.length) result.tools.forEach(t => send({ tool_progress: t }));
              send({ done: true });
              finish();
            })();
          } else if (result && result.status === 'error') {
            send({ error: result.error || 'Previous stream failed' });
            send({ done: true });
            finish();
          } else {
            send({ error: '等待上一轮回复超时，请重新发送消息' });
            send({ done: true });
            finish();
          }
        } catch (e) { try { controller.close(); } catch {} }
      };
      if (cacheEntry.waiters) cacheEntry.waiters.push(waiter);
      // 60 秒兜底超时（与 runChatWS 等待语义一致）
      setTimeout(() => { try { controller.close(); } catch {} }, 60000);
    },
  });
}

// 竞态修复（2026-08-24）：SSE 重发同一已完成消息时重放缓存结果，不重新调用 LLM（防重跑/内容漂移）
function createReplayStream(cacheEntry) {
  const enc = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      const send = (data) => { try { controller.enqueue(enc.encode("data: " + JSON.stringify(data) + "\n\n")); } catch {} };
      const finish = () => { try { controller.enqueue(enc.encode("data: [DONE]\n\n")); controller.close(); } catch {} };
      const reply = cacheEntry.reply || "";
      const chunkSize = 200;
      (async () => {
        for (let i = 0; i < reply.length; i += chunkSize) {
          send({ delta: reply.slice(i, i + chunkSize) });
          await new Promise(r => setTimeout(r, 5));
        }
        if (cacheEntry.tools && cacheEntry.tools.length) cacheEntry.tools.forEach(t => send({ tool_progress: t }));
        send({ done: true });
        finish();
      })();
    },
  });
}

// ─── WebSocket 聊天流式传输 ─────────────────────────────────────────────────
// 前端流程：POST /api/chat/ws-send 入队消息 → 建 ws://.../api/chat/ws 连接取流
const wsClients = new Map(); // session_id → ws

async function runChatWS(ws, sessionId, message, systemOverride, modelOverride, execution = {}) {
  const replyIdentity = execution.snapshot?.identity || sessionIdentity(sessionId, systemOverride);
  if (execution.requestId) replyIdentity.request_id = execution.requestId;
  systemOverride = execution.snapshot?.system ?? sessionSystem(sessionId, systemOverride || "");
  const sendJSON = (obj) => { try { ws.send(JSON.stringify(obj)); } catch {} };
  // 竞态修复（2026-08-24）：WS 路径补 streamId（与 createChatStream 一致）——checkpoint/finalize 只更新自己的流式消息
  const streamId = `${sessionId}:${Date.now()}:${Math.random().toString(36).slice(2, 10)}`;
  const myGen = _streamGenMap.get(sessionId) || 0;

  // 关键修复：检查是否已有同一会话的流在运行或已完成（WS 重连场景）
  // 如果有，等待已有流完成并返回缓存结果，避免重复请求 LLM
  const existingCache = _streamResultCache.get(sessionId);
  if (existingCache) {
    if (existingCache.status === 'done') {
      log(`[WS] cache hit (done) session=${sessionId}, sending cached result`);
      // 直接发送缓存的完整结果
      if (existingCache.reply) {
        const chunkSize = 200;
        for (let i = 0; i < existingCache.reply.length; i += chunkSize) {
          sendJSON({ delta: existingCache.reply.slice(i, i + chunkSize) });
          await new Promise(r => setTimeout(r, 5));
        }
      }
      if (existingCache.tools && existingCache.tools.length) {
        existingCache.tools.forEach(t => sendJSON({ tool_progress: t }));
      }
      sendJSON({ done: true });
      try { ws.close(1000); } catch {}
      return;
    }
    if (existingCache.status === 'running') {
      log(`[WS] cache hit (running) session=${sessionId}, waiting for existing stream...`);
      sendJSON({ info: '正在等待之前的回复完成…' });
      let _sentLen = 0;
      const result = await new Promise(resolve => {
        existingCache.waiters.push(resolve);
        const _push = setInterval(() => {
          try {
            const cur = existingCache.reply || "";
            if (cur.length > _sentLen) {
              sendJSON({ delta: cur.slice(_sentLen) });
              _sentLen = cur.length;
            }
          } catch {}
        }, 1000);
        setTimeout(() => { clearInterval(_push); resolve(null); }, 60000);
      });
      if (result && result.status === 'done') {
        log(`[WS] cache wait done session=${sessionId}, reply len=${result.reply.length}`);
        const _full = result.reply || "";
        for (let i = _sentLen; i < _full.length; i += 200) {
          sendJSON({ delta: _full.slice(i, i + 200) });
          await new Promise(r => setTimeout(r, 5));
        }
        if (result.tools && result.tools.length) {
          result.tools.forEach(t => sendJSON({ tool_progress: t }));
        }
        sendJSON({ done: true });
        try { ws.close(1000); } catch {}
        return;
      }
      log(`[WS] cache wait timeout session=${sessionId}, starting new stream`);
      // 重连且无新消息时无法起新流，直接告知错误
      if (message == null) {
        sendJSON({ error: '等待上一轮回复超时，请重新发送消息' });
        sendJSON({ done: true });
        try { ws.close(1000); } catch {}
        return;
      }
    }
    if (existingCache.status === 'error') {
      log(`[WS] cache hit (error) session=${sessionId}`);
      sendJSON({ error: existingCache.error || 'Previous stream failed' });
      sendJSON({ done: true });
      try { ws.close(1000); } catch {}
      return;
    }
  }

  // 重连场景但没有可用缓存（无新消息也无进行中/已完成的流）→ 告知并关闭
  if (message == null) {
    log(`[WS] reconnect without cache session=${sessionId}, closing`);
    sendJSON({ error: '没有进行中的回复，请重新发送消息' });
    sendJSON({ done: true });
    try { ws.close(1000); } catch {}
    return;
  }

  const stopCtrl = new AbortController();
  const abortExecution = () => stopCtrl.abort(execution.signal?.reason);
  execution.signal?.addEventListener('abort', abortExecution, {once:true});
  if (execution.signal?.aborted) abortExecution();
  ws.data.stopCtrl = stopCtrl;
  activeChatStreams.set(sessionId, stopCtrl);
  _turnStart.set(sessionId, Date.now());
  wsClients.set(sessionId, ws);
  sendJSON({ info: '正在思考…' });

  // 注册流结果缓存：WS 断开后 SSE fallback / WS 重连可复用
  const cacheEntry = { status: 'running', reply: '', tools: [], error: '', waiters: [], ws: ws, msgFp: _msgFp(message), streamId: streamId };
  _streamResultCache.set(sessionId, cacheEntry);

  const pingTimer = setInterval(() => { try { ws.ping(); } catch {} }, 30000);
  const keepaliveTimer = setInterval(() => { try { sendJSON({ keepalive: true }); } catch {} }, 15000);

  const cleanup = () => {
    execution.signal?.removeEventListener('abort', abortExecution);
    clearInterval(pingTimer);
    clearInterval(keepaliveTimer);
    // 【2026-09-23 修复】防"幽灵 running"：本流若在未走到正常收尾（status=done/error）
    // 就被 cleanup（早退路径：session not found / stale 丢弃），必须把缓存从 running
    // 改判 error。否则 ws-send 的排队分支会把后续所有消息永久判为 queued，
    // 前端轮询到超时后落进 SSE 兜底又触发硬中断 —— 排队机制死锁。
    try {
      if (cacheEntry && cacheEntry.status === 'running') {
        cacheEntry.status = 'error';
        cacheEntry.error = cacheEntry.error || 'stream ended before completion';
        cacheEntry.reply = cacheEntry.reply || '';
        try { cacheEntry.waiters.forEach(w => w(cacheEntry)); } catch {}
        cacheEntry.waiters = [];
      }
    } catch {}
    if (activeChatStreams.get(sessionId) === stopCtrl) activeChatStreams.delete(sessionId);
    wsClients.delete(sessionId);
  };

  let checkpointInterval = null;
  let fullReply = "";
  let responseTools = [];
  let session = null;
  try {
    const normalizedMessage = await normalizeMessage(message);
    session = getSession(sessionId);
    if (!session) { sendJSON({ error: "session not found" }); sendJSON({ done: true }); cleanup(); return; }

    // 去重：防止边界情况（如并发调用）下出现重复用户消息
    const _wsLastMsg = session.messages[session.messages.length - 1];
    const _wsIsSameMsg = execution.requestId ? session.messages.some(m => m.role === 'user' && m.request_id === execution.requestId) : _wsLastMsg && _wsLastMsg.role === "user" &&
      JSON.stringify(_wsLastMsg.content) === JSON.stringify(normalizedMessage);
    const _wsSwept = sweepStaleStreaming(session);
    if (!_wsIsSameMsg) {
      session.messages.push({ role: "user", content: normalizedMessage, ts: Date.now(), ...(execution.snapshot?.user_identity || {}), ...(execution.requestId ? {request_id:execution.requestId} : {}) });
      saveSession(session);
    } else if (_wsSwept) {
      saveSession(session);
    }

    // 智能上下文：保留首条用户消息 + 最近 MAX_HISTORY_MESSAGES 条
    // systemOverride（persona / 专家团提示）注入 system prompt，避免污染用户消息历史
    const history = buildChatHistory(session, (systemOverride ? systemOverride + "\n\n" : "") + UI_CAPABILITIES_PROMPT);

    // 改动3（2026-09-21）：长任务先推占位消息
    checkpointAssistantMessage(sessionId, "开始处理…", streamId, undefined, replyIdentity);

    const cfg = await getChatConfig();
    const allProviders = resolveChatProviders(cfg, modelOverride);

    let requestError = null;
    let hadToolCalls = false;

    // 每 5 秒 / 每 1000 字符做一次增量 checkpoint
    let lastCheckpointLen = 0;
    let lastCheckpointTs = Date.now();
    checkpointInterval = setInterval(() => {
      if (_isStale(sessionId, myGen)) return; // 已被新消息取代的流不再 checkpoint
      if ((fullReply.length > 0 || responseTools.length > 0) && (fullReply.length - lastCheckpointLen >= 1000 || Date.now() - lastCheckpointTs >= 5000)) {
        checkpointAssistantMessage(sessionId, fullReply || "开始处理…", streamId, responseTools, replyIdentity);
        lastCheckpointLen = fullReply.length;
        lastCheckpointTs = Date.now();
      }
    }, 1000);

    let timedOutByTimer = false;
    for (let i = 0; i < allProviders.length; i++) {
      if (stopCtrl.signal.aborted) break;
      const provider = allProviders[i];
      const isFallback = i > 0;
      if (isFallback) sendJSON({ info: `主模型超时，切换备选: ${provider.name}...` });

      let timeoutTimer;
      timedOutByTimer = false;
      try {
        requestError = null;
        hadToolCalls = false;
        let usageReported = false;
        const timeoutController = new AbortController();
        // 空闲计时：只要上游还在吐数据（文本/思考/工具进度）就重置，
        // 只有连续 PROVIDER_TIMEOUT_MS 没有任何事件才判定超时中断。
        // 旧写法在请求开始时定一个绝对 5 分钟上限，长工具链会被无差别砍断。
        const armTimeout = (ms) => {
          if (timeoutTimer) clearTimeout(timeoutTimer);
          timeoutTimer = setTimeout(() => { timedOutByTimer = true; timeoutController.abort(); }, ms || PROVIDER_TIMEOUT_MS);
        };
        armTimeout();
        const signal = combineSignals([timeoutController.signal, stopCtrl.signal]);

        const upstream = await chatRequest(provider, normalizedMessage, history, signal, sessionId);
            {const linked=getSession(sessionId);if(linked&&recordGatewaySession(linked,upstream,{streamId}))saveSession(linked);}

        const localParser = createSSEParser(
          (delta) => { armTimeout(); fullReply += delta; sendJSON({ delta }); cacheEntry.reply = fullReply; },
          () => {},
          (err) => { requestError = err; sendJSON({ error: err }); cacheEntry.error = err; },
          (toolEvent) => {
            armTimeout();
            hadToolCalls = true;
            sendJSON({ tool_progress: toolEvent });
            const _tid = toolEvent.toolCallId || toolEvent.tool || "tool";
            const _ex = responseTools.find(t => (t.toolCallId || t.tool) === _tid);
            if (_ex) {
              if (toolEvent.status) _ex.status = toolEvent.status;
              if (toolEvent.result) _ex.result = String(toolEvent.result).slice(0, 4000);
              if (toolEvent.emoji) _ex.emoji = toolEvent.emoji;
              const _lbl = toolEvent.label || toolEvent.command || toolEvent.summary;
              if (_lbl) _ex.label = _lbl;
              if (toolEvent.toolZh) _ex.toolZh = toolEvent.toolZh;
            } else {
              responseTools.push({
                tool: toolEvent.tool,
                toolCallId: toolEvent.toolCallId,
                status: toolEvent.status || "done",
                emoji: toolEvent.emoji || "",
                label: toolEvent.label || toolEvent.command || toolEvent.summary || "",
                toolZh: toolEvent.toolZh || toolEvent.tool || "工具",
                result: (toolEvent.result || "").slice(0, 4000),
              });
            }
            cacheEntry.tools = responseTools.slice();
            checkpointAssistantMessage(sessionId, fullReply || "开始处理…", streamId, responseTools, replyIdentity);
          },
          (usage) => {
            usageReported = true;
            try {
              const s = getSession(sessionId);
              if (s) {
                s.lastUsage = usageSummary(usage,{provider});
                saveSession(s);
              }
            } catch {}
            sendJSON({ usage });
          },
          (r) => { armTimeout(); sendJSON({ reasoning: r }); },
          (clarifyEvent) => {
            /* 2026-11-12：clarify 是「等人点按钮」，不是「模型卡住」。
             * 以前这里沿用 300s 空闲超时，用户没在 5 分钟内点选，整轮直接被判
             * 「模型 5 分钟没有返回任何数据」中断（14:22 那次就是这么死的，
             * clarify 自己配的是 600s，压根等不到）。等待窗口按 clarify_timeout
             * 放宽，回答后正常的工具事件会把计时器重新收紧回 300s。 */
            armTimeout(clarifyWaitMs());
            sendJSON({ clarify: clarifyEvent });
            log(`[Clarify] request pushed session=${sessionId} id=${clarifyEvent && clarifyEvent.clarify_id} wait=${Math.round(clarifyWaitMs() / 1000)}s`);
          },
        );

        const reader = upstream.body.getReader();
        const localDecoder = new TextDecoder();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            localParser.feed(localDecoder.decode(value, { stream: true }));
          }
        } catch (e) {
          if (e.name !== "AbortError" || !stopCtrl.signal.aborted) throw e;
        } finally {
          localParser.flush();
          reader.releaseLock();
        }

        if (!requestError) requestError = null;
        break;
      } catch (e) {
        const errMsg = timedOutByTimer
          ? `模型 ${Math.round(PROVIDER_TIMEOUT_MS / 60000)} 分钟没有返回任何数据（超时中断）`
          : (e.message || String(e));
        log(`Chat provider "${provider.name}" failed: ${errMsg}`);
        requestError = errMsg;
        if (isFallback) sendJSON({ info: `备选 "${provider.name}" 失败: ${errMsg}` });
        // Once tools or content appeared, retrying on another provider may repeat side effects.
        if (fullReply || hadToolCalls || stopCtrl.signal.aborted) break;
      } finally {
        clearTimeout(timeoutTimer);
      }
    }

    clearInterval(checkpointInterval);
    if (_isStale(sessionId, myGen)) {
      // 已被新消息取代：丢弃本流结果，不 finalize、不写缓存（防旧流覆盖新流/复活缓存）
      log(`[WS] stale stream discarded session=${sessionId} gen=${myGen}`);
      sendJSON({ done: true });
      cleanup();
      return;
    }
    if (stopCtrl.signal.aborted) {
      finalizeAssistantMessage(sessionId, (fullReply || '（执行已中断）') + (fullReply ? '\n\n（执行已中断）' : ''), {tools:interruptPendingTools(responseTools),identity:replyIdentity,systemOverride,queueStatus:'interrupted'},streamId);
      cacheEntry.status='error';cacheEntry.error='执行已中断';cacheEntry.reply=fullReply;
    } else if (requestError !== null) {
      const partialContent = fullReply || (hadToolCalls
        ? `（本轮中断：${requestError}；已执行 ${responseTools.length} 个工具调用，发「继续」接着跑）`
        : `(请求失败: ${requestError})`);
      finalizeAssistantMessage(sessionId, partialContent, { tools: interruptPendingTools(responseTools), systemOverride, identity: replyIdentity, queueStatus:'failed', errorCode: timedOutByTimer ? 'provider_timeout' : 'provider_error' }, streamId);
      sendJSON({ error: `所有模型均失败: ${requestError}` });
      cacheEntry.status = 'error'; cacheEntry.error = requestError; cacheEntry.reply = fullReply;
    } else {
      finalizeAssistantMessage(sessionId, fullReply || (hadToolCalls ? "（已执行工具，未生成文字回复）" : "（模型没有返回内容）"), { tools: responseTools, systemOverride, identity: replyIdentity, queueStatus:fullReply||hadToolCalls?'done':'failed' }, streamId);
      if (!fullReply && !hadToolCalls) { requestError='模型没有返回内容';sendJSON({error:requestError}); }
      cacheEntry.status = requestError ? 'error' : 'done'; cacheEntry.error = requestError || ''; cacheEntry.reply = fullReply; cacheEntry.tools = responseTools;
    }

    // 修复（2026-10-18）：同 SSE 路径——局部 session 只有自己 push 的用户消息，
    // 必须重读磁盘才能看到 finalize 落盘的助手消息，否则判定永假、autoTitle 不触发。
    const _sTitleNowWs = getSession(sessionId);
    if (!requestError && _sTitleNowWs && _sTitleNowWs.title === "New Chat" && (_sTitleNowWs.messages || []).length >= 2) {
      autoTitle(message, allProviders[0]).then(title => {
        const s2 = getSession(sessionId);
        if (s2 && s2.title === "New Chat") { s2.title = title; saveSession(s2); }
      }).catch(() => {});
    }
    sendJSON({ done: true });
    // 通知 SSE fallback 等待者
    cacheEntry.waiters.forEach(w => w(cacheEntry));
    cacheEntry.waiters = [];
    _cacheCleanup(sessionId);
  } catch (e) {
    clearInterval(checkpointInterval);
    if (_isStale(sessionId, myGen)) {
      // 过期流异常：不 finalize、不写缓存（否则 fallback 可能覆盖新流消息）
      log(`[WS] stale stream error ignored session=${sessionId} gen=${myGen} err=${e.message || String(e)}`);
    } else {
      if (fullReply || responseTools.length) finalizeAssistantMessage(sessionId, (fullReply || "（已执行工具，未生成文字回复）") + "\n\n(流式处理异常中断: " + e.message + ")", { tools: interruptPendingTools(responseTools), systemOverride, identity: replyIdentity, queueStatus:'failed' }, streamId);
      sendJSON({ error: e.message || String(e) });
      sendJSON({ done: true });
      cacheEntry.status = 'error'; cacheEntry.error = e.message || String(e); cacheEntry.reply = fullReply || '';
      cacheEntry.waiters.forEach(w => w(cacheEntry));
      cacheEntry.waiters = [];
      _cacheCleanup(sessionId);
    }
    // 不回写入口处的旧 session：checkpoint/finalize 已重读并保存最新消息。
  }
  cleanup();
}

// The durable queue is the owner of panel executions; the socket-like sink only
// adapts the existing tested tool/stream runner. No browser is needed to run it.
const panelChatQueue = new ChatQueue({
  root: join(VAR_DIR, 'panel-state', 'queue'),
  available: job => !shuttingDown && !panelRuntime.status().restart_pending && prevState.gwHealth && !activeChatStreams.has(job.session_id) && !!readPidSync(PID_GATEWAY) && pidAliveSync(readPidSync(PID_GATEWAY)),
  onInterrupted: job => {
    const session = getSession(job.session_id);
    if (!session) return null;
    const message = recoverInterruptedAssistantMessage(session, job);
    if (!message) return null;
    saveSession(session);
    return {reply: message.content || '', tools: message.tools || []};
  },
  reconcile: job => {
    const s=getSession(job.session_id),m=s?.messages?.find(m=>m.role==='assistant'&&m.request_id===job.id&&!m._streaming&&m.queue_status);
    if(!m)return null;
    return {status:job.cancel_requested_at?'cancelled':m.queue_status,result:{reply:m.content||'',tools:m.tools||[]}};
  },
  execute: async (job,{signal,emit}) => {
    const sid=job.session_id,p=job.payload;
    /* 思考强度是 job 级语义：提交时就固化在 payload.model_options。worker 消费可能滞后，
       若只读 session 级 Map 会读到「最新一条」的档位（实测连发 off/low/medium/high，
       medium 那条被记成 high）。执行前用本条 job 自己的档位还原 Map，日志才准。 */
    noteSessionReasoning(sid, p.model_options);
    _streamResultCache.delete(sid); _bumpGen(sid);
    const sink={data:{},send:raw=>emit(JSON.parse(raw)),ping(){},close(){}};
    await runChatWS(sink,sid,p.message,p.system,{model:p.model||'',provider:p.provider||''},{signal,requestId:job.id,snapshot:job.snapshot});
    const saved=getSession(sid)?.messages?.find(m=>m.role==='assistant'&&m.request_id===job.id&&!m._streaming&&m.queue_status);
    if(!saved){
      // Queue already has the stream checkpoint; preserve that result and flag the failed transcript save.
      throw Error('回复未能完整写入会话，执行记录已保留，请检查存储后恢复。');
    }
    return {status:saved.queue_status,result:{reply:saved.content,tools:saved.tools||[]}};
  },
  onFault:e=>log('[panel-queue] '+e.message),
});
const panelRoomStore = new RoomStore({root:join(VAR_DIR,'panel-state'),legacyFile:join(DATA_DIR,'rooms.json'),expert:getExpert,identity:()=>readWorkspace().identity});
const panelRoomRunner = new RoomRunner({store:panelRoomStore,reconcile:id=>{try{const saved=panelChatQueue.get(id);if(saved.status==='pending'){panelChatQueue.cancel(id);return panelChatQueue.get(id);}return saved;}catch(error){if(error.status===404)return null;throw error;}},onFault:error=>log('[panel-rooms] '+error.message),
  execute:createRoomExecution({queue:panelChatQueue,userIdentity:()=>{const i=readWorkspace().identity;return {sender:i.user_name,sender_avatar:i.user_avatar,sender_kind:'user'};},
    ensureSession:(id,job)=>{if(!getSession(id))saveSession({id,title:job.member.label+' · 专家讨论',group:'room_'+job.room_id,messages:[],created_at:Date.now(),updated_at:Date.now()});}})});
const handlePanelRooms=createRoomHandler({store:panelRoomStore,runner:panelRoomRunner,checkToken,modelCatalog:()=>panelModelChecks.source({action:"catalog"})});
const panelFileRoots=createFileRoots({data:DATA_DIR,varDir:VAR_DIR,librarySources:createLibrarySources(DATA_DIR)});
const handlePanelFiles=createFileHandler({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),state:join(VAR_DIR,'panel-state'),roots:panelFileRoots,data:DATA_DIR,varDir:VAR_DIR,basePath:BASE_PATH,checkToken});
const handlePanelUpdate=createUpdateHandler({
  currentVersion:()=>{
    // Windows 安装器把版本写进 app/version.json；manifest 只在 fpk 里才有
    for(const f of [join(APP_DIR,'version.json'), join(APP_DIR,'..','version.json')]){
      try{ const j=JSON.parse(readFileSync(f,'utf8')); if(j&&j.version) return String(j.version).trim(); }catch{}
    }
    return reloadAppVersion();
  },
  platform:process.platform,
});
const panelConfigRecovery=createConfigRecovery({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),home:DATA_DIR,state:join(VAR_DIR,'panel-state'),checkToken,changed:reason=>panelRuntime.changed(reason)});
const serviceHealth=new ServiceHealth({gateway:{url:`http://127.0.0.1:${GATEWAY_PORT}/health/detailed`,token:()=>MONITOR_TOKEN},dashboard:{url:`http://${DASHBOARD_BIND}:${DASHBOARD_PORT}/api/status`,token:()=>DASHBOARD_SESSION_TOKEN},identity:kind=>serviceProcesses.read(kind)||serviceProcesses.find(kind)});
const panelDrain=new PanelDrain({python:join(VENV_BIN,PY_BIN),root:join(VAR_DIR,'panel-state'),identity:()=>serviceProcesses.read('gateway')||serviceProcesses.find('gateway'),health:serviceHealth});
// 会话活动探针：不只看「最后写消息的时间」，还看 sessions.last_activity_description ——
// 那是 gateway 自己写的实时状态（"receiving stream response" / "starting API call #1" / 空=一轮结束）。
// 只按 busy 快照判会在别人刚说完最后一句的下一秒放行（2026-11-20 06:37:02 派发、06:37:03 还在写）；
// 只看时间戳又会在长生成里静默 90 秒就当成空闲。两样合起来才够。
// desc 非空且不超 10 分钟 = 这轮还活着，硬忙；desc 空 = 一轮结束，交给静默窗口。查询 1ms，缓 4 秒。
const ACTIVE_DESC_TTL=600;
let actCache={at:0,value:{at:0,desc:'',age:1e9,sid:''}};
function sessionActivity(){
 const now=Date.now();
 if(now-actCache.at<4000)return actCache.value;
 let value={at:0,desc:'',age:1e9,sid:''};
 try{
  const probe=[
   'import sqlite3,sys,time,json',
   "c=sqlite3.connect('file:'+sys.argv[1]+'?mode=ro',uri=True,timeout=5)",
   'rows=c.execute("select id,last_activity_at,coalesce(last_activity_description,\'\') from sessions'
    +' where coalesce(last_activity_at,0)>? order by last_activity_at desc limit 8",(time.time()-7200,)).fetchall()',
   'print(json.dumps(rows))'].join('\n');
  const r=spawnSync(`${VENV_BIN}/${PY_BIN}`,['-c',probe,`${DATA_DIR}/state.db`],{encoding:'utf8',timeout:5000});
  const rows=JSON.parse(String(r.stdout||'[]').trim()||'[]');
  const t=Math.floor(Date.now()/1000);
  let at=0, pick=null;
  for(const row of rows){
   const ts=Number(row[1])||0, desc=String(row[2]||'').trim(), age=t-ts;
   if(ts>at)at=ts;
   if(desc&&age>=0&&age<=ACTIVE_DESC_TTL&&(!pick||age<pick.age))pick={desc,age,sid:String(row[0]||'')};
  }
  value=Object.assign({at,desc:'',age:1e9,sid:''},pick||{});
 }catch{}
 actCache={at:now,value};
 return value;
}
const panelRuntime=new PanelRuntime({receipt:createRestartReceipt({python:join(VENV_BIN,PY_BIN),app:APP_DIR,home:DATA_DIR,varDir:VAR_DIR}),drain:panelDrain,prepare:()=>serviceHealth.refresh(),observation:()=>serviceHealth.snapshot(),activity:sessionActivity,quietSeconds:90,recovery:()=>panelConfigRecovery.status(),root:join(VAR_DIR,'panel-state'),source:join(DATA_DIR,'workspace/fnos-hermes-agent-src'),started:START_TIME,available:()=>{const s=serviceHealth.snapshot();return s.gateway.healthy&&s.dashboard.healthy;},busy:()=>serviceHealth.snapshot().gateway.busy===true||activeChatStreams.size>0||panelChatQueue.workers.size>0||panelLibraryReviews.workers.size>0||panelModelChecks.workers.size>0});
const handlePanelRuntime=createRuntimeHandler({runtime:panelRuntime,checkToken});
const handleRestartIngress=createRestartIngress({runtime:panelRuntime,checkToken});
const observePanelChannels=createChannelRuntime({home:DATA_DIR,gatewayPid:()=>readPid(PID_GATEWAY),hermesBin:HERMES_BIN});
const panelChannels=createChannelsService({observe:observePanelChannels,python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),getConfig:()=>HERMES_CONFIG,state:join(VAR_DIR,'panel-state'),checkToken,changed:reason=>panelRuntime.changed(reason)});
const panelPairing=new ChannelPairing({root:join(VAR_DIR,'panel-state'),channels:panelChannels,allowedChannels:['weixin','qqbot','telegram','wecom']});
const handlePanelChannelIngress=createChannelIngress({channels:panelChannels,pairing:createPairingHandler({pairing:panelPairing,checkToken}),checkToken});
const panelModels=createModelsService({varRoot:VAR_DIR,python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),getConfig:()=>{const profile=_cronProfileName();return profile&&profile!=='default'?join(DATA_DIR,'profiles',safeId(profile),'config.yaml'):HERMES_CONFIG;},state:join(VAR_DIR,'panel-state'),changed:reason=>panelRuntime.changed(reason)});
const handlePanelMcp=createMcpHandler({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),getConfig:()=>{const profile=_cronProfileName();return profile&&profile!=='default'?join(DATA_DIR,'profiles',safeId(profile),'config.yaml'):HERMES_CONFIG;},state:join(VAR_DIR,'panel-state'),checkToken,changed:reason=>panelRuntime.changed(reason)});
const handlePanelTyping=createTypingHandler({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),getConfig:()=>{const profile=_cronProfileName();return profile&&profile!=='default'?join(DATA_DIR,'profiles',safeId(profile),'config.yaml'):HERMES_CONFIG;},state:join(VAR_DIR,'panel-state'),platforms:()=>CHANNEL_DEFS,checkToken,changed:reason=>panelRuntime.changed(reason)});
const panelLibraryStore=new LibraryStore({root:join(VAR_DIR,'panel-state'),sources:createLibrarySources(DATA_DIR)});
const panelLibraryReviews=new LibraryReviews({root:join(VAR_DIR,'panel-state/library-reviews'),library:panelLibraryStore,source:body=>panelModelChecks.source(body)});
try{panelLibraryReviews.load();}catch(error){panelLibraryReviews.fault=error;log('[library-reviews] '+error.message);}
const handlePanelLibraryReviews=createLibraryReviewHandler({reviews:panelLibraryReviews,checkToken});
const handlePanelLibrary=createLibraryHandler({store:panelLibraryStore,checkToken});
const handleArchiveVault=createArchiveVault({dataDir:DATA_DIR,checkToken,python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),state:join(VAR_DIR,'panel-state')});
const panelPlanStore=new PlanStore({root:join(VAR_DIR,'panel-state'),legacyConfig:CONFIG_FILE,legacyFlows:join(DATA_DIR,'flows'),expert:getExpert});
const handlePanelPlans=createPlanHandler({store:panelPlanStore,checkToken,launch:createPlanLaunch({queue:panelChatQueue,
 ensureSession:(id,title)=>{if(!getSession(id))saveSession({id,title,messages:[],created_at:Date.now(),updated_at:Date.now()});},
 attachPlan:bindSessionPlan,capture:id=>sessionSnapshot(id),guard:toolGuardCheckAndRespond})});
const handlePanelQueue=createQueueHandler({queue:panelChatQueue,checkToken,sessionExists:id=>!!getSession(id),
  capture:body=>sessionSnapshot(body.session_id,body.system||''),guard:toolGuardCheckAndRespond,
  noteReasoning:noteSessionReasoning});

// Dashboard WS 反代：带自动重连的 upstream 连接管理
function setupDashboardProxy(ws) {
  const { targetUrl } = ws.data;
  ws.data.sendQueue = [];
  ws.data.reconnectAttempts = 0;
  ws.data.supersededCount = 0;   // v0.21.148：连续 4409（superseded）计数，防连接活锁
  ws.data.reconnectTimer = null;
  ws.data.closing = false;

  function cleanup() {
    ws.data.closing = true;
    if (ws.data.reconnectTimer) { clearTimeout(ws.data.reconnectTimer); ws.data.reconnectTimer = null; }
    if (ws.data.kaTimer) { clearInterval(ws.data.kaTimer); ws.data.kaTimer = null; }
    if (ws.data.upstream) {
      // v0.21.148：先移除监听器再终止，防止旧连接 close/error 回调在 cleanup 后继续触发重连
      try { ws.data.upstream.removeAllListeners(); } catch {}
      try { ws.data.upstream.terminate(); } catch {}
      ws.data.upstream = null;
    }
  }

  function flushQueue() {
    const q = ws.data.sendQueue || [];
    ws.data.sendQueue = [];
    const up = ws.data.upstream;
    if (up && up.readyState === WebSocket.OPEN) {
      for (const item of q) {
        try { up.send(item.d, { binary: item.b }); } catch {}
      }
    }
  }

  function scheduleReconnect() {
    if (ws.data.closing || ws.readyState !== WebSocket.OPEN) return;
    const attempt = ws.data.reconnectAttempts;
    if (attempt >= 10) {
      log(`[WS-PROXY] upstream reconnect exhausted, closing client`);
      cleanup();
      try { ws.close(1011, "upstream reconnect exhausted"); } catch {}
      return;
    }
    const delay = Math.min(1000 * Math.pow(2, attempt), 30000);
    ws.data.reconnectAttempts = attempt + 1;
    log(`[WS-PROXY] upstream abnormal close, reconnect in ${delay}ms (attempt ${ws.data.reconnectAttempts})`);
    ws.data.reconnectTimer = setTimeout(() => connectUpstream(), delay);
  }

  function connectUpstream() {
    if (ws.data.closing || ws.readyState !== WebSocket.OPEN) return;
    // v0.21.148：清理旧上游连接的监听器并终止，避免被替换的旧连接在 close/error 时
    // 继续回调 connectUpstream → 多连接并发风暴（V8 堆累积到 GB 级的主因）
    try {
      const _old = ws.data.upstream;
      if (_old) {
        _old.removeAllListeners();
        if (_old.readyState === WebSocket.OPEN || _old.readyState === WebSocket.CONNECTING) { try { _old.terminate(); } catch {} }
      }
    } catch {}
    try {
      const upstream = new WebSocket(targetUrl, {
        headers: {
          "Host": `${DASHBOARD_BIND}:${DASHBOARD_PORT}`,
          "X-Hermes-Session-Token": DASHBOARD_SESSION_TOKEN,
        },
      });
      ws.data.upstream = upstream;
      upstream.on("open", () => {
        ws.data.reconnectAttempts = 0;
        ws.data.supersededCount = 0;
        log(`[WS-PROXY] upstream connected`);
        flushQueue();
      });
      upstream.on("message", (data, isBinary) => {
        if (ws.readyState !== WebSocket.OPEN) return;
        const path = ws.data.targetUrl?.replace(/\?.*$/, "") || "unknown";
        const isJsonPath = path.endsWith("/api/ws") || path.endsWith("/api/events");
        try {
          if (isJsonPath) {
            // 同样转成文本帧，保证浏览器 FJ/VJ 客户端收到的是可 JSON.parse 的文本。
            const payload = Buffer.isBuffer(data) ? data.toString("utf8") : (typeof data === "string" ? data : String(data));
            ws.send(payload, { binary: false });
          } else {
            // 关键：保留上游帧类型（文本帧→文本帧、二进制帧→二进制帧）。
            // 此前一律 ws.send(data)（Buffer）会把服务端文本帧（如 speak-stream 的
            // {"type":"fallback"}）转成二进制帧，前端 JSON.parse 失败、PCM 帧也区分不了。
            // /api/pty 的 Python 端同时接受 text/bytes 不受影响。
            ws.send(data, { binary: isBinary });
          }
        } catch {}
      });
      upstream.on("close", (code, reason) => {
        log(`[WS-PROXY] upstream closed code=${code}`);
        if (ws.data.closing || ws.readyState !== WebSocket.OPEN) return;
        if (code === 4409) {
          // 4409 = WS_CLOSE_SUPERSEDED：另一个 WebSocket Attach 到同一 PTY session。
          // v0.21.148：修复"连接活锁"——此前无限递归 connectUpstream() 无次数限制，
          // 多个前端（多 TUI + WebUI）attach 同一 session 时乒乓互踢 → V8 堆暴涨（实测 1.8GB）。
          // 现在：连续 4 次 superseded 后放弃重连，通知浏览器自行处理（避免死循环）；期间指数退避。
          const n = (ws.data.supersededCount || 0) + 1;
          ws.data.supersededCount = n;
          if (n >= 4) {
            log(`[WS-PROXY] upstream superseded ${n} 次（多前端争抢同一会话），放弃重连，通知浏览器`);
            cleanup();
            try { ws.close(1011, "upstream superseded, give up"); } catch {}
            return;
          }
          const delay = Math.min(500 * Math.pow(2, n - 1), 8000); // 0.5s → 1s → 2s
          log(`[WS-PROXY] upstream superseded #${n}，${delay}ms 后重试`);
          ws.data.reconnectTimer = setTimeout(() => connectUpstream(), delay);
          return;
        }
        // 1006（异常关闭）及 dashboard 偶发断连均尝试重连，而非直接断开浏览器客户端
        if (code === 1006 || code === 1001 || code === 1011 || code >= 4000) {
          scheduleReconnect();
          return;
        }
        // 其他正常关闭码（1000）透传给浏览器
        cleanup();
        try { ws.close(code, reason?.toString ? reason.toString() : reason); } catch {}
      });
      upstream.on("error", (err) => {
        log(`[WS-PROXY] upstream error: ${err?.message || err}`);
        // 连接错误也触发重连，避免上游临时不可用导致永久断开
        if (!ws.data.closing && ws.readyState === WebSocket.OPEN && !ws.data.reconnectTimer) {
          scheduleReconnect();
        }
      });
    } catch (e) {
      log(`[WS-PROXY] upstream connect failed: ${e?.message || e}`);
      scheduleReconnect();
    }
  }

  const kaTimer = setInterval(() => {
    try { if (ws.readyState === WebSocket.OPEN) ws.ping(); } catch {}
    const up = ws.data.upstream;
    if (up && up.readyState === WebSocket.OPEN) { try { up.ping(); } catch {} }
  }, 30000);
  ws.data.kaTimer = kaTimer;

  log(`[WS-PROXY] open → dashboard`);
  connectUpstream();
}

// WebSocket 连接建立后的事件处理（替换 Bun 的 wsHandler.open/message/close）
function attachWsHandlers(ws) {
  // Dashboard WS 反代
  if (ws.data.type === "dashboard-proxy") {
    setupDashboardProxy(ws);
  } else {
    // 聊天 WS
    const { sessionId, message, system, model, provider } = ws.data;
    log(`[WS] open session=${sessionId}`);
    runChatWS(ws, sessionId, message, system, { model: model || "", provider: provider || "" }).catch(err => {
      log(`[WS] runChatWS error: ${err?.message || err}`);
      try { ws.send(JSON.stringify({ error: err?.message || "internal error" })); } catch {}
      try { ws.send(JSON.stringify({ done: true })); } catch {}
    });
  }

  ws.on("message", (data, isBinary) => {
    if (ws.data.type === "dashboard-proxy") {
      const up = ws.data.upstream;
      const path = ws.data.targetUrl?.replace(/\?.*$/, "") || "unknown";
      // gateway 的 /api/ws（JSON-RPC 边车）与 /api/events（事件订阅）都用 receive_text() 收 JSON。
      // ws 库默认把收到的消息以 Buffer 形式回调，若原样 up.send(Buffer) 会被当成 binary 帧转发，
      // 触发 gateway KeyError:'text' 并导致前端 FJ 客户端显示 "WebSocket closed"。
      // 因此这两条路径一律把 Buffer 转成 UTF-8 文本、并以 text 帧上行；其它路径（如 /api/pty）保持原样。
      const isJsonPath = path.endsWith("/api/ws") || path.endsWith("/api/events");
      if (isJsonPath) {
        const payload = Buffer.isBuffer(data) ? data.toString("utf8") : (typeof data === "string" ? data : String(data));
        if (up && up.readyState === WebSocket.OPEN) {
          try { up.send(payload, { binary: false }); } catch {}
        } else if (!ws.data.closing) {
          ws.data.sendQueue = ws.data.sendQueue || [];
          ws.data.sendQueue.push({ d: payload, b: false });
        }
        return;
      }
      if (up && up.readyState === WebSocket.OPEN) {
        // 同样保留客户端帧类型：浏览器发送的 {"text":...}/{"stop":true} 是文本帧，
        // speak-stream 服务端用 receive_text() 读取，转成二进制帧会抛错；/api/pty 输入同时兼容。
        try { up.send(data, { binary: isBinary }); } catch {}
      } else if (!ws.data.closing) {
        ws.data.sendQueue = ws.data.sendQueue || [];
        ws.data.sendQueue.push({ d: data, b: isBinary });
      }
      return;
    }
    // Chat WS：前端可发送 {"stop":true} 主动中断
    try {
      const msg = data.toString();
      const d = JSON.parse(msg);
      if (d.stop && ws.data.stopCtrl) ws.data.stopCtrl.abort();
    } catch {}
  });

  ws.on("close", () => {
    if (ws.data.type === "dashboard-proxy") {
      ws.data.closing = true;
      if (ws.data.reconnectTimer) { clearTimeout(ws.data.reconnectTimer); ws.data.reconnectTimer = null; }
      if (ws.data.kaTimer) { clearInterval(ws.data.kaTimer); ws.data.kaTimer = null; }
      if (ws.data.upstream) { try { ws.data.upstream.terminate(); } catch {} }
      log(`[WS-PROXY] client closed`);
      return;
    }
    const { sessionId, stopCtrl } = ws.data;
    log(`[WS] close session=${sessionId} (stream continues, SSE fallback can reuse result)`);
    wsClients.delete(sessionId);
    // 关键修复：不再 abort 流！让 LLM 请求自然完成，结果缓存到 _streamResultCache
    // SSE fallback 请求 /api/chat/stream 时可复用已完成的流结果，保证回答完整性
    // stopCtrl 仅在用户主动停止时通过 ws.on("message") 中的 {stop:true} 触发
  });
}

function beijingTime() {
  const d = new Date(Date.now() + 8 * 3600000);
  return d.toISOString().replace("T", " ").replace(/\.\d+Z$/, "");
}
function log(...args) {
  const msg = `[monitor] ${beijingTime()} ${args.join(" ")}`;
  console.log(msg);
  try { writeFileSync(LOG_FILE, msg + "\n", { flag: "a" }); } catch {}
}

function pidAlive(pid) {
  try { process.kill(pid, 0); return true; }
  catch { return false; }
}

function readPid(path) {
  const kind=path===PID_GATEWAY?'gateway':path===PID_DASHBOARD?'dashboard':null;
  return kind?serviceProcesses.read(kind)?.pid||null:null;
}

async function portAlive(port, host = "localhost", timeoutMs = 2000) {
  try {
    const r = await fetch(`http://${host}:${port}/`, {
      method: "OPTIONS",
      signal: AbortSignal.timeout(timeoutMs),
    });
    return r.ok || r.status === 405;
  } catch { return false; }
}

// 直接读 /proc/net/tcp[6] 判断本机是否有进程在指定端口 LISTEN。
// 适用于非 HTTP 的内部端口（如 8742 网关通信端口），不受 HTTP 探活失败或
// localhost 解析为 IPv6 影响，比 portAlive 的 HTTP OPTIONS 探测更可靠。
function isPortListening(port) {
  const suffix = ":" + Number(port).toString(16).toUpperCase().padStart(4, "0");
  for (const f of ["/proc/net/tcp", "/proc/net/tcp6"]) {
    try {
      const lines = readFileSync(f, "utf8").split("\n");
      for (let i = 1; i < lines.length; i++) {
        const parts = lines[i].trim().split(/\s+/);
        if (parts.length < 4) continue;
        // parts[1]=local_address(HEX_IP:HEX_PORT)  parts[3]=st(0A=LISTEN)
        if (parts[3] === "0A" && parts[1] && parts[1].toUpperCase().endsWith(suffix)) {
          return true;
        }
      }
    } catch {}
  }
  return false;
}

function findPidByCmd(pattern,binPath){return binPath===HERMES_BIN?serviceProcesses.find(pattern.includes('dashboard')?'dashboard':'gateway')?.pid||null:null;}
function findGatewayPid(){return serviceProcesses.find('gateway')?.pid||null;}

// Inspect occupied service ports without signalling another application's
// process. A collision is reported and startup stops before native takeover.
function foreignHermesPortConflicts(ports=[GATEWAY_PORT,DASHBOARD_PORT]) {
  return inspectServicePortConflicts({ports,hermesBin:HERMES_BIN,venvBin:VENV_BIN});
}

async function waitForExit(pid, timeoutMs = 5000) {
  const deadline = Date.now() + timeoutMs;
  while (pidAlive(pid) && Date.now() < deadline) {
    await new Promise(r => setTimeout(r, 100));
  }
}

async function stopPid(pidPath) {
  const kind=pidPath===PID_GATEWAY?'gateway':'dashboard';
  const result=await serviceProcesses.stop(kind);
  if(!result.ok)throw Object.assign(Error(result.error),{status:503});
  spawnTimes.delete(pidPath);
  return result;
}

function getProcessRssKB(pid) {
  try {
    const status = readFileSync(`/proc/${pid}/status`, "utf8");
    const m = status.match(/^VmRSS:\s+(\d+)\s+kB/m);
    return m ? Number(m[1]) : 0;
  } catch { return 0; }
}

function getHermesTotalMemoryKB() {
  let total = getProcessRssKB(process.pid);
  try {
    const dirs = readdirSync("/proc").filter(d => /^\d+$/.test(d));
    for (const dir of dirs) {
      const pid = Number(dir);
      if (!pid || pid === process.pid) continue;
      try {
        const cmdline = readFileSync(`/proc/${pid}/cmdline`, "utf8").replace(/\0/g, " ").trim();
        if (cmdline.includes(HERMES_BIN)) total += getProcessRssKB(pid);
      } catch {}
    }
  } catch {}
  return total;
}

let prevState = { gwRun: false, gwHealth: false, dbRun: false, dbHealth: false };
const spawnTimes = new Map();
const GRACE_PERIOD_MS = 20000;

let gatewayCrashCount = 0;
let gatewayCrashLoop  = false;
// 2026-11-04：gateway 自愈相关
let gwManualStop     = false;   // 用户主动 stop 时不自动拉起
let gwRespawnTimer    = null;   // 防重复排程
const CRASH_WINDOW_MS  = 60000;
const CRASH_LOOP_MAX   = 3;

// 将 .env 风格文件中的 KEY=value 行并入 env 对象（忽略注释/空行，支持引号包裹）。
function mergeEnvFile(env, path) {
  if (!existsSync(path)) return;
  const {values}=parseEnv(readFileSync(path,"utf8"));
  for(const [key,value] of Object.entries(values))if(value!==null)env[key]=value;
}

function spawnHermes(name, pidPath, args) {
  // Resolve an interrupted multi-file config save before a child can observe
  // only one side of the pending change. Never start from a disputed journal.
  try {
    configTransaction({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),state:join(VAR_DIR,'panel-state'),file:HERMES_CONFIG,body:{action:'recover'}});
  } catch (_) {
    log(`${name} 未启动：配置保存恢复未完成，请先核对待恢复记录`);
    return {ok:false,error:'配置保存恢复未完成，尚未启动服务；请在维护记录中核对'};
  }
  if (readPid(pidPath)) return { ok: true, msg: "already_running" };
  const existing=serviceProcesses.find(name);
  if(existing){writeFileSync(pidPath,String(existing.pid));return {ok:true,msg:'already_running',pid:existing.pid};}
  if (name === "gateway" || name === "dashboard") {
    const conflicts=foreignHermesPortConflicts([name==="gateway"?GATEWAY_PORT:DASHBOARD_PORT]);
    if(conflicts.length){log(`${name} 未启动：应用端口被其他进程占用`);return {ok:false,error:'应用端口被其他进程占用，请在本地维护中检查端口；未停止任何其他应用'};}
    args=args.filter(arg=>arg!=="--replace");
  }
  if (pidPath === PID_GATEWAY && gatewayCrashLoop) {
    log(`Gateway 启动被阻止 — 已检测到崩溃循环（需配置消息平台或先停止再启动）`);
    return { ok: false, error: "crash_loop" };
  }

  const logPath = `${VAR_DIR}/${name}.log`;
  try { writeFileSync(logPath, ""); } catch {}

  const env = {
    ...process.env,
    HOME: DATA_DIR,
    HERMES_HOME: DATA_DIR,
    PATH: resolvedNodeDir
      ? `${resolvedNodeDir}:${VENV_BIN}:/usr/local/bin:/usr/bin:/bin`
      : `${VENV_BIN}:/usr/local/bin:/usr/bin:/bin`,
    ...(resolvedNodeBin ? { HERMES_NODE: resolvedNodeBin } : {}),
    HERMES_TUI_DIR: TUI_DIR,
    HERMES_PANEL_DRAIN_LEASE: join(VAR_DIR,'panel-state/gateway-drain.json'),
    GATEWAY_ALLOW_ALL_USERS: "true",
    API_SERVER_ENABLED: "true",
    API_SERVER_PORT:   String(GATEWAY_PORT),
    API_SERVER_HOST:    "0.0.0.0",
    API_SERVER_KEY:     MONITOR_TOKEN,
    HERMES_YOLO_MODE:   "1",
    LITELLM_REQUEST_TIMEOUT: "600",
    REQUEST_TIMEOUT:    "600",
  };
  if (name === "dashboard") {
    // 固定仪表盘会话令牌，使 monitor 代理转发时能通过鉴权（见 proxyDashboard）
    env.HERMES_DASHBOARD_SESSION_TOKEN = DASHBOARD_SESSION_TOKEN;
    // 预构建前端（hermes-src/hermes_cli/web_dist）随包分发，显式指定后 dashboard
    // 直接 serve 静态产物，避免源码模式下无 npm（0.20.0 只查 managed node tree）
    // 触发 _web_ui_build_needed → "Web UI frontend not built and npm is not available"
    if (existsSync(`${APP_DIR}/hermes-src/hermes_cli/web_dist/index.html`)) {
      env.HERMES_WEB_DIST = `${APP_DIR}/hermes-src/hermes_cli/web_dist`;
    }
  }

  // 关键修复（Issue #3）：网关进程继承 process.env，但控制面板把 API key 写在
  // ${VAR_DIR}/.env.providers，Hermes config.yaml 用 ${ENV_VAR} 引用。若只传 process.env，
  // 网关拿不到真实 key，会报 "No inference provider configured"。这里把 .env.providers
  // 与 Hermes 的 ${DATA_DIR}/.env 一并并入 spawn 环境，确保 SENSENOVA_API_KEY /
  // OPENAI_API_KEY / CUSTOM_*_API_KEY 等对网关可见。
  try {
    mergeEnvFile(env, `${VAR_DIR}/.env.providers`);
    mergeEnvFile(env, `${DATA_DIR}/.env`);
  } catch (_) {
    log(`${name} 未启动：凭证文件无法解析，请先修复原文件`);
    return {ok:false,error:'凭证文件无法解析，原文件已保留；请先修复后再启动'};
  }

  const logFd = openSync(logPath, "a");
  const p = spawn(HERMES_BIN, args, {
    env,
    stdio: ["ignore", logFd, logFd],
  });

  p.unref();
  writeFileSync(pidPath, String(p.pid));
  spawnTimes.set(pidPath, Date.now());
  log(`${name} 已启动 pid=${p.pid}`);

  const cmdPattern = name === "gateway" ? "hermes gateway run" : "hermes dashboard";
  setTimeout(() => {
    if (pidAlive(p.pid)) return;
    const real = findPidByCmd(cmdPattern, HERMES_BIN);
    if (real && real !== p.pid) {
      writeFileSync(pidPath, String(real));
      spawnTimes.set(pidPath, Date.now());
      log(`${name} 运行中 pid=${real}`);
    }
  }, 1500);

  return { ok: true, pid: p.pid };
}

// ─── Cloudflare Tunnel 管理（隧道/外网访问）────────────────────────────
function _loadTunnelState() {
  try {
    if (existsSync(TUNNEL_STATE_PATH)) return JSON.parse(readFileSync(TUNNEL_STATE_PATH, "utf8"));
  } catch {}
  return { mode: "quick", target: String(UI_PORT), url: "", name: "", started_at: 0, pid: 0 };
}
function _saveTunnelState(s) {
  try { writeFileSync(TUNNEL_STATE_PATH, JSON.stringify(s, null, 2), { mode: 0o600 }); } catch {}
}
function _cloudflaredVersion() {
  try {
    const r = spawnSync(TUNNEL_BIN, ["--version"], { encoding: "utf8", timeout: 8000 });
    if (r.status === 0 && r.stdout) return String(r.stdout).trim().split("\n")[0];
  } catch {}
  return "";
}
// 异步下载（不阻塞事件循环，下载期间 monitor 仍能服务其它请求）
function _downloadCloudflaredAsync(url, dest) {
  return new Promise((resolve) => {
    const p = spawn("curl", ["-fsSL", "--retry", "3", "-o", dest, url]);
    let err = "";
    p.stderr.on("data", d => err += d);
    p.on("close", (code) => resolve(code === 0 ? null : (err.trim() || `curl exit ${code}`)));
    p.on("error", (e) => resolve(e.message));
  });
}
// 确保 cloudflared 二进制存在（缺失时从候选源列表下载 linux-amd64 到持久目录）
async function _ensureCloudflared() {
  const ver = _cloudflaredVersion();
  if (ver) return { ok: true, version: ver };
  try { mkdirSync(TUNNEL_BIN_DIR, { recursive: true }); } catch {}
  const tmp = `${TUNNEL_BIN_DIR}/cloudflared.dl`;
  try { unlinkSync(tmp); } catch {}
  log(`[tunnel] 下载 cloudflared ${TUNNEL_CF_VERSION}（约 50MB，首次需数秒）...`);
  let lastErr = "";
  for (const src of TUNNEL_DL_SOURCES) {
    try { unlinkSync(tmp); } catch {}
    log(`[tunnel] 尝试下载源: ${src}`);
    lastErr = await _downloadCloudflaredAsync(src, tmp);
    if (!lastErr && existsSync(tmp)) break;
  }
  if (lastErr || !existsSync(tmp)) {
    return { ok: false, error: `cloudflared 下载失败: ${String(lastErr || "网络错误").slice(0, 300)}` };
  }
  try { chmodSync(tmp, 0o755); renameSync(tmp, TUNNEL_BIN); } catch (e) { return { ok: false, error: `写入失败: ${e.message}` }; }
  log("[tunnel] cloudflared 下载完成");
  return { ok: true, version: _cloudflaredVersion() || TUNNEL_CF_VERSION };
}
function _tunnelRunning() {
  return !!(_tunnelProc && _tunnelProc.pid && pidAlive(_tunnelProc.pid));
}
// 轮转隧道日志（保证 URL 提取只匹配本次启动）
function _rotateTunnelLog() {
  try {
    if (existsSync(TUNNEL_LOG_PATH)) {
      renameSync(TUNNEL_LOG_PATH, `${TUNNEL_LOG_PATH}.1`);
    }
  } catch (e) { log(`[tunnel] 日志轮转失败: ${e.message}`); }
  try { mkdirSync(`${VAR_DIR}/logs`, { recursive: true }); } catch {}
}
function _extractTunnelUrl() {
  try {
    if (!existsSync(TUNNEL_LOG_PATH)) return "";
    // 取最后一个 trycloudflare URL（日志可能因轮转失败残留历史多次启动的地址，第一个是旧地址）
    const all = [...readFileSync(TUNNEL_LOG_PATH, "utf8").matchAll(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/g)];
    return all.length ? all[all.length - 1][0] : "";
  } catch { return ""; }
}
function _tailTunnelLog(maxLines = 80) {
  try {
    if (!existsSync(TUNNEL_LOG_PATH)) return "";
    const lines = readFileSync(TUNNEL_LOG_PATH, "utf8").split("\n").filter(Boolean);
    return lines.slice(-maxLines).join("\n");
  } catch { return ""; }
}
function _spawnTunnelProc(args) {
  _rotateTunnelLog();
  const logFd = openSync(TUNNEL_LOG_PATH, "a");
  const proc = spawn(TUNNEL_BIN, args, { stdio: ["ignore", logFd, logFd] });
  _tunnelProc = proc;
  proc.on("exit", (code) => {
    if (_tunnelProc === proc) _tunnelProc = null;
    const st = _loadTunnelState();
    if (st.pid === proc.pid) { st.url = ""; st.started_at = 0; st.pid = 0; _saveTunnelState(st); }
    log(`[tunnel] cloudflared 进程退出 code=${code}`);
  });
  return proc;
}
async function _stopTunnel() {
  const proc = _tunnelProc;
  _tunnelProc = null;
  let targetProc = (proc && proc.pid && pidAlive(proc.pid)) ? proc : null;
  if (!targetProc) {
    const st = _loadTunnelState();
    if (st.pid && pidAlive(st.pid)) targetProc = { pid: st.pid };
  }
  if (targetProc) {
    try { process.kill(targetProc.pid, "SIGTERM"); } catch {}
    await new Promise(r => setTimeout(r, 1500));
    if (pidAlive(targetProc.pid)) {
      try { process.kill(targetProc.pid, "SIGKILL"); } catch {}
      await new Promise(r => setTimeout(r, 200));
    }
  }
  const st = _loadTunnelState();
  st.url = ""; st.started_at = 0; st.pid = 0;
  _saveTunnelState(st);
  log("[tunnel] 隧道已停止");
}
async function _startQuickTunnel(target) {
  if (!/^\d+$/.test(String(target))) return { ok: false, error: "目标端口无效" };
  if (!isPortListening(target)) return { ok: false, error: `本机端口 ${target} 未在监听，请先启动服务再开启隧道` };
  const proc = _spawnTunnelProc(["tunnel", "--no-autoupdate", "--protocol", "http2", "--url", `http://127.0.0.1:${target}`]);
  let resolved = false;
  return await new Promise((resolve) => {
    const poll = () => {
      if (resolved) return;
      if (proc.exitCode !== null) {
        resolved = true;
        resolve({ ok: false, error: `cloudflared 提前退出 code=${proc.exitCode}，详见隧道日志` });
        return;
      }
      const url = _extractTunnelUrl();
      if (url) {
        resolved = true;
        const st = _loadTunnelState();
        st.mode = "quick"; st.target = String(target); st.url = url; st.started_at = Date.now(); st.pid = proc.pid; st.name = "";
        _saveTunnelState(st);
        log(`[tunnel] Quick 隧道已就绪: ${url}`);
        resolve({ ok: true, url, pid: proc.pid });
        return;
      }
      setTimeout(poll, 500);
    };
    poll();
    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        if (!_tunnelRunning()) _stopTunnel();
        resolve({ ok: false, error: "等待 trycloudflare.com 公网地址超时（30s），请检查 NAS 外网连通性后重试" });
      }
    }, 30000);
  });
}
async function _startNamedTunnel(target, token) {
  const t = String(token || "").trim();
  if (!t) return { ok: false, error: "Named 模式需要 Cloudflare Tunnel Token" };
  if (!/^\d+$/.test(String(target)) || !isPortListening(target)) return { ok: false, error: `本机端口 ${target} 未在监听，请先启动服务再开启隧道` };
  const proc = _spawnTunnelProc(["tunnel", "--no-autoupdate", "--protocol", "http2", "run", "--token", t]);
  await new Promise(r => setTimeout(r, 4000));
  if (proc.exitCode !== null) return { ok: false, error: `cloudflared 提前退出 code=${proc.exitCode}（Token 可能无效或未授权），详见隧道日志` };
  const st = _loadTunnelState();
  st.mode = "named"; st.target = String(target); st.url = ""; st.started_at = Date.now(); st.pid = proc.pid; st.name = "";
  _saveTunnelState(st);
  log("[tunnel] Named 隧道已启动");
  return { ok: true, pid: proc.pid };
}


function recordGatewayDeath() {
  const spawnTime = spawnTimes.get(PID_GATEWAY) || 0;
  const lifetime  = Date.now() - spawnTime;
  if (lifetime < CRASH_WINDOW_MS) {
    gatewayCrashCount++;
    if (gatewayCrashCount >= CRASH_LOOP_MAX && !gatewayCrashLoop) {
      gatewayCrashLoop = true;
      log(`Gateway crash loop detected (${gatewayCrashCount} rapid deaths) — blocking respawn`);
      log(`Gateway requires messaging platform config or manual restart after stop`);
    }
  } else {
    gatewayCrashCount = 0;
  }
}

function resetGatewayCrashLoop() {
  gatewayCrashCount = 0;
  gatewayCrashLoop  = false;
}
async function getStatus() {
  let [gp, dp] = [readPid(PID_GATEWAY), readPid(PID_DASHBOARD)];

  // 验证 PID 文件中的进程是否还活着（Dashboard 内部重启时 PID 文件可能残留旧值）
  if (gp && !pidAlive(gp)) {
    try { unlinkSync(PID_GATEWAY); } catch {}
    gp = null;
  }
  if (dp && !pidAlive(dp)) {
    try { unlinkSync(PID_DASHBOARD); } catch {}
    dp = null;
  }

  if (!gp) {
    const found = findGatewayPid();
    if (found) {
      writeFileSync(PID_GATEWAY, String(found), "utf8");
      log(`Gateway 运行中 pid=${found}`);
      gp = found;

    }
  }
  if (!dp) {
    const foundDb = findPidByCmd("hermes dashboard", HERMES_BIN);
    if (foundDb) {
      writeFileSync(PID_DASHBOARD, String(foundDb), "utf8");
      log(`Dashboard 运行中 pid=${foundDb}`);
      dp = foundDb;
    }
  }
  const health=await serviceHealth.refresh();
  const gwRunning=!!gp,dbRunning=!!dp,gwHealthy=health.gateway.healthy,dbHealthy=health.dashboard.healthy;

  if (prevState.gwRun && !gwRunning) {
    log("Gateway stopped");
    recordGatewayDeath();
    // 2026-11-04 修：此前这里只记日志不拉起 —— gateway 被杀后必须人工点「启动」才恢复
    // （实测 16:05:26 被 SIGKILL，直到 16:05:52 用户手动点启动才起来，中间 26 秒全是死的）。
    // 现在自动重拉一次，crash loop 与用户主动 stop 两种情况下不拉。
    if (!gatewayCrashLoop && !gwManualStop && !gwRespawnTimer) {
      gwRespawnTimer = setTimeout(function () {
        gwRespawnTimer = null;
        try {
          if (readPid(PID_GATEWAY)) { log("Gateway 自动拉起跳过：已有 pid 文件"); return; }
          log("Gateway 自动拉起（检测到异常退出，非人工停止）");
          spawnHermes("gateway", PID_GATEWAY, ["gateway", "run", "--replace"]);
        } catch (e) {
          log("Gateway 自动拉起失败: " + ((e && e.message) || e));
        }
      }, 3000);
    }
  }
  if (!prevState.gwRun && gwRunning) log("Gateway started (pid=" + gp + ")");
  if (gwRunning && prevState.gwHealth && !gwHealthy) log("Gateway port unresponsive (pid=" + gp + ")");
  if (gwRunning && !prevState.gwHealth && gwHealthy) log("Gateway is healthy (pid=" + gp + ")");

  if (prevState.dbRun && !dbRunning) log("Dashboard stopped (pid gone)");
  if (!prevState.dbRun && dbRunning) log("Dashboard started (pid=" + dp + ")");
  if (dbRunning && prevState.dbHealth && !dbHealthy) log("Dashboard port unresponsive (pid=" + dp + ")");
  if (dbRunning && !prevState.dbHealth && dbHealthy) log("Dashboard is healthy (pid=" + dp + ")");

  prevState = { gwRun: gwRunning, gwHealth: gwHealthy, dbRun: dbRunning, dbHealth: dbHealthy };

  let lastLog = "";
  try {
    // 只读日志尾部（最多 64KB），避免 /api/status 每 3 秒轮询时全量读取持续增长的 hermes.log 阻塞事件循环
    const size = statSync(LOG_FILE).size;
    const fd = openSync(LOG_FILE, "r");
    try {
      const readLen = Math.min(size, 65536);
      const buf = Buffer.alloc(readLen);
      readSync(fd, buf, 0, readLen, size - readLen);
      lastLog = buf.toString("utf8").split("\n").filter(l => l.trim()).slice(-20).join("\n");
    } finally { closeSync(fd); }
  } catch {}

  return {
    gateway:   { running: gwRunning, healthy: gwHealthy, pid: gp, port: GATEWAY_PORT, crash_loop: gatewayCrashLoop, work_known:health.gateway.work_known, busy:health.gateway.busy, active:health.gateway.active, version: HERMES_VERSION },
    dashboard: { running: dbRunning, healthy: dbHealthy, pid: dp, port: DASHBOARD_PORT },
    lastLog,
  };
}

// Dashboard 自愈冷却：避免并发请求在 Dashboard 挂死时反复杀进程+重启（10 秒内最多自愈一次）
let lastDashboardHealTs = 0;

async function proxyDashboard(req) {
  const url     = new URL(req.url);
  // req.url 仍含 BASE_PATH 前缀（handleFetch 只剥了 path 变量），需先去掉
  const subPath = url.pathname
    .replace(new RegExp(`^${BASE_PATH.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&")}`), "")
    .replace(/^\/proxy\/dashboard/, "") || "/";
  const target  = `http://${DASHBOARD_BIND}:${DASHBOARD_PORT}${subPath}${url.search}`;

  // 前缀动态适配实际访问 URL：门户访问（/app/hermes-agent/proxy/dashboard/...）与
  // 直接访问（/proxy/dashboard/...）注入不同前缀，否则 __HERMES_BASE_PATH__/资源路径
  // 与实际 URL 不匹配导致前端 API/WS 404、页面黑屏。
  const _dashPrefixBase = (url.pathname.split("/proxy/dashboard")[0] || "").replace(/\/+$/, "");
  const prefix = (_dashPrefixBase || (BASE_PATH || "").replace(/\/+$/, "")) + "/proxy/dashboard";

  const frozenResponse = await handleMaintenance(req, subPath);
  if (frozenResponse) return frozenResponse;
  const restartResponse=await handleRestartIngress(req,'/proxy/dashboard'+subPath);
  if(restartResponse)return restartResponse;

  // 通讯页渠道描述汉化：后端返回的渠道描述为英文，这里拦截翻译（数据层汉化）。
  // 注意：此处位于 try 块外，init 变量不可用，需自行构造请求。
  if (req.method === "GET" && subPath === "/api/messaging/platforms") {
    try {
      const _up = await fetch(target, {
        method: "GET",
        headers: { "X-Hermes-Session-Token": DASHBOARD_SESSION_TOKEN },
        signal: AbortSignal.timeout(10000),
      });
      if (_up.ok) {
        const _j = await _up.json().catch(() => null);
        if (_j && Array.isArray(_j.platforms)) {
          const DESC = {
            "Run Hermes from Telegram DMs, groups, and topics.": "通过 Telegram 私聊、群组和话题使用 Hermes。",
            "Connect Hermes to Discord DMs, channels, and threads.": "将 Hermes 连接到 Discord 私聊、频道和帖子。",
            "Use Hermes from Slack via Socket Mode. Add allowed Slack member IDs so connected bots can respond.": "通过 Socket Mode 从 Slack 使用 Hermes。添加允许的 Slack 成员 ID，连接的机器人即可响应。",
            "Connect Hermes to Mattermost channels and direct messages.": "将 Hermes 连接到 Mattermost 频道和私信。",
            "Use Hermes in Matrix rooms and direct messages.": "在 Matrix 房间和私信中使用 Hermes。",
            "Use Hermes through the bundled WhatsApp bridge with QR-based auth.": "通过内置 WhatsApp 桥（二维码认证）使用 Hermes。",
            "Connect through a signal-cli REST bridge.": "通过 signal-cli REST 桥连接。",
            "Use Hermes through iMessage via a BlueBubbles server.": "通过 BlueBubbles 服务器经 iMessage 使用 Hermes。",
            "Control your smart home from Hermes via Home Assistant.": "通过 Home Assistant 从 Hermes 控制智能家居。",
            "Talk to Hermes through an IMAP/SMTP mailbox.": "通过 IMAP/SMTP 邮箱与 Hermes 对话。",
            "Send and receive text messages via Twilio.": "通过 Twilio 收发短信。",
            "Connect Hermes to DingTalk groups (钉钉).": "将 Hermes 连接到钉钉群组。",
            "Use Hermes inside Feishu / Lark.": "在飞书 / Lark 中使用 Hermes。",
            "Connect Hermes to Google Chat via Cloud Pub/Sub.": "通过 Cloud Pub/Sub 将 Hermes 连接到 Google Chat。",
            "Send-only WeCom group bot via webhook.": "通过 Webhook 发送企业微信群机器人消息（仅发送）。",
            "Two-way WeCom integration via callback app.": "通过回调应用进行双向企业微信集成。",
            "Connect a personal WeChat account through Tencent's iLink Bot API.": "通过腾讯 iLink Bot API 连接个人微信账号。",
            "Connect Hermes to a QQ Bot from the QQ Open Platform.": "从 QQ 开放平台将 Hermes 连接到 QQ 机器人。",
            "Connect Hermes to Tencent Yuanbao.": "将 Hermes 连接到腾讯元宝。",
            "Expose Hermes as an OpenAI-compatible HTTP API for tools like Open WebUI.": "将 Hermes 作为兼容 OpenAI 的 HTTP API 暴露，供 Open WebUI 等工具使用。",
            "Receive events from GitHub, GitLab, and other webhook sources.": "接收来自 GitHub、GitLab 等 Webhook 源的事件。",
            "No extra packages needed (stdlib only)": "无需额外包（仅标准库）",
            "Requires the buzz CLI binary (https://github.com/block/buzz) on PATH or at BUZZ_CLI_PATH": "需要 buzz CLI 二进制文件（https://github.com/block/buzz）位于 PATH 或 BUZZ_CLI_PATH",
            "Use Hermes through iMessage via Photon's managed Spectrum platform.": "通过 Photon 托管的 Spectrum 平台经 iMessage 使用 Hermes。",
            "Relay messages between an IRC channel (or DMs) and Hermes.": "在 IRC 频道（或私信）与 Hermes 之间中继消息。",
            "Use Hermes from LINE via the LINE Messaging API webhook.": "通过 LINE Messaging API Webhook 从 LINE 使用 Hermes。",
            "Receive Microsoft Graph change notifications (Teams meetings, Outlook, …).": "接收 Microsoft Graph 变更通知（Teams 会议、Outlook 等）。",
            "Connect Hermes to Microsoft Teams chats via the Bot Framework.": "通过 Bot Framework 将 Hermes 连接到 Microsoft Teams 聊天。",
            "Chat with Hermes over ntfy push topics (ntfy.sh or self-hosted).": "通过 ntfy 推送主题（ntfy.sh 或自托管）与 Hermes 聊天。",
            "Join a Raft workspace as an external agent.": "作为外部智能体加入 Raft 工作区。",
            "Generic relay adapter fronted by the Hermes Relay connector.": "由 Hermes Relay 连接器提供前置的通用中继适配器。",
            "Talk to Hermes over SimpleX Chat via a local simplex-chat daemon.": "通过本地 simplex-chat 守护进程在 SimpleX Chat 上与 Hermes 对话。",
            "Use Hermes via Meta's hosted WhatsApp Cloud API (no local bridge).": "通过 Meta 托管的 WhatsApp Cloud API 使用 Hermes（无需本地桥）。"
          };
          let changed = false;
          _j.platforms.forEach(p => {
            if (p && p.description && DESC[p.description]) { p.description = DESC[p.description]; changed = true; }
          });
          if (changed) {
            return new Response(JSON.stringify(_j), { headers: { "Content-Type": "application/json; charset=utf-8" } });
          }
        }
      }
      return _up;
    } catch (e) {
      // fallthrough to normal proxy on error
    }
  }

  try {
    const headers = new Headers(req.headers);
    headers.delete("host");
    // 注入仪表盘会话令牌（与 HERMES_DASHBOARD_SESSION_TOKEN 同源），
    // 转发到仪表盘的所有 /api/* 请求均带此令牌，免去 401 鉴权。
    headers.set("X-Hermes-Session-Token", DASHBOARD_SESSION_TOKEN);
    // Node 的全局 fetch 在转发流 body（ReadableStream）时必须显式传 duplex:'half'，
    // 否则报 "RequestInit: duplex option is required when sending a body"。
    // 语音端点超时放宽：/api/audio/transcribe 含 STT 推理（本地 Whisper 或远程 round-trip）、
    // /api/audio/speak 含整段 TTS 合成，10s 默认超时必然误杀；统一放宽到 3 分钟，其余保持 10s 快速失败。
    const _audioPath = subPath.startsWith("/api/audio/");
    const init = {
      method: req.method,
      headers,
      signal: AbortSignal.timeout(_audioPath ? 180000 : 10000),
    };
    if (req.method !== "GET" && req.method !== "HEAD" && req.body) {
      init.body = req.body;
      init.duplex = "half";
    }
    const upstream = await fetch(target, init);

    const respHeaders = new Headers(upstream.headers);

    // ── 3xx 重定向：改写 Location 头 ──
    if (upstream.status >= 300 && upstream.status < 400) {
      const loc = respHeaders.get("location");
      if (loc) {
        try {
          const abs = new URL(loc, target);
          respHeaders.set("location", prefix + abs.pathname + abs.search);
        } catch {}
      }
      return new Response(upstream.body, { status: upstream.status, headers: respHeaders });
    }

    const contentType = respHeaders.get("content-type") || "";

    // ── CSS 响应：改写 url(/...) 加前缀，让字体等 url() 引用能正确路由 ──
    if (contentType.includes("text/css") || subPath.endsWith(".css")) {
      let css = await upstream.text();
      css = css.replace(/url\((\/[^)'"]+)\)/g, `url(${prefix}$1)`);
      respHeaders.delete("content-length");
      return new Response(css, { status: upstream.status, headers: respHeaders });
    }

    // ── HTML 响应：注入 <base> + 路径改写脚本 ──
    if (contentType.includes("text/html")) {
      let html = await upstream.text();
      // Native config editor assets have versioned import-map entries. Keep
      // those module URLs inside this authenticated proxy as well.
      html = html.replace(/(<script type="importmap">)([\s\S]*?)(<\/script>)/g, (all, open, text, close) => {
        const map = JSON.parse(text);
        if (map.imports) map.imports = Object.fromEntries(Object.entries(map.imports).map(([key, value]) => [key.startsWith('/assets/') ? prefix + key : key, typeof value === 'string' && value.startsWith('/assets/') ? prefix + value : value]));
        return open + JSON.stringify(map) + close;
      });

      // <base> 处理相对路径（CSS url()、相对 src 等）
      html = html.replace(/<head(\s[^>]*)?>/, `<head$1><base href="${prefix}/">`);

      // 静态重写 src 属性中的绝对路径（脚本、图片等）
      html = html.replace(/\bsrc="\/(?!\/)/g, `src="${prefix}/`);
      // 静态重写 <link href>（CSS 样式表），不改写 <a href>（SPA 路由需要原始路径）
      html = html.replace(/<link(\s[^>]*)href="\/(?!\/)/g, (m, a) => `<link${a}href="${prefix}/`);

      // 注入 JS：智能前缀管理（pushState剥离+导航感知恢复+popstate拦截）
      const inject = `<script>
(function(){
  var P="${prefix}";
  function rw(u){
    if(typeof u!=="string")return u;
    if(u.indexOf("//")===0||/^[a-z]+:/i.test(u))return u;
    if(u.charAt(0)==="/"){if(u.indexOf(P)===0)return u;return P+u;}
    return u;
  }
  function strip(u){
    if(typeof u!=="string")return u;
    if(u.indexOf(P)===0)return u.substring(P.length)||"/";
    return u;
  }
  /* ── 注意：不再劫持 history.pushState/replaceState/popstate ──
     官方 dashboard 用 <BrowserRouter basename={__HERMES_BASE_PATH__}>，导航由
     react-router 原生处理（自动拼 basename）。此前的「剥离前缀给路由+微任务恢复」
     劫持会让 Router 在 pushState 瞬间看到无前缀 URL → basename 不匹配 → 黑屏。 */
  /* ── fetch / XHR：添加前缀 ── */
  var _f=window.fetch;
  window.fetch=function(i,o){
    if(typeof i==="string")i=rw(i);
    else if(i&&i.url)return _f(new Request(rw(i.url),i),o);
    return _f.call(this,i,o);
  };
  var _xo=XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open=function(){
    if(arguments.length>1)arguments[1]=rw(arguments[1]);
    return _xo.apply(this,arguments);
  };
  /* ── MutationObserver：只改写 src ── */
  function rwEl(el){
    if(el.hasAttribute("src")){var s=el.getAttribute("src");if(s&&s.charAt(0)==="/"&&s.indexOf(P)!==0)el.setAttribute("src",P+s);}
  }
  new MutationObserver(function(ms){ms.forEach(function(m){if(m.type==="childList")m.addedNodes.forEach(function(n){if(n.nodeType===1){rwEl(n);n.querySelectorAll&&n.querySelectorAll("[src]").forEach(rwEl);}});});}).observe(document.documentElement,{childList:true,subtree:true});
  document.querySelectorAll("[src]").forEach(rwEl);
  /* ── hook HTMLScriptElement.src setter：createElement("script") 后 v.src=...
     走的不是 fetch/XHR，需要在这里加前缀 ── */
  var _sp=HTMLScriptElement.prototype,_sd=Object.getOwnPropertyDescriptor(_sp,"src");
  if(_sd&&_sd.set){var _ss=_sd.set,_sg=_sd.get;Object.defineProperty(_sp,"src",{get:function(){return _sg?_sg.call(this):undefined;},set:function(v){if(typeof v==="string"&&v.charAt(0)==="/"&&v.indexOf(P)!==0)v=P+v;_ss.call(this,v);},configurable:true,enumerable:_sd.enumerable});}
  /* ── hook HTMLLinkElement.href setter：createElement("link") 后 x.href=...
     走的不是 fetch/XHR，需要在这里加前缀 ── */
  var _lp=HTMLLinkElement.prototype,_ld=Object.getOwnPropertyDescriptor(_lp,"href");
  if(_ld&&_ld.set){var _ls=_ld.set,_lg=_ld.get;Object.defineProperty(_lp,"href",{get:function(){return _lg?_lg.call(this):undefined;},set:function(v){if(typeof v==="string"&&v.charAt(0)==="/"&&v.indexOf(P)!==0)v=P+v;_ls.call(this,v);},configurable:true,enumerable:_ld.enumerable});}
  /* ── hook WebSocket：给 dashboard WS URL 加前缀，路由到 monitor 反代 ── */
  var _WS=window.WebSocket;
  /* iOS 第三方输入法(如百度)在 xterm 终端无法输入的补偿所需：
     捕获 /api/pty 连接并包裹其 send 以记录 xterm 实际发出的输入 */
  var _activePty=null, _ptySent=[];
  function _hookPty(sock, pathname){
    try{
      if(!sock||!pathname||pathname.indexOf("/api/pty")===-1)return sock;
      _activePty=sock;
      var _os=sock.send;
      sock.send=function(d){
        try{
          var s=(typeof d==="string")?d:(d?new TextDecoder().decode(d):"");
          if(s){_ptySent.push({t:Date.now(),s:s});if(_ptySent.length>80)_ptySent.shift();}
        }catch(e){}
        return _os.apply(this,arguments);
      };
      sock.addEventListener("close",function(){if(_activePty===sock)_activePty=null;});
    }catch(e){}
    return sock;
  }
  window.WebSocket=function(url,protocols){
    try{
      if(typeof url==="string"){
        var u=new URL(url,location.origin);
        if(u.pathname.charAt(0)==="/"&&u.pathname.indexOf(P)!==0){
          var newUrl=(location.protocol==="https:"?"wss:":"ws:")+"//"+location.host+P+u.pathname+(u.search||"")+(u.hash||"");
          return _hookPty(new _WS(newUrl,protocols),u.pathname);
        }
        return _hookPty(new _WS(url,protocols),u.pathname);
      }
    }catch(e){}
    return new _WS(url,protocols);
  };
  window.WebSocket.prototype=_WS.prototype;
  /* 关键：保留构造器静态常量（CONNECTING/OPEN/CLOSING/CLOSED）。
     dashboard 前端发送输入前常用 ws.readyState===WebSocket.OPEN 做门禁；
     覆盖构造器若丢掉这些常量，OPEN 变 undefined → 门禁永不成立 → 输入帧发不出去
     （服务端推来的输出仍走 onmessage，故表现为“画面能显示、但无法输入/发送”）。 */
  window.WebSocket.CONNECTING=_WS.CONNECTING;
  window.WebSocket.OPEN=_WS.OPEN;
  window.WebSocket.CLOSING=_WS.CLOSING;
  window.WebSocket.CLOSED=_WS.CLOSED;
  /* ── iOS 第三方输入法(百度等)组合输入补偿 ──
     现象：iPhone 上用第三方 IME 在 Dashboard 终端(xterm)对话打不出字，自带键盘正常。
     根因：部分第三方 IME 的组合提交未触发 xterm 期望的事件序列，组合文字从不经
     /api/pty 发出。这里在组合结束/插入后核对：若该文字未被 xterm 经 pty socket 发出，
     则由我们补发到 /api/pty（服务端 pty_ws 同时接受 text/bytes 帧，text 按 UTF-8 编码）。
     去重：仅当“事件发生之后”pty 未发出该文字才补发；xterm 正常处理会在事件后立即发出，
     且我们自己的补发也会被记录，天然避免重复；不同次提交按时间戳区分，允许连续重复字。 */
  function _isTermTarget(t){
    try{return !!(t&&((t.classList&&t.classList.contains("xterm-helper-textarea"))||(t.closest&&t.closest(".xterm"))));}
    catch(e){return false;}
  }
  function _ptyReconcileSend(text,mark){
    if(!text||!_activePty||_activePty.readyState!==1)return;
    setTimeout(function(){
      try{
        if(!_activePty||_activePty.readyState!==1)return;
        var after="";
        for(var i=0;i<_ptySent.length;i++){if(_ptySent[i].t>=mark-5)after+=_ptySent[i].s;}
        if(after.indexOf(text)!==-1)return;   /* xterm 已发出，勿重复 */
        _activePty.send(text);
      }catch(e){}
    },80);
  }
  document.addEventListener("compositionend",function(ev){
    try{if(ev&&ev.data&&_isTermTarget(ev.target))_ptyReconcileSend(String(ev.data),Date.now());}catch(e){}
  },true);
  document.addEventListener("input",function(ev){
    try{
      if(!ev||ev.isComposing||!ev.data||!_isTermTarget(ev.target))return;
      if(ev.inputType&&ev.inputType!=="insertText"&&ev.inputType!=="insertCompositionText")return;
      _ptyReconcileSend(String(ev.data),Date.now());
    }catch(e){}
  },true);
})();
<\/script>`;

      // ── 中文语言运行时汉化（仅 zh/zh-hant 生效，不影响其他语言切换）──
      const injectZh = `<script>
(function(){
  try{
    var DICT={
      'Files':'文件','Channels':'通讯','Webhooks':'回调参数','Pairing':'配对','System':'系统',
      'KANBAN':'看板','Kanban':'看板','achievements':'成就','Achievements':'成就',
      'Model Context Length':'模型上下文长度','Fallback Providers':'备用提供商',
      'Max Concurrent Sessions':'最大并发会话','Max Live Sessions':'最大活跃会话',
      'Context File Max Chars':'上下文文件最大字符数','File Read Max Chars':'文件读取最大字符数',
      'Save':'保存','Cancel':'取消','Add':'添加','Delete':'删除','Edit':'编辑','Apply':'应用',
      'Reset':'重置','Test':'测试','Enabled':'已启用','Disabled':'已禁用','Running':'运行中',
      'Stopped':'已停止','Active':'启用','Inactive':'停用','Connected':'已连接','Disconnected':'未连接',
      'Loading':'加载中','Search':'搜索','Settings':'设置','Language':'语言','Update':'更新',
      'Restart':'重启','Install':'安装','Uninstall':'卸载','Stop':'停止','Start':'启动',
      'General':'常规','Advanced':'高级','About':'关于',
      // ── 会话页 ──
      'Prune old sessions':'清理旧会话','Total':'总计','Active in store':'存储中活跃','Archived':'已归档',
      'Messages':'消息数','Sources':'来源','Overview':'概览','History':'历史','Import sessions':'导入会话',
      'Any chat source':'任意聊天来源','Chat':'聊天','Automation':'自动化','All':'全部','Connected Platforms':'已连接平台',
      // ── 模型页 ──
      'MODEL SETTINGS':'模型设置','MAIN MODEL':'主模型','AUXILIARY TASKS':'辅助任务','MIXTURE OF AGENTS':'多智能体混合',
      'CHANGE':'更改','CONFIGURE':'配置','USE AS':'设为','applies to new sessions':'适用于新会话',
      // ── 插件页 ──
      'SAVE MEMORY PROVIDER':'保存记忆提供方','SAVE CONTEXT ENGINE':'保存上下文引擎',
      'Memory Provider':'记忆提供方','Context Engine':'上下文引擎','Installed Plugins':'已安装插件',
      // ── MCP 页 ──
      'Your MCP servers':'你的 MCP 服务器','ADD SERVER':'添加服务器','Setup notes':'设置说明',
      'No MCP servers configured.':'未配置 MCP 服务器。','Catalog':'目录',
      // ── 回调页 ──
      'NEW SUBSCRIPTION':'新建订阅','ENABLE WEBHOOKS':'启用 Webhook','Subscriptions':'订阅',
      'No webhook subscriptions yet.':'暂无 Webhook 订阅。','Webhook receiver disabled':'Webhook 接收器已停用',
      // ── 配对页 ──
      'Pending requests':'待处理请求','Approved users':'已批准用户',
      'No pending pairing requests':'暂无待处理配对请求','No approved users':'暂无已批准用户',
      // ── 多AGENT ──
      'BUILD':'构建','Create':'创建','Active profile':'当前激活配置','Multi-Agent Configuration':'多智能体配置',
      // ── 系统页 ──
      'Host':'主机','Nous Portal':'Nous 门户','Skill curator':'技能策展','Gateway':'网关',
      'Check for updates':'检查更新','not configured':'未配置','not logged in':'未登录','Manage subscription':'管理订阅',
      // ── 看板 ──
      'Clear filters':'清除筛选','Orchestration':'编排','Orchestration settings':'编排设置',
      'New Kanban':'新建看板','Trigger Scheduler':'触发调度器','Refresh':'刷新','Show Archived':'显示已归档',
      'Group by Configuration':'按配置分组','Filter cards...':'筛选卡片...','All Tenants':'全部租户',
      'All Configurations':'全部配置','No tasks':'无任务','新建看板':'新建看板',
      // ── 技能/其他 ──
      'Learn a skill':'学习技能','New skill':'新建技能','Toolsets':'工具集','BROWSE HUB':'浏览中心',
      'Session':'会话','Sessions':'会话','Docs':'文档','Logs':'日志','Models':'模型','Plugins':'插件管理',
      'MCP':'MCP','Config':'配置','Keys':'密钥','active':'启用','inactive':'停用','running':'运行中',
      'enabled':'已启用','disabled':'已停用','Install':'安装','Enable':'启用','Disable':'停用',
      // ── MCP 弹窗 / 通讯页 ──
      'ADD MCP SERVER':'添加 MCP 服务器','NAME':'名称','TRANSPORT':'传输方式','URL':'地址',
      'AUTHENTICATION':'认证','None':'无','HTTP/SSE':'HTTP/SSE','my-server':'我的服务器',
      'QUICK SETUP':'快速设置','recommended':'推荐','CREATE WITH QR':'扫码创建','USE YOUR OWN BOT':'使用自己的机器人',
      'MANUAL SETUP':'手动设置','PAIR WITH QR':'扫码配对','MODE':'模式','Bot':'机器人','Self-chat':'私聊',
      'ALLOWED WHATSAPP NUMBERS':'允许的 WhatsApp 号码','Test':'测试','Last updated':'最后更新',
      // ── 模型/通用按钮 ──
      'CHANGE':'更改','CONFIGURE':'配置','USE AS':'设为','Sessions count':'会话数','Number of models used':'使用模型数',
      'Total sessions':'总会话数','Hide':'隐藏','Show':'显示','Custom':'自定义','solo':'独立',
      // ── 文件页 ──
      'GO':'前往','UPLOAD':'上传','DROP FILES HERE':'拖拽文件到此处','CHOOSE FILES':'选择文件',
      'NAME':'名称','SIZE':'大小','MODIFIED':'修改时间','ACTIONS':'操作','Create':'创建','Files':'文件'
    };
    var SKIP={INPUT:1,TEXTAREA:1,SCRIPT:1,STYLE:1,CODE:1,PRE:1};
    // 默认按中文处理（DICT 仅含英→中映射；用户是中文环境）。若用户显式切英文界面，
    // hermes-locale 存了 'en'，此时仍翻译（DICT 只翻英文文案，不影响其它语言内容）。
    function getLoc(){try{return localStorage.getItem('hermes-locale')||'zh';}catch(e){return 'zh';}}
    function translate(root){
      if(!root)return;
      var w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT,null,false),n;
      while((n=w.nextNode())){
        var t=n.nodeValue; if(!t)continue;
        var k=t.trim(); if(!k||!DICT[k]||k===DICT[k])continue;
        var p=n.parentNode; if(!p||p.nodeType!==1)continue;
        if(SKIP[p.tagName]||p.isContentEditable)continue;
        n.nodeValue=t.replace(k,DICT[k]);
      }
    }
    // 无条件翻译（DICT 仅含英→中，始终生效，不受语言切换/React 重渲染影响）；
    // 定时兜底：SPA 路由切换/React 重渲染会覆盖 DOM 文本，每 600ms 强制翻译一次
    function run(){ try{translate(document.body);}catch(e){} }
    var obs;
    function start(){
      if(obs)return;
      obs=new MutationObserver(function(){
        if(obs)obs.disconnect();
        try{run();}catch(e){}
        if(obs)obs.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
      });
      obs.observe(document.documentElement,{childList:true,subtree:true,characterData:true});
      setInterval(function(){ try{translate(document.body);}catch(e){} }, 600);
    }
    if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',function(){run();start();});}
    else{run();start();}
    window.addEventListener('storage',function(e){if(e.key==='hermes-locale')run();});
  }catch(e){}
})();
<\/script>`;

      // 官方 web_server 会按「剥前缀后的 URL」注入 window.__HERMES_BASE_PATH__（此时为空值），
      // 该 script 位于 monitor 注入之前，会在运行时覆盖代理前缀 → 前端 API/WS 拼出无前缀路径，
      // chat 页依赖的 gateway WS(/api/ws) 在门户下 404 → 黑屏。统一替换为正确代理前缀；
      // 官方未注入该变量时兜底追加。
      if (/window\.__HERMES_BASE_PATH__="[^"]*"/.test(html)) {
        html = html.replace(/window\.__HERMES_BASE_PATH__="[^"]*"/, `window.__HERMES_BASE_PATH__="${prefix}"`);
      } else {
        html = html.replace("</head>", `<script>window.__HERMES_BASE_PATH__="${prefix}";</script></head>`);
      }

      html = html.replace("</head>", inject + "\n" + injectZh + "\n</head>");

      // ── 独立自包含汉化脚本（body 末尾注入，不依赖 injectZh，无条件执行）──
      // injectZh 整体包在 try/catch 里，任何运行时错误都会静默吞掉导致翻译不生效；
      // 这里提供第二套独立翻译：叶节点精确匹配 DICT + setInterval 500ms 持续兜底，
      // 覆盖 React 重渲染与路由切换。
      const _zhStandalone = `<script>
(function(){
  var D={${Object.entries({
    "Prune old sessions":"清理旧会话","Total":"总计","Active in store":"存储中活跃","Archived":"已归档","Messages":"消息数","Sources":"来源","Overview":"概览","History":"历史","Import sessions":"导入会话","Any chat source":"任意聊天来源","Chat":"聊天","Automation":"自动化","All":"全部","Connected Platforms":"已连接平台",
    "MODEL SETTINGS":"模型设置","MAIN MODEL":"主模型","AUXILIARY TASKS":"辅助任务","MIXTURE OF AGENTS":"多智能体混合","CHANGE":"更改","CONFIGURE":"配置","USE AS":"设为","applies to new sessions":"适用于新会话",
    "GO":"前往","UPLOAD":"上传","DROP FILES HERE":"拖拽文件到此处","CHOOSE FILES":"选择文件","NAME":"名称","SIZE":"大小","MODIFIED":"修改时间","ACTIONS":"操作",
    "SAVE MEMORY PROVIDER":"保存记忆提供方","SAVE CONTEXT ENGINE":"保存上下文引擎","Memory Provider":"记忆提供方","Context Engine":"上下文引擎","Installed Plugins":"已安装插件",
    "Your MCP servers":"你的 MCP 服务器","ADD SERVER":"添加服务器","ADD MCP SERVER":"添加 MCP 服务器","Setup notes":"设置说明","No MCP servers configured.":"未配置 MCP 服务器。","Catalog":"目录","TRANSPORT":"传输方式","AUTHENTICATION":"认证","None":"无","HTTP/SSE":"HTTP/SSE","my-server":"我的服务器",
    "NEW SUBSCRIPTION":"新建订阅","ENABLE WEBHOOKS":"启用 Webhook","Subscriptions":"订阅","No webhook subscriptions yet.":"暂无 Webhook 订阅。","Webhook receiver disabled":"Webhook 接收器已停用",
    "Pending requests":"待处理请求","Approved users":"已批准用户","No pending pairing requests":"暂无待处理配对请求","No approved users":"暂无已批准用户",
    "BUILD":"构建","Create":"创建","Active profile":"当前激活配置","Multi-Agent Configuration":"多智能体配置",
    "Host":"主机","Nous Portal":"Nous 门户","Skill curator":"技能策展","Gateway":"网关","Check for updates":"检查更新","not configured":"未配置","not logged in":"未登录","Manage subscription":"管理订阅",
    "Clear filters":"清除筛选","Orchestration":"编排","Orchestration settings":"编排设置","New Kanban":"新建看板","Trigger Scheduler":"触发调度器","Refresh":"刷新","Show Archived":"显示已归档","Group by Configuration":"按配置分组","Filter cards...":"筛选卡片...","All Tenants":"全部租户","All Configurations":"全部配置","No tasks":"无任务",
    "Learn a skill":"学习技能","New skill":"新建技能","Toolsets":"工具集","BROWSE HUB":"浏览中心","Session":"会话","Sessions":"会话","Docs":"文档","Logs":"日志","Models":"模型","Plugins":"插件管理","MCP":"MCP","Config":"配置","Keys":"密钥","active":"启用","inactive":"停用","running":"运行中","enabled":"已启用","disabled":"已停用","Install":"安装","Enable":"启用","Disable":"停用",
    "QUICK SETUP":"快速设置","recommended":"推荐","CREATE WITH QR":"扫码创建","USE YOUR OWN BOT":"使用自己的机器人","MANUAL SETUP":"手动设置","PAIR WITH QR":"扫码配对","MODE":"模式","Bot":"机器人","Self-chat":"私聊","ALLOWED WHATSAPP NUMBERS":"允许的 WhatsApp 号码","Test":"测试","Last updated":"最后更新",
    "SKILLS (OPTIONAL)":"技能（可选）","ADVANCED FIELDS":"高级字段","PROVIDER":"提供方","MODEL":"模型","BASE URL OVERRIDE":"基础地址覆盖","SCRIPT":"脚本","WORKDIR":"工作目录","CONTEXT_FROM_JOB_IDS":"上下文任务ID","ENABLED_TOOLSETS":"启用工具集","Deliver To":"投递至","Local":"本地","Default":"默认","one job id per line":"每行一个任务ID",
    "Categories":"分类","Toolset":"工具集","Enabled":"已启用","Installed":"已安装","Source":"来源","Auth":"认证","Status":"状态","Action":"操作","Language":"语言","Theme":"主题","Custom":"自定义","Hide":"隐藏","Show":"显示","Yes":"是","No":"否","Next":"下一步","Back":"返回","Submit":"提交","Close":"关闭","Confirm":"确认","Error":"错误","Success":"成功","Warning":"警告","Information":"信息","Delete":"删除","Edit":"编辑","Add":"添加","Save":"保存","Cancel":"取消","Apply":"应用","Reset":"重置","Search":"搜索","Loading":"加载中","General":"常规","Advanced":"高级","About":"关于","Settings":"设置","Update":"更新","Restart":"重启","Stop":"停止","Start":"启动",
    "Mcp Discovery Timeout":"MCP 发现超时","Mcp Single Query Discovery Timeout":"MCP 单次查询发现超时","Prefill Messages File":"预填充消息文件","Command Allowlist":"命令白名单","Hooks Auto Accept":"钩子自动接受","Live Probe Timeout":"实时探测超时","Curator":"策展","Database":"数据库","Desktop":"桌面","Monitoring":"监控","Proxy":"代理","Secrets":"密钥","Streaming":"流式","Wake_word":"唤醒词","Tools":"工具","Tool_output":"工具输出","Tool_loop_guardrails":"工具循环护栏","Session":"会话","Gateway":"网关","Model_catalog":"模型目录","X_search":"X 搜索","Moa":"多智能体混合","Lsp":"LSP","Assistant":"助手","Memory":"记忆","Security":"安全","Voice":"语音","Text to Speech":"文字转语音","Speech to Text":"语音转文字","Delegation":"委托","Compression":"压缩","Browser":"浏览器","Bedrock":"Bedrock","Vertex":"Vertex","Openrouter":"OpenRouter","Model Catalog":"模型目录","Search":"搜索","Web":"Web","Community":"社区","General":"通用","All":"全部","N/A":"不适用","Unknown":"未知","Optional":"可选","Required":"必填","recommended":"推荐"
  }).map(([k,v])=>JSON.stringify(k)+":"+JSON.stringify(v)).join(",")} };
  var SKIP={SCRIPT:1,STYLE:1,INPUT:1,TEXTAREA:1,PRE:1,CODE:1};
  function tr(){
    try{
      var w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false),n;
      while((n=w.nextNode())){
        var t=n.nodeValue; if(!t)continue;
        var k=t.trim(); if(!k||!D[k]||k===D[k])continue;
        var p=n.parentNode; if(!p||p.nodeType!==1)continue;
        if(SKIP[p.tagName]||p.isContentEditable)continue;
        n.nodeValue=t.replace(k,D[k]);
      }
    }catch(e){}
  }
  if(document.readyState!=='loading')tr();
  document.addEventListener('DOMContentLoaded',tr);
  window.addEventListener('load',tr);
  setInterval(tr,500);
})();
<\/script>`;
      html = html.replace("</body>", _zhStandalone + "\n</body>");

      respHeaders.delete("content-length");
      respHeaders.delete("content-encoding");
      return new Response(html, { status: upstream.status, headers: respHeaders });
    }

    // ── JSON /api/status 响应：注入正确的 app_version（manifest 版本） ──
    // Dashboard 后端的 /api/status 返回 Python 包版本，但前端应显示应用包(manifest)版本。
    // 此处在 proxy 层覆写 app_version，确保 UI 显示与 manifest 一致。
    if (contentType.includes("application/json") && subPath === "/api/status") {
      try {
        const body = await upstream.text();
        const j = JSON.parse(body);
        if (j && j.app_version !== APP_VERSION) {
          j.app_version = APP_VERSION;
          respHeaders.delete("content-length");
          respHeaders.set("cache-control", "no-store");
          return new Response(JSON.stringify(j), { status: upstream.status, headers: respHeaders });
        }
        respHeaders.delete("content-length");
        return new Response(body, { status: upstream.status, headers: respHeaders });
      } catch {}
    }

    // ── 非 HTML 响应：原样透传 ──
    return new Response(upstream.body, {
      status:  upstream.status,
      headers: respHeaders,
    });
  } catch (e) {
    const msg = e?.message || '';
    const isConnErr = /connect|refused|abort|ECONN|fetch failed|undici/i.test(msg);

    // 自愈 502：Dashboard 无响应时尝试拉起/重启并重试一次。
    // 健康判据用「端口是否在 LISTEN」而非 pidAlive：进程挂死/变 zombie 时 kill(pid,0) 仍返回存活，
    // 旧逻辑据此跳过重启；且 spawnHermes 的 readPid 守卫也会因 pid 文件中的进程“存活”而返回
    // already_running 拒绝重启 → 端口永远无人监听，所有请求永久 502（即“Hermes 网关总是 502”）。
    if (isConnErr || /fetch failed|undici/i.test(msg)) {
      const portUp = isPortListening(DASHBOARD_PORT);
      const healAllowed = Date.now() - lastDashboardHealTs > 10000;
      if (!portUp && healAllowed) {
        lastDashboardHealTs = Date.now();
        const dp = readPid(PID_DASHBOARD);
        if(dp){log('[proxyDashboard] Dashboard暂未监听，保留现有进程并等待正式重启');return new Response(JSON.stringify({ok:false,error:'仪表盘进程尚未恢复响应，请等待或从本地维护重启应用'}),{status:503,headers:{'Content-Type':'application/json'}});}
        try {
          spawnHermes("dashboard", PID_DASHBOARD, ["dashboard", "--host", DASHBOARD_BIND, "--port", String(DASHBOARD_PORT), "--no-open", "--insecure"]);
          // 等待 dashboard ready（最多 5 秒）
          const deadline = Date.now() + 5000;
          while (Date.now() < deadline) {
            await new Promise(r => setTimeout(r, 250));
            try {
              const probe = await fetch(`http://${DASHBOARD_BIND}:${DASHBOARD_PORT}/`, { signal: AbortSignal.timeout(300) });
              if (probe.ok || probe.status < 500) break;
            } catch {}
          }
          // 重试原请求
          const headers2 = new Headers(req.headers);
          headers2.delete("host");
          headers2.set("X-Hermes-Session-Token", DASHBOARD_SESSION_TOKEN);
          const init2 = { method: req.method, headers: headers2, signal: AbortSignal.timeout(10000) };
          if (req.method !== "GET" && req.method !== "HEAD" && req.body) {
            init2.body = req.body;
            init2.duplex = "half";
          }
          const upstream2 = await fetch(target, init2);
          return new Response(upstream2.body, { status: upstream2.status, headers: upstream2.headers });
        } catch (e2) {
          log(`[proxyDashboard] 自动拉起 Dashboard 后重试失败：${e2?.message || e2}`);
        }
      }
    }

    // 连接拒绝/Dashboard 未就绪属正常现象（启动期间），仅非预期错误才记录
    if (msg && !isConnErr) log(`proxy error: ${msg}`);
    return new Response(JSON.stringify({ error: "Dashboard unavailable" }), {
      status:  502,
      headers: { "Content-Type": "application/json" },
    });
  }
}

function createLogStream(req, lastOffset) {
  const enc = new TextEncoder();
  return new ReadableStream({
    start(controller) {
      let closed = false;
      const send = (data, ev = "log") => {
        if (closed) return;
        try { controller.enqueue(enc.encode(`event: ${ev}\ndata: ${data}\n\n`)); }
        catch { closed = true; try { controller.close(); } catch {} }
      };

      // offset >= 0 = 重连，跳过历史；-1 = 首次连接，发送历史
      let offset = 0;
      if (lastOffset >= 0) {
        let fileSize = 0;
        try { if (existsSync(LOG_FILE)) fileSize = statSync(LOG_FILE).size; } catch {}
        if (lastOffset <= fileSize) {
          offset = lastOffset;
        } else {
          try {
            if (existsSync(LOG_FILE))
              readFileSync(LOG_FILE, "utf8").split("\n").filter(l => l.trim()).slice(-30)
                .forEach(l => send(l));
          } catch {}
          offset = fileSize;
        }
      } else {
        try {
          if (existsSync(LOG_FILE))
            readFileSync(LOG_FILE, "utf8").split("\n").filter(l => l.trim()).slice(-30)
              .forEach(l => send(l));
        } catch {}
        try { if (existsSync(LOG_FILE)) offset = statSync(LOG_FILE).size; } catch {}
      }

      const flush = () => {
        try {
          if (!existsSync(LOG_FILE)) return;
          const sz = statSync(LOG_FILE).size;
          if (sz < offset) {
            offset = 0;
          }
          if (sz > offset) {
            const chunk = readFileSync(LOG_FILE, "utf8").slice(offset);
            offset = sz;
            chunk.split("\n").filter(l => l.trim()).forEach(l => send(l));
          }
        } catch {}
      };

      let watcher = null;
      try {
        watcher = watch(existsSync(LOG_FILE) ? LOG_FILE : VAR_DIR, () => flush());
      } catch {}

      const heartbeat = setInterval(() => send("", "heartbeat"), 30000);

      req.signal.addEventListener("abort", () => {
        closed = true;
        clearInterval(heartbeat);
        try { watcher?.close(); } catch {}
        try { controller.close(); } catch {}
      });
    },
  });
}

// ─── 静态文件服务 ─────────────────────────────────────────────────────
function serveFile(filePath, contentType, opts={}) {
  let opened;
  try { opened=openStaticFile(opts.root || STATIC_DIR,filePath,{allowHardlinks:!!opts.stickerSource});
    if (opts.stickerSource && !isRasterSticker(opened.fd, contentType)) {
      closeSync(opened.fd); return new Response("Not Found", {status:404});
    } }
  catch(error){return new Response(error.status===403?'Forbidden':'Not Found',{status:error.status||404});}
  const {fd,stat}=opened;
  const etag='W/"'+stat.size.toString(16)+'-'+Math.floor(stat.mtimeMs).toString(16)+'"';
  const headers={'Content-Type':contentType,'ETag':etag,'Last-Modified':stat.mtime.toUTCString(),
    'Cache-Control':opts.privateMedia?'private, no-store':opts.cacheable?'public, max-age=3600':'no-cache', 'X-Content-Type-Options':'nosniff'};
  const match=opts.req?.headers.get('if-none-match');
  if(match&&(match===etag||match.trim()==='*')){closeSync(fd);return new Response(null,{status:304,headers});}
  return new Response(Readable.toWeb(createReadStream(filePath,{fd,autoClose:true})),{headers});
}

/* ═══ 安全网关 v1（tool_guard）：拦截危险操作 / 标记敏感信息 ═══
 * 拦截点：用户消息入队（/api/chat/ws-send）与 SSE 流式入口（/api/chat/stream）。
 * 设计原则：保守拦截——只拦"破坏性命令且目标明确指向系统级路径/设备"的组合，
 * 避免误伤正常讨论（如"rm -rf 的用法是什么"这类纯知识提问）。
 * PII（身份证/手机号）仅记录警告不阻断：允许用户起草含证件的文档，AI 也不会
 * 因一句"分析这段文本"就被拦死。开关经 GET/PUT /api/studio/security 查看/切换，
 * 持久化到 data/studio/security.json（默认开启）。
 * 融合来源：Octop tool_guard（allow/deny 规则 + 敏感挂载点拒绝）× shellward
 * L3 Tool Blocker / L4 Input Auditor（中文注入规则 + 危险命令清单）。 */
const TOOL_GUARD_BLOCK_RULES = [
  { re: /\brm\s+-\S*[rf]\S*\s+(\/|\/\*|~)\s*(;|&|\||$)/i, hint: "rm -rf 递归删除根目录/主目录" },
  { re: /\brm\s+-\S*[rf]\S*\s+\/(etc|boot|usr|var|bin|sbin|root|lib|lib64)\b/i, hint: "rm -rf 递归删除系统目录" },
  { re: /\bdd\s+if=[^\s]+\s+of=\/dev\/(sd|hd|vd|nvme)/i, hint: "dd 直写磁盘设备" },
  { re: /\bmkfs\.[a-z0-9]+\s+\/dev\//i, hint: "mkfs 格式化磁盘" },
  { re: /\b(reboot|poweroff|halt|shutdown\s+-[a-z]*[rh])/i, hint: "关机/重启系统" },
  { re: /:\(\)\s*\{\s*:\s*\|/i, hint: "fork bomb 分叉炸弹" },
  { re: /(curl|wget)\s+[^\s|&]+\s*\|\s*(sudo\s+)?(sh|bash)\b/i, hint: "下载并直接执行脚本 (curl|sh)" },
  { re: /\bchmod\s+-R\s+777\s+\//i, hint: "chmod -R 777 根目录" },
  { re: /\bchown\s+-R\s+(root|0:0)\s+\//i, hint: "chown -R root 根目录" },
  { re: />\s*\/dev\/(sd|hd|vd|nvme)[a-z]?\d?/i, hint: "向磁盘设备写入数据" },
  { re: /\bkill\s+-9\s+[10]\b/i, hint: "kill -9 系统进程 (pid 0/1)" },
  { re: /\b(iptables\s+-F|ufw\s+disable)\b/i, hint: "清空防火墙规则/关闭防火墙" },
  { re: /\bcryptsetup\s+luksFormat/i, hint: "加密格式化磁盘 (LUKS)" },
];
const TOOL_GUARD_WARN_RULES = [
  { re: /(?<!\d)1[3-9]\d{9}(?!\d)/g, hint: "手机号", kind: "PII" },
  { re: /\b[1-9]\d{5}(?:19|20)\d{2}(?:0[1-9]|1[0-2])(?:0[1-9]|[12]\d|3[01])\d{3}[\dXx]\b/g, hint: "身份证号", kind: "PII" },
];
let _toolGuardEnabled = true; // 默认开启；持久化 data/studio/security.json
const TOOL_GUARD_CFG_FILE = `${DATA_DIR}/studio/security.json`;
function toolGuardLoad() {
  try {
    if (existsSync(TOOL_GUARD_CFG_FILE)) {
      const j = JSON.parse(readFileSync(TOOL_GUARD_CFG_FILE, "utf8") || "{}");
      _toolGuardEnabled = j.enabled !== false;
    }
  } catch (e) { log("[tool-guard] config load failed: " + e.message); }
}
function toolGuardSave() {
  try {
    mkdirSync(dirname(TOOL_GUARD_CFG_FILE), { recursive: true });
    writeFileSync(TOOL_GUARD_CFG_FILE, JSON.stringify({ enabled: _toolGuardEnabled }, null, 2), { mode: 0o644 });
  } catch (e) { log("[tool-guard] config save failed: " + e.message); }
}
function toolGuardTextOf(msg) {
  if (typeof msg === "string") return msg;
  if (Array.isArray(msg)) return msg.map(p => (p && typeof p === "object" ? String(p.text || "") : "")).join(" ");
  if (msg && typeof msg === "object") return String(msg.text || "");
  return "";
}
function toolGuardScan(msg) {
  const text = toolGuardTextOf(msg);
  const out = { blocked: false, warnings: [] };
  if (!text) return out;
  for (const r of TOOL_GUARD_BLOCK_RULES) {
    if (r.re.test(text)) { out.blocked = true; out.hint = r.hint; return out; }
  }
  for (const r of TOOL_GUARD_WARN_RULES) {
    const m = text.match(r.re);
    if (m && m.length) out.warnings.push({ hint: r.hint, kind: r.kind, count: m.length });
  }
  return out;
}
function toolGuardCheckAndRespond(msg) {
  if (!_toolGuardEnabled) return null;
  const scan = toolGuardScan(msg);
  if (!scan.blocked) return null;
  log(`[tool-guard] 拦截危险操作：${scan.hint}`);
  return new Response(JSON.stringify({
    blocked: true,
    error: `⚠ 安全网关已拦截：检测到危险操作「${scan.hint}」。为防止 AI 误执行破坏性命令，这条消息未发送。如确属必要，请到「语音设置→安全网关」或 /api/studio/security 关闭后重试。`,
  }), { status: 403, headers: { "Content-Type": "application/json", "Cache-Control": "no-store" } });
}
toolGuardLoad();

// ─── 请求处理器 ─────────────────────────────────────────────────────────
const panelModelChecks = new ModelChecks({root: join(VAR_DIR, 'panel-state/model-checks'),
  source: createModelSource({python: `${VENV_BIN}/${PY_BIN}`, serverRoot: join(APP_DIR, 'server'), varRoot: VAR_DIR,
    getConfig: () => { const profile = _cronProfileName(); return profile && profile !== 'default' ? join(DATA_DIR, 'profiles', safeId(profile), 'config.yaml') : HERMES_CONFIG; }})});
let panelModelChecksLoadError = null;
try { panelModelChecks.load(); } catch (error) { panelModelChecksLoadError = error; log('[model-checks] state cannot load: '+error.message); }
const modelChecksHandler = createModelChecksHandler({checks: panelModelChecks, checkToken});
async function handleModelChecks(req, path) {
  if (panelModelChecksLoadError && (path.startsWith('/api/panel-models/checks') || path === '/api/panel-models/catalog'))
    return new Response(JSON.stringify({ok:false,error:'验证记录无法读取，原文件已保留，请检查存储'}), {status:503,headers:{'Content-Type':'application/json'}});
  return modelChecksHandler(req,path);
}
const handleAuxiliary = createAuxiliaryHandler({python: `${VENV_BIN}/${PY_BIN}`, serverRoot: join(APP_DIR, 'server'),
  getConfig: () => { const profile = _cronProfileName(); return profile && profile !== 'default' ? join(DATA_DIR, 'profiles', safeId(profile), 'config.yaml') : HERMES_CONFIG; },
  backupRoot: join(VAR_DIR, 'panel-state/auxiliary-backups'), checkToken});
const handleSpeechConfig = createSpeechConfigHandler({python: `${VENV_BIN}/${PY_BIN}`, serverRoot: join(APP_DIR, 'server'),
  getConfig: () => { const profile = _cronProfileName(); return profile && profile !== 'default' ? join(DATA_DIR, 'profiles', safeId(profile), 'config.yaml') : HERMES_CONFIG; },
  lockRoot: join(VAR_DIR, 'panel-state'), checkToken});
const handleConnectorTools = createConnectorToolsHandler({getConnector, readState: () => panelConnectorStore.all(), checkToken, call: callConnectorTool});
const handleConnectorConfig = createConnectorHandler({catalog: CONNECTOR_CATALOG, store: panelConnectorStore, checkToken, probe: probeConnector});
const handleMaintenance = createMaintenanceHandler({checkToken, repositories: [
  {id: 'panel', name: '面板源码仓库', path: join(DATA_DIR, 'workspace/fnos-hermes-agent-src')},
  {id: 'python', name: 'Hermes Python 内核', path: join(APP_DIR, 'hermes-src')},
]});
const handleUsage = createUsageHandler({python: `${VENV_BIN}/${PY_BIN}`, serverRoot: join(APP_DIR, 'server'), dataRoot: DATA_DIR,panelRoot:join(VAR_DIR,'panel-state')});
const handleEcho = createEchoHandler({python: `${VENV_BIN}/${PY_BIN}`, serverRoot: join(APP_DIR, 'server'),
  queueFile: '/vol1/1000/飞牛文件/html/.acl/tasks/tasks.json', backupRoot: join(VAR_DIR, 'panel-state/echo-backups'),
  draftFile: join(VAR_DIR, 'panel-state/echo-drafts.json'), checkToken});
const handleCronHistory = createCronHistoryHandler({checkToken, getHome: () => {
  const profile = _cronProfileName();
  return profile && profile !== 'default' ? join(DATA_DIR, 'profiles', safeId(profile)) : DATA_DIR;
}});
const handleCronHooks = createCronHookHandler({hooks: panelCronHooks, checkToken, jobExists: id => {
  const raw = JSON.parse(readFileSync(_cronProfileJobsFile(), 'utf8'));
  return (Array.isArray(raw) ? raw : raw.jobs).some(job => job.id === id);
}});
const handleCronUpdate = createCronUpdateHandler({
  python: `${VENV_BIN}/${PY_BIN}`, serverRoot: join(APP_DIR, 'server'), nativeRoot: join(APP_DIR, 'hermes-src'),
  backupRoot: join(VAR_DIR, 'panel-state/cron-backups'), checkToken,
  getHome: () => { const profile = _cronProfileName(); return profile && profile !== 'default' ? join(DATA_DIR, 'profiles', safeId(profile)) : DATA_DIR; },
});

async function handleFetch(req) {
  const configRW=configReaderWriter({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),state:join(VAR_DIR,'panel-state'),getFile:()=>_runtimeConfigPath(),reason:'面板服务配置'});
  const envRW=envReaderWriter({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),state:join(VAR_DIR,'panel-state'),getFile:()=>HERMES_ENV});
  const channelRW=channelConfigWriter({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),state:join(VAR_DIR,'panel-state'),getConfig:()=>_runtimeConfigPath(),getEnv:()=>HERMES_ENV});
  const url  = new URL(req.url);
  // fnOS gateway 反向代理不剥路径前缀（BASE_PATH），这里按实际 BASE_PATH 剥离
  let path = url.pathname;
  if (BASE_PATH && BASE_PATH !== "/") {
    if (path.startsWith(BASE_PATH + "/")) path = path.slice(BASE_PATH.length);
    else if (path === BASE_PATH) path = "/";
  }

  const recoveryResponse=await panelConfigRecovery.handle(req,path);if(recoveryResponse)return recoveryResponse;
  const typingResponse=await handlePanelTyping(req,path);if(typingResponse)return typingResponse;
  const runtimeResponse=await handlePanelRuntime(req,path);if(runtimeResponse)return runtimeResponse;
  const modelsResponse=await panelModels.handle(req,path,checkToken);if(modelsResponse)return modelsResponse;
  const mcpResponse=await handlePanelMcp(req,path);if(mcpResponse)return mcpResponse;
  if(path==='/api/mcp-servers'||path.startsWith('/api/mcp-servers/'))return new Response(JSON.stringify({ok:false,error:'请刷新面板后使用工具服务管理'}),{status:410,headers:{'Content-Type':'application/json'}});
  const maintenanceResponse = await handleMaintenance(req, path);
  if (maintenanceResponse) return maintenanceResponse;
  const modelChecksResponse = await handleModelChecks(req, path);
  if (modelChecksResponse) return modelChecksResponse;
  const auxiliaryResponse = await handleAuxiliary(req, path);
  if (auxiliaryResponse) return auxiliaryResponse;
  const speechConfigResponse = await handleSpeechConfig(req, path);
  if (speechConfigResponse) return speechConfigResponse;
  const libraryReviewResponse = await handlePanelLibraryReviews(req, path);
  if (libraryReviewResponse) return libraryReviewResponse;
  // Legacy chat links and in-flight sticker renders. Only raster sticker subtrees.
  if (req.method === "GET" && /^\/data\/(?:assets\/(?:nekowhale-stickers|whale-stickers|sticker-sent)\/|tmp\/sticker_text\/)/.test(path)) {
    try {
      const src = stickerSource(DATA_DIR,path);
      if (src && checkToken(req)) return serveFile(src.file,src.mime,{root:src.root,req,stickerSource:true,privateMedia:true});
      return new Response("Not Found",{status:404});
    } catch (e) { return new Response("Not Found",{status:e.status || 404}); }
  }

  const updateResponse = await handlePanelUpdate(req, path);
  if (updateResponse) return updateResponse;
  const filesResponse = await handlePanelFiles(req, path);
  if (filesResponse) return filesResponse;
  const libraryResponse = await handlePanelLibrary(req, path);
  if (libraryResponse) return libraryResponse;
  const archiveVaultResponse = await handleArchiveVault(req, path);
  if (archiveVaultResponse) return archiveVaultResponse;
  const planResponse = await handlePanelPlans(req, path);
  if (planResponse) return planResponse;
  const roomResponse = await handlePanelRooms(req, path);
  if (roomResponse) return roomResponse;
  const stickerMatch = path.match(/^\/api\/workspace-ui\/session-sticker\/([a-zA-Z0-9_-]+)\/(?:stickers\/)?([^/]+)$/);
  if (stickerMatch && req.method === "GET") {
    if (!checkToken(req)) return new Response("Unauthorized", {status:401});
    const [,id,name] = stickerMatch;
    try {
      const loc = await resolveSessionFileDir(id);
      const {root,file,mime} = sessionSticker(DATA_DIR,loc,name);
      return serveFile(file,mime,{root,req,stickerSource:true,privateMedia:true});
    } catch (e) { return new Response("Not Found",{status:e.status || 404}); }
  }
  const workspaceResponse = await handleWorkspace(req, checkToken, path);
  if (workspaceResponse) return workspaceResponse;
  const pushResponse = await pushHub.handle(req, checkToken, path);
  if (pushResponse) return pushResponse;
  const diagResponse = await clientDiag.handle(req, checkToken, path);
  if (diagResponse) return diagResponse;
  const echoResponse = await handleEcho(req, path);
  if (echoResponse) return echoResponse;
  const queueResponse = await handlePanelQueue(req, path);
  if (queueResponse) return queueResponse;

  const corsOrigin = ""; // Responses are same-origin; no wildcard or reflected CORS grants.
  const jsonHeaders = (extra = {}) => ({
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
    "Access-Control-Allow-Origin": corsOrigin,
    ...extra,
  });

  // 更新说明（随包分发的 UPDATE-LOG.md）：支持 ?after=当前版本 → 只返回该版本之后的
  // 各版本说明（本次更新内容），供更新页「本次更新说明」展示
  if (path === "/api/app/changelog" && req.method === "GET") {
    const _cl = `${APP_DIR}/UPDATE-LOG.md`;
    if (existsSync(_cl)) {
      try {
        let txt = readFileSync(_cl, "utf8");
        const _u = new URL(req.url);
        const _after = (_u.searchParams.get("after") || "").trim();
        if (_after) {
          const _cmp = (a, b) => {
            const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
            for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
              const d = (pa[i] || 0) - (pb[i] || 0);
              if (d) return d;
            }
            return 0;
          };
          // 按 "## vX.Y.Z" 切分版本段
          const sections = [];
          const lines = txt.split("\n");
          let curVer = "", curSec = [];
          const flush = () => { if (curVer && curSec.length) sections.push({ ver: curVer, text: curSec.join("\n") }); };
          for (const ln of lines) {
            const m = ln.match(/^##\s+v?(\d+\.\d+\.\d+)/);
            if (m) { flush(); curVer = m[1]; curSec = [ln]; }
            else if (curVer) curSec.push(ln);
          }
          flush();
          const newer = sections.filter(s => _cmp(s.ver, _after) > 0).map(s => s.text).join("\n\n---\n\n");
          txt = newer || "";
        }
        return new Response(txt, {
          headers: { "Content-Type": "text/markdown; charset=utf-8", "Cache-Control": "no-store" },
        });
      } catch (e) {
        return new Response(JSON.stringify({ error: "解析更新说明失败" }), { status: 500, headers: jsonHeaders() });
      }
    }
    return new Response(JSON.stringify({ error: "无更新说明" }), { status: 404, headers: jsonHeaders() });
  }

  // 实时探测 8742 网关健康状态，前端 chat 页用这个判断"是否连接"
  if (path === "/api/gateway/health") {
    const t0 = Date.now();
    let ok = false, err = null;
    try {
      const r = await fetch(`${GATEWAY_API}/models`, {
        headers: { "Authorization": `Bearer ${MONITOR_TOKEN}` },
        signal: AbortSignal.timeout(2000),
      });
      ok = r.ok;
      if (!ok) err = `HTTP ${r.status}`;
    } catch (e) { err = e?.message || String(e); }
    return new Response(JSON.stringify({ ok, latency: Date.now() - t0, error: err, port: GATEWAY_PORT }), {
      headers: jsonHeaders(),
    });
  }

  if (path === "/api/status") {
    const s = await getStatus();
    const uptimeMs = Date.now() - START_TIME;
    const uptimeStr = formatUptime(uptimeMs);
    const monPid = process.pid;
    const readPid = (f) => { try { return Number(readFileSync(f,"utf8").trim()); } catch { return null; } };
    const gwPid = readPid(PID_GATEWAY);
    const dbPid = readPid(PID_DASHBOARD);
    const isAlive = (pid) => { try { process.kill(pid, 0); return true; } catch { return false; } };
    const logDir = `${DATA_DIR}/logs`;
    const logFiles = [
      { name: "hermes.log",             label: "Monitor 日志" },
      { name: "agent.log",              label: "Agent 日志" },
      { name: "gui.log",                label: "GUI 日志" },
      { name: "errors.log",             label: "错误日志" },
      { name: "gateway.log",            label: "Gateway 日志" },
      { name: "gateway-restart.log",    label: "Gateway 重启记录" },
      { name: "gateway-shutdown-diag.log", label: "Gateway 关闭诊断" },
      { name: "gateway-exit-diag.log",  label: "Gateway 退出诊断" },
    ].map(({ name, label }) => {
      const fp = `${logDir}/${name}`;
      let size = 0, mtime = null;
      try { const s2 = statSync(fp); size = s2.size; mtime = s2.mtime.toISOString(); } catch {}
      return { name, label, size, mtime };
    });
    let memKB = null;
    try { memKB = getHermesTotalMemoryKB(); } catch {}
    return new Response(JSON.stringify({
      ...s,
      uptime: uptimeStr,
      uptimeMs,
      pid: monPid,
      gatewayPid: gwPid,
      dashboardPid: dbPid,
      gatewayAlive: gwPid ? isAlive(gwPid) : null,
      dashboardAlive: dbPid ? isAlive(dbPid) : null,
      memoryKB: memKB,
      logFiles,
      token: MONITOR_TOKEN,
      transport: SOCKET_PATH ? "unix" : "tcp",
      socket_path: SOCKET_PATH || null,
      api_server_port: GATEWAY_PORT,
      api_server_url: `http://${getLANIP()}:${GATEWAY_PORT}`,
      app_version: APP_VERSION,
      hermes_version_date: HERMES_VERSION_DATE,
    }), { headers: jsonHeaders() });
  }

  // ── Hermes 自更新（直接使用 uv，不依赖 dashboard）────────
  // GET  /api/hermes/update/check  → 从 PyPI 查询最新版本
  // POST /api/hermes/update        → 触发 uv pip install --upgrade（后台执行）
  // GET  /api/hermes/update/status → 轮询更新进度
  if (path === "/api/hermes/update/check") {
    try {
      // 每次检查都重新运行 hermes --version，确保版本准确（不依赖缓存）
      let current = HERMES_VERSION;
      try {
        // spawnSync 已在顶部从 child_process 导入
        const vr = spawnSync(HERMES_BIN, ["--version"], { stdout: "pipe", stderr: "pipe" });
        const vOut = ((vr.stdout ? vr.stdout.toString() : "").trim())
                  || ((vr.stderr ? vr.stderr.toString() : "").trim());
        if (vOut) {
          current = formatHermesVersion(vOut);
          if (current !== HERMES_VERSION) {
            HERMES_VERSION = current;
            try { writeFileSync(VERSION_FILE, current, { mode: 0o644 }); } catch {}
            log(`版本已刷新(check): ${current}`);
          }
        }
      } catch {}
      const currentVer = current.replace(/^v/, "").split(" ")[0];
      let latest = "unknown";
      let latestDate = "";

      // v0.20.0 起官方停止 PyPI 分发（wheel/sdist 被构建守卫拦截），PyPI 上永远显示旧版
      // 0.19.0。源码模式（本包内置 hermes-src）下不再查询 PyPI，latest 直接展示当前版本。
      const sourceMode = compareVersions(currentVer, "0.20.0") >= 0;

      // 优先 PyPI JSON API（可获取发布日期）
      if (!sourceMode) {
        try {
          const r = await fetch("https://pypi.org/pypi/hermes-agent/json", {
            signal: AbortSignal.timeout(10000),
          });
          if (r.ok) {
            const data = await r.json();
            if (data.info && data.info.version) {
              latest = data.info.version;
              const rels = data.releases && data.releases[latest];
              if (rels && rels.length > 0 && rels[0].upload_time) {
                const d = new Date(rels[0].upload_time);
                latestDate = `(${d.getFullYear()}.${d.getMonth() + 1}.${d.getDate()})`;
              }
            }
          }
        } catch {}

        // 兜底：阿里云镜像 simple index（无日期信息）
        if (latest === "unknown") {
          try {
            const r2 = await fetch("https://pypi.tuna.tsinghua.edu.cn/simplehermes-agent/", {
              signal: AbortSignal.timeout(10000),
            });
            const html = await r2.text();
            const versions = [...html.matchAll(/hermes-agent-(\d+\.\d+\.\d+)/g)].map(m => m[1]);
            if (versions.length > 0) {
              versions.sort((a, b) => {
                const pa = a.split(".").map(Number);
                const pb = b.split(".").map(Number);
                for (let i = 0; i < 3; i++) { if (pa[i] !== pb[i]) return pa[i] - pb[i]; }
                return 0;
              });
              latest = versions[versions.length - 1];
            }
          } catch {}
        }
      } else {
        latest = currentVer;
      }

      const latestDisplay = latest !== "unknown" ? `v${latest} ${latestDate}`.trim() : "未知";
      const updateAvailable = latest !== "unknown" && compareVersions(latest, currentVer) > 0;
      return new Response(JSON.stringify({ current, latest: latestDisplay, updateAvailable, date: HERMES_VERSION_DATE }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message || String(e) }), {
        status: 500, headers: { "Content-Type": "application/json" },
      });
    }
  }

  if (path === "/api/hermes/update" && req.method === "POST") {
    if (updateState === "updating") {
      return new Response(JSON.stringify({ error: "更新进行中，请等待" }), {
        status: 409, headers: { "Content-Type": "application/json" },
      });
    }
    // 重置状态
    updateState = "updating";
    updateOutput = [];
    updateExitCode = null;

    const env = {
      ...process.env,
      UV_INDEX_URL: "https://pypi.tuna.tsinghua.edu.cn/simple",
      UV_CACHE_DIR: `${DATA_DIR}/.uv-cache`,
      PATH: `${VENV_BIN}:/usr/local/bin:/usr/bin:/bin`,
    };

    try {
      // v0.20.0+ 源码模式：hermes 不再从 PyPI 分发，更新 = 重新执行内置源码 editable 安装
      // （无源码时退回旧版 PyPI 升级，用于旧包/热补丁场景）
      const srcMode = existsSync(`${APP_DIR}/hermes-src/pyproject.toml`);
      const installArgs = srcMode
        ? ["pip", "install", "--python", `${DATA_DIR}/venv/bin/python3`, "--no-cache", "-e", `${APP_DIR}/hermes-src[all]`]
        : ["pip", "install", "--python", `${DATA_DIR}/venv/bin/python3`, "--upgrade", "--no-cache", "hermes-agent[all]"];
      const proc = spawn(UV_BIN_PATH, installArgs, { env, stdio: ["ignore", "pipe", "pipe"] });
      updateProc = proc;

      const decoder = new TextDecoder();
      const collectStream = async (stream, isErr) => {
        const reader = Readable.toWeb(stream).getReader();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            const text = decoder.decode(value, { stream: true });
            for (const line of text.split("\n")) {
              if (line.trim()) {
                updateOutput.push((isErr ? "[stderr] " : "") + line.trim());
                if (updateOutput.length > 200) updateOutput.shift();
              }
            }
          }
        } catch {}
      };

      collectStream(proc.stdout, false);
      collectStream(proc.stderr, true);

      proc.on("exit", (code) => {
        updateExitCode = code;
        updateState = code === 0 ? "done" : "error";
        if (code === 0) {
          // 清除版本缓存，下次 status 查询时重新检测
          try { unlinkSync(VERSION_FILE); } catch {}
          try { HERMES_VERSION = "unknown"; } catch {}
        }
        updateProc = null;
        log(`hermes self-update finished: exit=${code}`);
      });

      return new Response(JSON.stringify({ ok: true, message: "更新已启动" }), {
        headers: { "Content-Type": "application/json" },
      });
    } catch (e) {
      updateState = "error";
      updateProc = null;
      return new Response(JSON.stringify({ error: e.message || String(e) }), {
        status: 500, headers: { "Content-Type": "application/json" },
      });
    }
  }

  if (path === "/api/hermes/update/status") {
    let currentVer = HERMES_VERSION;
    if (updateState === "done") {
      try {
        // spawnSync 已在顶部从 child_process 导入
        const verResult = spawnSync(HERMES_BIN, ["--version"], { stdout: "pipe", stderr: "pipe" });
        const verOut = ((verResult.stdout ? verResult.stdout.toString() : "").trim())
                    || ((verResult.stderr ? verResult.stderr.toString() : "").trim());
        if (verOut) {
          currentVer = formatHermesVersion(verOut);
          HERMES_VERSION = currentVer;
          try { writeFileSync(VERSION_FILE, currentVer, { mode: 0o644 }); } catch {}
        }
      } catch {}
    }
    return new Response(JSON.stringify({
      status: updateState,
      output: updateOutput.slice(-50),
      exitCode: updateExitCode,
      version: currentVer,
    }), { headers: { "Content-Type": "application/json" } });
  }

  // ── 应用包更新（GitHub Releases / Actions）────────────────────────────────
  const GITHUB_REPO = process.env.GITHUB_REPO || "veenyi/fnos-hermes-agent";
  const GITHUB_PAT_FILE = `${VAR_DIR}/github_pat`;

  function getGitHubPAT() {
    try {
      const envPat = process.env.GITHUB_TOKEN || process.env.GITHUB_PAT;
      if (envPat) return envPat.trim();
      if (existsSync(GITHUB_PAT_FILE)) return readFileSync(GITHUB_PAT_FILE, "utf8").trim();
    } catch {}
    return "";
  }

  // 获取「最新发布」的 release：按 published_at 排序而非 created_at。
  // （releases?per_page=1 按 created_at 倒序，重建过的旧 release 会排在前面，导致热更拉到旧版本）
  async function fetchLatestPublishedRelease(headers) {
    const r = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/releases?per_page=30`, {
      signal: AbortSignal.timeout(15000), headers,
    });
    if (!r.ok) return { data: null, status: r.status };
    const list = await r.json();
    const published = (Array.isArray(list) ? list : []).filter(x => !x.draft && x.published_at);
    if (!published.length) return { data: null, status: r.status };
    published.sort((a, b) => String(b.published_at).localeCompare(String(a.published_at)));
    return { data: published[0], status: r.status };
  }

  // POST /api/app/auto-update → 自动更新：下载最新 FPK 并用 appcenter-cli 直接安装升级
  if (path === "/api/app/auto-update" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      // source 通道选择：auto（多源依次尝试，默认）/ github（仅 GitHub：加速镜像+直连）/ webdav（仅 WebDAV 内部通道）
      const source = String(body.source || "auto").trim().toLowerCase();
      let url = String(body.url || "").trim();
      let version = String(body.version || "");
      if (!url && source !== "webdav") {
        // webdav 通道不需要 url（直接从 WebDAV 取包），且不应查 GitHub 覆盖 version
        const pat = getGitHubPAT();
        const headers = { "Accept": "application/vnd.github+json", "User-Agent": "fnos-hermes-agent" };
        if (pat) headers["Authorization"] = `Bearer ${pat}`;
        const { data } = await fetchLatestPublishedRelease(headers);
        if (data && Array.isArray(data.assets)) {
          const asset = data.assets.find(a => /\.fpk$/i.test(a.name || ""));
          if (asset && asset.browser_download_url) { url = asset.browser_download_url; version = data.tag_name || ""; }
        }
      }
      if (!url && source !== "webdav") return new Response(JSON.stringify({ ok: false, error: "未找到安装包下载地址（GitHub 可能限流，请稍后或改用网页下载）" }), { headers: jsonHeaders() });
      log(`[app-update] 开始自动更新 ${version || ""}（通道=${source}）：${url || "WebDAV"}`);
      // 下载源：优先 alist 分享直链（用户飞牛 5667/p/<分享码>/<文件>，公众下载通道免认证、国内快）
      // —— WebDAV（5244）仅为发布推送通道，不用于公众下载
      const _shareBase = (process.env.HERMES_SHARE_BASE || "").replace(/\/+$/, "");
      const _shareCode = process.env.HERMES_SHARE_CODE || "";
      const _verTag = String(version || "").replace(/^fnos-hermes-agent_v|^v/, "");
      const _shareFile = _verTag ? `fnos-hermes-agent_v${_verTag}.fpk` : "";
      let dl = null;
      let buf = null;
      if (_shareFile) {
        // ① WebDAV（用户内部更新通道，凭证从 data/.env 读取，不硬编码）
        const _envCfg = (() => { try { const t = readFileSync(`${DATA_DIR}/.env`, "utf8"); const g = k => { const m = t.match(new RegExp("^" + k + "\\s*=\\s*(.+)$", "m")); return m ? m[1].trim() : ""; }; return { u: g("HERMES_WD_USER"), p: g("HERMES_WD_PASS"), b: g("HERMES_WD_BASE") }; } catch { return { u: "", p: "", b: "" }; } })();
        const _wdBase = (_envCfg.b || "").replace(/\/+$/, "");
        const _wdPath = (_envCfg.p2 || "Fnosapp").replace(/^\/+|\/+$/g, "");
        if (source !== "github" && _wdBase) {
          try {
            // 匿名调用 OpenList API 获取 raw_url（无需认证，公众下载通道）
            const apiUrl = `${_wdBase}/api/fs/get`;
            log(`[app-update] 尝试从 OpenList 获取下载直链: ${apiUrl}`);
            const apiRes = await fetch(apiUrl, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ path: `/${_wdPath}/${_shareFile}`, password: "" }),
              signal: AbortSignal.timeout(15000),
            });
            if (apiRes.ok) {
              const apiJson = await apiRes.json();
              const rawUrl = apiJson?.data?.raw_url;
              if (rawUrl) {
                log(`[app-update] 获取到直链，开始下载`);
                dl = await fetch(rawUrl, { signal: AbortSignal.timeout(120000) });
                if (dl.ok) {
                  const _b0 = Buffer.from(await dl.arrayBuffer());
                  if (_b0.length > 0 && (_b0[0] === 0x1f && _b0[1] === 0x8b)) { buf = _b0; log(`[app-update] OpenList 下载成功 ${(buf.length/1048576).toFixed(1)}MB`); }
                  else { log(`[app-update] OpenList 内容非 FPK，切换下一源`); dl = null; }
                } else { log(`[app-update] OpenList 直链下载失败 HTTP ${dl.status}，切换下一源`); dl = null; }
              } else { log(`[app-update] OpenList 未返回 raw_url，切换下一源`); dl = null; }
            } else { log(`[app-update] OpenList API 失败 HTTP ${apiRes.status}，切换下一源`); dl = null; }
          } catch (e) { log(`[app-update] OpenList 下载异常: ${e.message}`); dl = null; }
        }
        // ② alist 分享直链（公众通道，免认证）——仅 auto 通道使用
        if (source === "auto" && !dl && !buf && _shareBase && _shareCode) {
          try {
            const shareUrl = `${_shareBase}/p/${_shareCode}/${_shareFile}`;
            log(`[app-update] 尝试从 alist 分享直链下载: ${shareUrl}`);
            dl = await fetch(shareUrl, { signal: AbortSignal.timeout(60000) });
            if (dl.ok) {
              const _b1 = Buffer.from(await dl.arrayBuffer());
              if (_b1.length > 0 && (_b1[0] === 0x1f && _b1[1] === 0x8b)) { buf = _b1; log(`[app-update] 分享直链下载成功 ${(buf.length/1048576).toFixed(1)}MB`); }
              else { log(`[app-update] 分享直链内容非 FPK（可能是预览页），切换下一源`); dl = null; }
            } else { log(`[app-update] 分享直链下载失败 HTTP ${dl.status}`); dl = null; }
          } catch (e) { log(`[app-update] 分享直链下载异常: ${e.message}`); dl = null; }
        }
        // ③ GitHub 加速镜像（大陆中继）——auto / github 通道使用
        if ((source === "auto" || source === "github") && !dl && !buf) {
          try {
            const _ghp = (process.env.HERMES_GHPROXY || "https://ghproxy.net/").replace(/\/+$/, "");
            log(`[app-update] 尝试 GitHub 加速镜像下载`);
            dl = await fetch(`${_ghp}/${url.replace(/^https?:\/\//, "")}`, { signal: AbortSignal.timeout(30000) });
            if (dl.ok) {
              const _b2 = Buffer.from(await dl.arrayBuffer());
              if (_b2.length > 0 && (_b2[0] === 0x1f && _b2[1] === 0x8b)) { buf = _b2; log(`[app-update] 加速镜像下载成功 ${(buf.length/1048576).toFixed(1)}MB`); }
              else { log(`[app-update] 加速镜像内容非 FPK，切换 GitHub 直连`); dl = null; }
            } else { log(`[app-update] 加速镜像下载失败 HTTP ${dl.status}`); dl = null; }
          } catch (e) { log(`[app-update] 加速镜像下载异常: ${e.message}`); dl = null; }
        }
      }
      // ④ GitHub 直连（兜底）——auto / github 通道使用；webdav 通道不降级
      if (source !== "webdav" && !dl && !buf) {
        dl = await fetch(url, { signal: AbortSignal.timeout(600000) });
        if (dl.ok) {
          const _b3 = Buffer.from(await dl.arrayBuffer());
          if (_b3.length > 0 && (_b3[0] === 0x1f && _b3[1] === 0x8b)) { buf = _b3; log(`[app-update] GitHub 下载成功 ${(buf.length/1048576).toFixed(1)}MB`); }
          else throw new Error("GitHub 下载内容不是有效的 FPK 包（gzip）");
        } else throw new Error(`GitHub 下载失败: HTTP ${dl.status}`);
      }
      // 下载后校验 gzip 头：分享服务对完整请求可能返回 HTML 预览页（HTTP 200 但非文件），
      // 非 gzip 时自动切换到 GitHub 兜底下载
      if (!buf) {
        if (source === "webdav") throw new Error("WebDAV 通道下载失败：未获取到安装包（请确认 WebDAV 凭证已配置且已发布该版本，或改用 GitHub Release 通道）");
        if (source === "github") throw new Error("GitHub 通道下载失败：请检查网络/代理后重试，或改用 WebDAV 通道");
        throw new Error("安装包为空");
      }
      const fpkPath = `/tmp/hermes-agent-update.fpk`;
      writeFileSync(fpkPath, buf);
      log(`[app-update] FPK 已下载: ${(buf.length / 1048576).toFixed(1)}MB → ${fpkPath}`);
      // 校验：确认是合法 fpk（gzip tar 头）
      if (buf[0] !== 0x1f || buf[1] !== 0x8b) throw new Error("下载内容不是有效的 FPK 包（gzip）");
      // 安装：appcenter-cli install-fpk 不支持已安装应用升级（实测仅返回 "is installed" 不执行），
      // 改为「解包覆盖」——解压 FPK 直接覆盖 APP_DIR（hermes-agent 有写权限，配置在 @appdata/@apphome 不受影响）
      // 先停止 gateway/dashboard（释放端口与文件占用），再解压覆盖——「先 stop 再解压」流程
      try {
        await stopPid(PID_GATEWAY);
        await stopPid(PID_DASHBOARD);
        log(`[app-update] 已停止旧 gateway/dashboard（释放 8742/9219）`);
      } catch (e) { log(`[app-update] 停止旧服务异常（继续覆盖）: ${e.message}`); }
      const stage = `/tmp/fpk-auto-${Date.now()}`;
      try {
        execSync(`rm -rf ${stage} && mkdir -p ${stage} && tar xzf ${fpkPath} -C ${stage}`, { timeout: 120000, encoding: "utf8" });
        execSync(`cd ${stage} && tar xzf app.tgz`, { timeout: 600000, encoding: "utf8" });
        // 覆盖应用目录（bin/server/ui/hermes-src/package.json 等；config 为 fnOS 只读模板不覆盖）
        execSync(`cp -rf ${stage}/bin ${stage}/server ${stage}/ui ${stage}/hermes-src ${stage}/package.json ${APP_DIR}/ 2>/dev/null; true`, { timeout: 600000, encoding: "utf8" });
        // 更新 fnOS 应用壳 manifest（sudo cp 免密白名单已配置）
        try { execSync(`sudo -n cp ${stage}/manifest /var/apps/hermes-agent/manifest && sudo -n chown root:root /var/apps/hermes-agent/manifest 2>/dev/null; true`, { timeout: 15000 }); } catch {}
        execSync(`rm -rf ${stage}`, { timeout: 30000 });
      } catch (e) {
        try { execSync(`rm -rf ${stage}`, { timeout: 30000 }); } catch {}
        throw new Error("解包覆盖失败: " + e.message);
      }
      // 清除版本缓存：确保 UI 显示新版本（VERSION_OVERRIDE_FILE 残留会导致显示旧版本）
      try { unlinkSync(VERSION_OVERRIDE_FILE); } catch {}
      try { HERMES_VERSION = "unknown"; } catch {}
      try { APP_VERSION = readAppVersion(); } catch {}
      // 同步 fnOS 应用中心版本记录（postgres appcenter.app 表）——应用中心 UI 显示版本与 manifest 一致
      const _appVer = String(version || "").replace(/^fnos-hermes-agent_v|^v/, "");
      if (_appVer) {
        try {
          execSync(`sudo -n sudo -u postgres /usr/bin/psql -d appcenter -c "UPDATE app SET version='${_appVer}' WHERE app_name='hermes-agent'" 2>&1`, { timeout: 15000 });
          log(`[app-update] fnOS 应用中心版本已同步: ${_appVer}`);
        } catch (e2) {
          log(`[app-update] 应用中心版本同步失败: ${e2.message}`);
          // fallback：直接改写 /var/apps/hermes-agent/manifest 的 version（尽力同步显示）
          try {
            const _mf = "/var/apps/hermes-agent/manifest";
            if (existsSync(_mf)) {
              const _mt = readFileSync(_mf, "utf8").replace(/^version\s*=.*$/m, `version               = ${_appVer}`);
              writeFileSync(_mf, _mt);
              log(`[app-update] 已直接改写 manifest 版本为 ${_appVer}`);
            }
          } catch (e3) { log(`[app-update] manifest 版本改写失败: ${e3.message}`); }
        }
      }
      log(`[app-update] 文件覆盖完成（version=${version || "?"}），服务即将自动重启生效`);
      // ── 官方对齐：upgrade_callback 式权限修复（防覆盖后权限漂移导致 EACCES/启动失败）──
      // 官方升级流程在 upgrade_callback 阶段会修复目录属主/权限（TRIM_APP_STATUS=UPGRADE 语义）；
      // auto-update 自更新不经过系统 upgrade_callback，这里补齐等价修复：
      // 只修 APP_DIR（被覆盖的 bin/server/ui/hermes-src）与 VAR_DIR（pid/tmp/socket），
      // DATA_DIR（含大体积 venv）不在覆盖范围、跳过避免 chown 大目录耗时。
      try {
        const _owner = execSync(`stat -c '%U:%G' ${APP_DIR} 2>/dev/null`).toString().trim() || "hermes-agent:hermes-agent";
        // chown 需特权（monitor 以应用用户运行，走 sudo -n 免密；chmod 属主可自改）
        execSync(`sudo -n chown -R ${_owner} ${APP_DIR} 2>/dev/null; chmod 775 ${APP_DIR} 2>/dev/null; true`, { timeout: 60000 });
        execSync(`sudo -n chown -R ${_owner} ${VAR_DIR} 2>/dev/null; chmod -R 750 ${VAR_DIR} 2>/dev/null; true`, { timeout: 60000 });
        log(`[app-update] 权限修复完成（${_owner}，对齐 upgrade_callback / TRIM_APP_STATUS=UPGRADE）`);
      } catch (e) { log(`[app-update] 权限修复异常（继续自重启）: ${e.message}`); }
      // monitor 安全自重启：spawn 延迟拉起启动脚本（完整 env），随后本进程退出；
      // 优先 start-monitor.sh（部分机器手动固化）；缺失时 fallback 到 fnOS 标准 cmd/main start
      // （main 需显式传 TRIM_APPDEST=target——其脚本内 fallback 是壳目录，无 env 时会找不到 monitor.js）
      try {
        const _sm = `${VAR_DIR}/start-monitor.sh`;
        const _rs = existsSync(_sm)
          ? `sleep 3; ${_sm}`
          : `sleep 3; env TRIM_APPDEST=${APP_DIR} TRIM_PKGHOME=${DATA_DIR.replace(/\/data$/, "")} TRIM_PKGVAR=${VAR_DIR} bash /var/apps/hermes-agent/cmd/main start`;
        spawn("/bin/sh", ["-c", _rs], { detached: true, stdio: "ignore" }).unref();
        log(`[app-update] 已安排 monitor 自重启（${existsSync(_sm) ? "start-monitor.sh" : "cmd/main start"}）`);
      } catch (e) { log(`[app-update] 自重启安排失败: ${e.message}`); }
      setTimeout(() => { try { process.exit(0); } catch {} }, 1500);
      return new Response(JSON.stringify({ ok: true, version, note: "文件已覆盖，服务即将自动重启生效" }), { headers: jsonHeaders() });
    } catch (e) {
      log(`[app-update] 自动更新失败: ${e.message}`);
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  if (path === "/api/app/update/check") {
    try {
      const pat = getGitHubPAT();
      const headers = { "Accept": "application/vnd.github+json", "User-Agent": "fnos-hermes-agent" };
      if (pat) headers["Authorization"] = `Bearer ${pat}`;

      // 优先按 published_at 取最新已发布 release（避免 created_at 排序导致拉到重建的旧 release）
      let { data, status: firstStatus } = await fetchLatestPublishedRelease(headers);
      let rateLimited = false;
      if (!data && (firstStatus === 401 || firstStatus === 403)) {
        // 401/403 = PAT 无效或 GitHub API 限流（无 PAT 时 60次/小时）
        rateLimited = true;
      }
      // 兜底：未认证或没有 release 时尝试 /releases/latest
      if (!data && !rateLimited) {
        const r = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/releases/latest`, {
          signal: AbortSignal.timeout(15000),
          headers,
        });
        if (r.ok) {
          data = await r.json();
        } else if (r.status === 401 || r.status === 403) {
          rateLimited = true;
        } else {
          throw new Error(`GitHub API ${r.status}`);
        }
      }
      if (rateLimited && !data) {
        // PAT 未配置或 GitHub 限流：返回友好提示而非502错误
        const hint = !pat
          ? "未配置 GitHub PAT，公开仓库限速 60次/小时，当前已耗尽。可在设置页面配置 PAT 解除限速。"
          : "GitHub API 请求被限流（403），请稍后重试或检查 PAT 权限。";
        return new Response(JSON.stringify({
          current: APP_VERSION,
          latest: APP_VERSION,
          updateAvailable: false,
          rateLimited: true,
          hint,
        }), { headers: jsonHeaders() });
      }
      if (!data || !data.tag_name) throw new Error("GitHub API 未返回 release 信息");

      const tag = String(data.tag_name || "");
      const latest = tag.replace(/^fnos-hermes-agent_v|^v/, "").trim() || "unknown";
      const current = APP_VERSION;
      // 语义化版本比较：仅当 GitHub 版本严格大于本地版本时才提示更新
      const updateAvailable = latest !== "unknown" && compareVersions(latest, current) > 0;

      // 提取 .fpk 安装包直链，供用户直接下载
      let download_url = "";
      if (Array.isArray(data.assets)) {
        const asset = data.assets.find(a => /\.fpk$/i.test(a.name || ""));
        if (asset && asset.browser_download_url) download_url = asset.browser_download_url;
      }

      return new Response(JSON.stringify({
        current,
        latest,
        updateAvailable,
        html_url: data.html_url || "",
        download_url,
        published_at: data.published_at || "",
        body: data.body || "",
        repo: GITHUB_REPO,
        // 热更新信息：检查 release assets 中是否有 hot-patch.json
        hot_patch_available: Array.isArray(data.assets) && data.assets.some(a => (a.name || "") === "hot-patch.json"),
      }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message || String(e) }), {
        status: 502, headers: jsonHeaders(),
      });
    }
  }

  // ─── 热更新：下载并替换文件，无需全量 fpk 重装 ───────────────────────────
  // ─── 自重启助手：更新后拉起新进程（不依赖外部 supervisor） ────────────────
  // 先 spawn 一个 detached 新进程再退出；新进程启动时会 unlink 旧 socket 文件
  // 后重新监听，因此新旧进程交接不会发生 EADDRINUSE。若 spawn 失败则退化为
  // 单纯退出，由 fnOS 应用管理兜底拉起。
  function scheduleMonitorRestart(reason, delayMs) {
    try { writeFileSync(`${VAR_DIR}/.hot-restart`, String(Date.now())); } catch {}
    setTimeout(() => {
      log(`[自重启] ${reason} — 拉起新 monitor 进程...`);
      try {
        const script = fileURLToPath(import.meta.url);
        // 用 shell 延迟 1.5 秒再拉新进程：确保旧进程先退出并释放 socket / TCP 8650 端口，
        // 避免新进程绑端口失败导致 standalone UI 不可用。
        const child = spawn("/bin/sh", ["-c", `sleep 1.5; exec "${process.execPath}" "${script}"`], {
          detached: true, stdio: "inherit", env: process.env, cwd: process.cwd(),
        });
        child.unref();
      } catch (e) {
        log(`[自重启] spawn 新进程失败（退化为直接退出，等待外部拉起）: ${e.message}`);
      }
      setTimeout(() => process.exit(0), 300);
    }, delayMs || 2000);
  }

  if (path === "/api/app/hot-patch" && req.method === "POST") {
    try {
      const pat = getGitHubPAT();
      const ghHeaders = { "Accept": "application/vnd.github+json", "User-Agent": "fnos-hermes-agent" };
      if (pat) ghHeaders["Authorization"] = `Bearer ${pat}`;

      // 1. 获取最新已发布 release（按 published_at，避免拉到重建的旧 release）
      const hpRes = await fetchLatestPublishedRelease(ghHeaders);
      const relData = hpRes.data;
      if (!relData) return new Response(JSON.stringify({ ok: false, error: "无法获取 Release 信息" }), { status: 502, headers: jsonHeaders() });

      // 2. 找 hot-patch.json asset
      const patchAsset = (relData.assets || []).find(a => (a.name || "") === "hot-patch.json");
      if (!patchAsset) return new Response(JSON.stringify({ ok: false, error: "该版本无热更新包，请使用完整安装" }), { status: 404, headers: jsonHeaders() });

      // 3. 下载 hot-patch.json（私有仓库需认证）
      const dlHeaders = { "Accept": "application/octet-stream", "User-Agent": "fnos-hermes-agent" };
      if (pat) dlHeaders["Authorization"] = `Bearer ${pat}`;
      const patchRes = await fetch(patchAsset.url || patchAsset.browser_download_url, { signal: AbortSignal.timeout(15000), headers: dlHeaders });
      if (!patchRes.ok) throw new Error("下载 hot-patch.json 失败: " + patchRes.status);
      const patchManifest = await patchRes.json();

      // 4. 校验 base_version
      if (patchManifest.base_version && compareVersions(APP_VERSION, patchManifest.base_version) < 0) {
        return new Response(JSON.stringify({ ok: false, error: `当前版本 ${APP_VERSION} 低于热更基线 ${patchManifest.base_version}，请完整安装` }), { status: 400, headers: jsonHeaders() });
      }

      // 5. 逐个下载并替换文件
      const results = [];
      let needRestart = false;
      // 构建 asset name → API URL 映射（用于私有仓库认证下载）
      // 兼容两种命名：hotpatch_server_monitor.js / 裸文件名 monitor.js
      const assetUrlMap = {};
      (relData.assets || []).forEach(a => { if (a.name) assetUrlMap[a.name] = a.url; });
      for (const file of (patchManifest.files || [])) {
        const targetPath = `${APP_DIR}/${file.path}`;
        const bakPath = targetPath + ".hot-bak";
        try {
          // 优先用 API URL（私有仓库认证下载更可靠）；依次尝试 hotpatch_ 前缀名、裸文件名、manifest 内 url
          const assetName = 'hotpatch_' + file.path.replace(/\//g, '_');
          const baseName = file.path.substring(file.path.lastIndexOf("/") + 1);
          const dlUrl = assetUrlMap[assetName] || assetUrlMap[baseName] || file.url;
          if (!dlUrl) { results.push({ path: file.path, ok: false, error: "Release 中未找到对应资产: " + assetName + " / " + baseName }); continue; }
          // 下载文件内容（私有仓库需认证）
          const fileRes = await fetch(dlUrl, { signal: AbortSignal.timeout(60000), headers: dlHeaders });
          if (!fileRes.ok) { results.push({ path: file.path, ok: false, error: "HTTP " + fileRes.status }); continue; }
          const buf = Buffer.from(await fileRes.arrayBuffer());
          // 备份原文件
          if (existsSync(targetPath)) { try { copyFileSync(targetPath, bakPath); } catch {} }
          // 写入新文件
          const dir = targetPath.substring(0, targetPath.lastIndexOf("/"));
          if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
          writeFileSync(targetPath, buf, { mode: 0o644 });
          results.push({ path: file.path, ok: true, size: buf.length });
          if (file.path.indexOf("server/") >= 0 || file.path === "manifest") needRestart = true;
        } catch (fe) {
          results.push({ path: file.path, ok: false, error: fe.message });
        }
      }

      // 6. 持久化版本号（manifest 或兜底覆盖文件），并令当前进程立即上报新版本
      if (patchManifest.version) writeAppVersion(patchManifest.version);

      const allOk = results.every(r => r.ok);
      // 7. 若含后端文件变更：先停掉 gateway/dashboard，再自重启加载新代码。
      //    新 monitor 启动时 maybeAutoStartServices 会全新拉起两者，确保「更新后网关一定重启」，
      //    不依赖旧 pid 存活探测（此前旧网关存活会导致自动启动被跳过）。
      if (allOk && needRestart) {
        try {
          await stopPid(PID_GATEWAY);
          await stopPid(PID_DASHBOARD);
            resetGatewayCrashLoop();
          log("[HotPatch] gateway/dashboard 已停止，monitor 自重启后将自动重新拉起");
        } catch (e) { log(`[HotPatch] 停止服务失败（非致命）: ${e && e.message}`); }
        scheduleMonitorRestart("HotPatch", 2000);
      }

      return new Response(JSON.stringify({
        ok: allOk,
        version: patchManifest.version || "",
        need_restart: needRestart,
        results,
        hint: allOk ? (needRestart ? "后端文件已更新，服务将在 2 秒后自动重启" : "UI 文件已更新，刷新浏览器即可生效") : "部分文件更新失败，请检查日志",
      }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message || String(e) }), { status: 500, headers: jsonHeaders() });
    }
  }

  if (path === "/api/app/update/token" && req.method === "POST") {
    try {
      const body = await req.json();
      const pat = (body && body.pat || "").trim();
      if (!pat) {
        try { unlinkSync(GITHUB_PAT_FILE); } catch {}
        return new Response(JSON.stringify({ ok: true, saved: false }), { headers: jsonHeaders() });
      }
      writeFileSync(GITHUB_PAT_FILE, pat, { mode: 0o600 });
      return new Response(JSON.stringify({ ok: true, saved: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message || String(e) }), {
        status: 500, headers: jsonHeaders(),
      });
    }
  }

  if (path === "/api/app/update/dispatch" && req.method === "POST") {
    try {
      const pat = getGitHubPAT();
      if (!pat) {
        return new Response(JSON.stringify({ ok: false, error: "未配置 GitHub PAT，请先在应用更新卡片中设置" }), {
          status: 401, headers: jsonHeaders(),
        });
      }
      const version = APP_VERSION;
      const r = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/actions/workflows/Build_fnos-hermes-agent.yml/dispatches`, {
        method: "POST",
        headers: {
          "Accept": "application/vnd.github+json",
          "Authorization": `Bearer ${pat}`,
          "User-Agent": "fnos-hermes-agent",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ ref: "main", inputs: { version } }),
        signal: AbortSignal.timeout(15000),
      });
      if (!r.ok) {
        const txt = await r.text();
        throw new Error(`GitHub dispatch ${r.status}: ${txt}`);
      }
      log(`[应用更新] 已触发 GitHub Actions 构建: ${GITHUB_REPO}, 版本 ${version}`);
      return new Response(JSON.stringify({ ok: true, version, repo: GITHUB_REPO }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message || String(e) }), {
        status: 502, headers: jsonHeaders(),
      });
    }
  }

  if (path === "/api/app/update/run") {
    try {
      const pat = getGitHubPAT();
      const headers = { "Accept": "application/vnd.github+json", "User-Agent": "fnos-hermes-agent" };
      if (pat) headers["Authorization"] = `Bearer ${pat}`;
      const r = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/actions/runs?branch=main&per_page=1`, {
        signal: AbortSignal.timeout(15000),
        headers,
      });
      if (!r.ok) throw new Error(`GitHub API ${r.status}`);
      const data = await r.json();
      const run = (data.workflow_runs && data.workflow_runs[0]) || null;
      return new Response(JSON.stringify({
        run: run ? {
          id: run.id,
          status: run.status,
          conclusion: run.conclusion,
          html_url: run.html_url,
          created_at: run.created_at,
          name: run.name,
        } : null,
      }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ error: e.message || String(e) }), {
        status: 502, headers: jsonHeaders(),
      });
    }
  }

  // ─── 隧道（Cloudflare Tunnel 外网访问）API ───
  if (path === "/api/tunnel/status" && req.method === "GET") {
    try {
      const st = _loadTunnelState();
      let running = _tunnelRunning();
      if (!running && st.pid) running = pidAlive(st.pid);
      if (running) {
        const u = _extractTunnelUrl();
        if (u && u !== st.url) { st.url = u; _saveTunnelState(st); }
      }
      return new Response(JSON.stringify({
        ok: true, running,
        mode: st.mode || "quick", target: st.target || String(UI_PORT),
        url: st.url || "", name: st.name || "",
        pid: st.pid || (_tunnelProc ? _tunnelProc.pid : 0), started_at: st.started_at || 0,
        cloudflared: _cloudflaredVersion() || "",
        log_tail: _tailTunnelLog(80),
        ui_port: UI_PORT,
      }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/tunnel/start" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const mode = body.mode === "named" ? "named" : "quick";
      const target = String(body.target || UI_PORT).trim();
      const prevSt = _loadTunnelState();
      if (_tunnelRunning() || (prevSt.pid && pidAlive(prevSt.pid))) await _stopTunnel();
      const ensure = await _ensureCloudflared();
      if (!ensure.ok) return new Response(JSON.stringify({ ok: false, error: ensure.error }), { status: 500, headers: jsonHeaders() });
      const r = mode === "named"
        ? await _startNamedTunnel(target, body.token)
        : await _startQuickTunnel(target);
      if (!r.ok) return new Response(JSON.stringify({ ok: false, error: r.error }), { status: 500, headers: jsonHeaders() });
      return new Response(JSON.stringify({ ok: true, mode, ...r }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/tunnel/stop" && req.method === "POST") {
    try {
      await _stopTunnel();
      return new Response(JSON.stringify({ ok: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ─── 完整安装：中转下载最新 Release 的 .fpk 安装包（私有仓库需认证，浏览器无法直接下载） ───
  // 前端「完整安装」按钮打开此 URL → 浏览器下载 fpk → 用户在 fnOS 应用中心手动安装/覆盖。
  // 注意：完整安装不再在服务端自动替换文件（旧 /api/app/update/full 已移除），文件级替换请走「热更新」按钮。
  if (path === "/api/app/update/fpk") {
    try {
      const pat = getGitHubPAT();
      const ghHeaders = { "Accept": "application/vnd.github+json", "User-Agent": "fnos-hermes-agent" };
      if (pat) ghHeaders["Authorization"] = `Bearer ${pat}`;
      const relRes = await fetch(`https://api.github.com/repos/${GITHUB_REPO}/releases/latest`, {
        signal: AbortSignal.timeout(15000), headers: ghHeaders,
      });
      if (!relRes.ok) throw new Error(`GitHub API ${relRes.status}`);
      const relData = await relRes.json();
      const fpkAsset = (relData.assets || []).find(a => /\.fpk$/i.test(a.name || ""));
      if (!fpkAsset) {
        return new Response(JSON.stringify({ ok: false, error: "该版本 Release 没有 .fpk 安装包，请到 GitHub 发布页下载" }), { status: 404, headers: jsonHeaders() });
      }
      const dlHeaders = { "Accept": "application/octet-stream", "User-Agent": "fnos-hermes-agent" };
      if (pat) dlHeaders["Authorization"] = `Bearer ${pat}`;
      const fileRes = await fetch(fpkAsset.url, { signal: AbortSignal.timeout(300000), headers: dlHeaders });
      if (!fileRes.ok) throw new Error(`安装包下载失败: HTTP ${fileRes.status}`);
      const buf = Buffer.from(await fileRes.arrayBuffer());
      log(`[完整安装] 中转下载 fpk 安装包: ${fpkAsset.name} (${(buf.length / 1024 / 1024).toFixed(1)} MB)`);
      return new Response(buf, {
        headers: {
          "Content-Type": "application/octet-stream",
          "Content-Disposition": `attachment; filename="${fpkAsset.name}"`,
          "Content-Length": String(buf.length),
        },
      });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message || String(e) }), { status: 502, headers: jsonHeaders() });
    }
  }
  
  if (path === "/api/start" && req.method === "POST") {
    const configured=await panelModels.execute({action:'read'});
    if(!configured.ok||!configured.hermes_configured)return new Response(JSON.stringify({ok:false,error:configured.error||'请先设置默认服务和模型'}),{status:400,headers:jsonHeaders()});
    gwManualStop = false;  // 人工启动：恢复自愈
    const r1 = spawnHermes("gateway",   PID_GATEWAY,   ["gateway", "run", "--replace"]);
    const r2 = spawnHermes("dashboard", PID_DASHBOARD, ["dashboard", "--host", DASHBOARD_BIND, "--port", String(DASHBOARD_PORT), "--no-open", "--insecure"]);
    return new Response(JSON.stringify({ gateway: r1, dashboard: r2 }), { headers: jsonHeaders() });
  }

  if (path === "/api/stop" && req.method === "POST") {
    gwManualStop=true;clearTimeout(gwRespawnTimer);gwRespawnTimer=null;
    const gwAlive = readPid(PID_GATEWAY);
    const dbAlive = readPid(PID_DASHBOARD);
    await stopPid(PID_GATEWAY);
    await stopPid(PID_DASHBOARD);
    resetGatewayCrashLoop();
    gwManualStop = true;   // 人工停止：禁止自愈重拉
    if (gwAlive) log("Gateway stopped (pid=" + gwAlive + ")");
    if (dbAlive) log("Dashboard stopped (pid=" + dbAlive + ")");
    if (!gwAlive && !dbAlive) log("Stop: no running processes");
    return new Response(JSON.stringify({ ok: true }), { headers: jsonHeaders() });
  }

  if(path==='/api/restart')return handleRestartIngress(req,path);

  // Dashboard 独立启停
  if (path === "/api/dashboard/start" && req.method === "POST") {
    const r = spawnHermes("dashboard", PID_DASHBOARD, ["dashboard", "--host", DASHBOARD_BIND, "--port", String(DASHBOARD_PORT), "--no-open", "--insecure"]);
    return new Response(JSON.stringify({ dashboard: r }), { headers: jsonHeaders() });
  }

  if (path === "/api/dashboard/stop" && req.method === "POST") {
    const dbAlive = readPid(PID_DASHBOARD);
    await stopPid(PID_DASHBOARD);
    if (dbAlive) log("Dashboard stopped (pid=" + dbAlive + ")");
    return new Response(JSON.stringify({ ok: true }), { headers: jsonHeaders() });
  }

  if (path === "/api/logs") {
    const offsetParam = url.searchParams.get("offset");
    const lastOffset = offsetParam !== null ? parseInt(offsetParam, 10) : -1;
    return new Response(createLogStream(req, isNaN(lastOffset) ? -1 : lastOffset), {
      headers: {
        "Content-Type":  "text/event-stream",
        "Cache-Control": "no-cache",
        "Connection":    "keep-alive",
        "Access-Control-Allow-Origin": corsOrigin,
      },
    });
  }

  if (path === "/api/logs/history") {
    let lines = [];
    let fileSize = 0;
    try {
      if (existsSync(LOG_FILE)) {
        fileSize = statSync(LOG_FILE).size;
        lines = readFileSync(LOG_FILE, "utf8").split("\n").filter(l => l.trim()).slice(-100);
      }
    } catch {}
    return new Response(JSON.stringify({ lines, fileSize }), { headers: jsonHeaders() });
  }

  // ─── 读取任意日志文件 ────────────────────────────────────────────────
  if (path === "/api/logs/read") {
    const file = url.searchParams.get("file") || "";
    const allowed = [
      "gateway.log","errors.log","agent.log","gui.log",
      "gateway-restart.log","gateway-shutdown-diag.log","gateway-exit-diag.log","hermes.log",
    ];
    if (!allowed.includes(file)) {
      return new Response(JSON.stringify({ error: "disallowed" }), { headers: jsonHeaders() });
    }
    const fp = file === "hermes.log" ? `${VAR_DIR}/${file}` : `${DATA_DIR}/logs/${file}`;
    const rawLines = url.searchParams.get("lines") || "200";
    const limit = Math.min(Math.max(parseInt(rawLines, 10) || 200, 10), 2000);
    let lines = [], size = 0;
    try {
      if (existsSync(fp)) {
        size = statSync(fp).size;
        lines = readFileSync(fp, "utf8").split("\n").filter(l => l.trim()).slice(-limit);
      }
    } catch {}
    return new Response(JSON.stringify({ lines, size, limit }), { headers: jsonHeaders() });
  }

  // ─── 清空（截断）日志文件 ──────────────────────────────────────────────
  if (path === "/api/logs/clear" && req.method === "POST") {
    let body = {};
    try { body = await req.json(); } catch {}
    const file = body.file || "hermes.log";
    const allowed = [
      "gateway.log","errors.log","agent.log","gui.log",
      "gateway-restart.log","gateway-shutdown-diag.log","gateway-exit-diag.log","hermes.log",
    ];
    if (!allowed.includes(file)) {
      return new Response(JSON.stringify({ error: "disallowed" }), { headers: jsonHeaders() });
    }
    try{return new Response(JSON.stringify(panelLogClear.clear(file)),{headers:jsonHeaders()});}
    catch(e){return new Response(JSON.stringify({error:e.message,undo_id:e.undo_id||null}),{status:e.status||500,headers:jsonHeaders()});}
  }

  if(path==="/api/logs/clear/undo"&&req.method==="GET")return new Response(JSON.stringify({items:panelLogClear.pending()}),{headers:jsonHeaders()});

  if (path === "/api/logs/restore" && req.method === "POST") {
    let body={};try{body=await req.json();}catch{}
    try{return new Response(JSON.stringify(panelLogClear.restore(body.id)),{headers:jsonHeaders()});}
    catch(e){return new Response(JSON.stringify({error:e.message}),{status:e.status||500,headers:jsonHeaders()});}
  }

  // ─── Profiles（多 Agent）API ─────────────────────────────────────────────
  // 与 Hermes 官方 profiles 系统完全对齐（参考 hermesagent.org.cn/docs/user-guide/profiles）
  // 每个 profile 是完全隔离的 Hermes 环境：独立 config.yaml、.env、SOUL.md、记忆、会话、技能、网关
  // 通过 `hermes profile create/use/delete` CLI 管理，profile 目录 = DATA_DIR/profiles/<name>/
  const PROFILES_DIR = `${DATA_DIR}/profiles`;

  // ── 辅助：从 config.yaml 提取模型名（支持三种格式，避免 \s 跨行吞嵌套键名）──
  // 1) hermes config set model.model 写入: "model:\n  model: deepseek-v4-flash"
  // 2) hermes 0.20 主配置: "model:\n  provider: xxx\n  default: sensenova-6.7-flash-lite"
  // 3) 旧版单行: "model: deepseek-v4-flash"
  function _extractConfigModel(cfg) {
    const block = cfg.match(/^model:[ \t]*\n((?:[ \t]+[^\n]*\n?)+)/m);
    if (block) {
      const inner = block[1];
      const dm = inner.match(/^[ \t]+default:[ \t]*(\S.*)$/m);
      if (dm) return dm[1].trim();
      const nm = inner.match(/^[ \t]+model:[ \t]*(\S.*)$/m);
      if (nm) return nm[1].trim();
    }
    const single = cfg.match(/^model:[ \t]*(\S.*)$/m);
    if (single) return single[1].trim();
    return "";
  }

  // ── 辅助：读取某个 profile 目录的详细信息 ──
  function _readProfileInfo(dir, id) {
    let soul = ""; try { soul = readFileSync(`${dir}/SOUL.md`, "utf8"); } catch {}
    let model = "";
    let provider = "";
    try {
      const cfg = readFileSync(`${dir}/config.yaml`, "utf8");
      model = _extractConfigModel(cfg);
      provider = (cfg.match(/^\s*provider:\s*(.+)$/m) || [])[1] || "";
    } catch {}
    // 读取 .env 中的 API 密钥（仅检测是否配置，不暴露完整密钥）
    let hasApiKey = false;
    let envKeys = [];
    try {
      const envContent = readFileSync(`${dir}/.env`, "utf8");
      envContent.split("\n").forEach(line => {
        const s = line.trim();
        if (!s || s.startsWith("#")) return;
        const idx = s.indexOf("=");
        if (idx < 0) return;
        const key = s.slice(0, idx).trim();
        if (key) envKeys.push(key);
        if (/API_KEY|TOKEN|SECRET/i.test(key) && s.slice(idx + 1).trim()) hasApiKey = true;
      });
    } catch {}
    // 检测技能目录
    let skills = [];
    try {
      const skillsDir = `${dir}/skills`;
      if (existsSync(skillsDir)) {
        skills = readdirSync(skillsDir).filter(s => {
          try { return statSync(`${skillsDir}/${s}`).isDirectory(); } catch { return false; }
        });
      }
    } catch {}
    // UI 元数据（emoji、显示名等，由 WEBUI 写入）
    let meta = {}; try { meta = JSON.parse(readFileSync(`${dir}/metadata.json`, "utf8")); } catch {}
    return {
      id,
      name: meta.name || id,
      emoji: meta.emoji || "🤖",
      prompt: soul.slice(0, 800),
      model: (model || meta.model || "").trim(),
      provider: (provider || "").trim(),
      has_api_key: hasApiKey,
      env_keys: envKeys,
      skills,
      scene: meta.scene || "通用",
      quick_prompts: Array.isArray(meta.quick_prompts) ? meta.quick_prompts : [],
      is_default: false,
    };
  }

  function _listProfiles() {
    const profiles = [];
    // 默认 profile（主目录 DATA_DIR 本身 = ~/.hermes）
    let defaultSoul = ""; try { defaultSoul = readFileSync(`${DATA_DIR}/SOUL.md`, "utf8"); } catch {}
    const mainCfg = _readHermesConfig();
    const mainModel = _extractConfigModel(mainCfg) || (mainCfg.match(/^\s*default:\s*(.+)$/m) || [])[1] || "";
    let defaultSkills = [];
    try {
      const sd = `${DATA_DIR}/skills`;
      if (existsSync(sd)) defaultSkills = readdirSync(sd).filter(s => { try { return statSync(`${sd}/${s}`).isDirectory(); } catch { return false; } });
    } catch {}
    profiles.push({
      id: "default",
      name: "默认助手",
      emoji: "🤖",
      prompt: defaultSoul.slice(0, 800),
      model: mainModel.trim(),
      provider: "",
      has_api_key: true,
      env_keys: [],
      skills: defaultSkills,
      scene: "通用",
      quick_prompts: [],
      is_default: true,
      is_active: _getActiveProfile() === "default",
    });
    // 扫描 profiles 子目录（每个都是 hermes profile create 创建的完整环境）
    try {
      if (!existsSync(PROFILES_DIR)) mkdirSync(PROFILES_DIR, { recursive: true });
      const dirs = readdirSync(PROFILES_DIR).filter(d => {
        try { return statSync(`${PROFILES_DIR}/${d}`).isDirectory(); } catch { return false; }
      });
      const activeProfile = _getActiveProfile();
      dirs.forEach(d => {
        const info = _readProfileInfo(`${PROFILES_DIR}/${d}`, d);
        info.is_active = activeProfile === d;
        profiles.push(info);
      });
    } catch {}
    return profiles;
  }

  // ── 活跃 profile 检测：优先使用 hermes profile list 解析，兜底 .active_profile 文件 ──
  // 注意：CLI 每次 spawn 拉起 venv Python（页面加载 /api/profiles 的瓶颈），
  // 因此结果做内存缓存（_activeProfileCache 声明在模块级）；_setActiveProfile 时同步更新，避免陈旧。
  function _getActiveProfile() {
    if (_activeProfileCache) return _activeProfileCache;
    // 方式1：解析 hermes profile list 输出（活跃 profile 带 ◆ 前缀）
    // 实际格式: " ◆default         sensenova-6.7-flash-lite     running      —            —"
    // 注意：必须注入 HERMES_HOME=DATA_DIR，否则 hermes 找 $HOME/.hermes 解析为空 → 面板 GET 读错 store
    try {
      const r = spawnSync(HERMES_BIN, ["profile", "list"], { stdout: "pipe", stderr: "pipe", timeout: 8000, env: { ...process.env, HERMES_HOME: DATA_DIR } });
      const out = (r.stdout || "").toString();
      if (r.status === 0 && out.trim()) {
        const lines = out.split("\n");
        for (const line of lines) {
          const trimmed = line.trim();
          // 跳过表头和分隔线
          if (!trimmed || trimmed.startsWith("Profile") || trimmed.startsWith("─") || trimmed.startsWith("-")) continue;
          // ◆ 标记 = 当前活跃 profile（可能无空格直接连接名称）
          if (trimmed.includes("◆")) {
            const name = trimmed.replace(/^[\s◆]+/, "").trim().split(/\s+/)[0];
            if (name) { _activeProfileCache = name; return name; }
          }
          // 兼容其他可能的标记格式: "* coder" 或 "→ coder" 或 "(active)"
          if (/^[\*→>]\s+/.test(trimmed) || /\(active\)|\(current\)/.test(trimmed)) {
            const name = trimmed.replace(/^[\*→>]\s+/, "").replace(/\s*\(active\)|\s*\(current\)/, "").trim().split(/\s+/)[0];
            if (name && name !== "Profile") { _activeProfileCache = name; return name; }
          }
        }
        // 有输出但没找到标记，默认 default
        _activeProfileCache = "default";
        return "default";
      }
    } catch {}
    // 方式2：兜底读取本地记录文件
    try { _activeProfileCache = readFileSync(`${DATA_DIR}/.active_profile`, "utf8").trim(); return _activeProfileCache; } catch { return "default"; }
  }

  // ── 确保 profile 具备模型配置：目标 config.yaml 缺失/无有效 model 块时，
  // 从「当前活跃 profile → default」继承 model/providers 块与 .env 密钥。
  // 背景：从专家模板创建的空 profile（hermes profile create 不带 clone）没有 config.yaml，
  // 网关激活后报 "No inference provider configured"，聊天空回复显示误导性的
  // 「(Gateway 连接失败)」（v0.21.44 修复）。在 _setActiveProfile 入口调用，覆盖所有激活路径。
  function _ensureProfileModel(id) {
    try {
      const dir = id === "default" ? DATA_DIR : `${PROFILES_DIR}/${id}`;
      const cfgPath = `${dir}/config.yaml`;
      let cfg = ""; try { cfg = readFileSync(cfgPath, "utf8"); } catch {}
      if (_extractConfigModel(cfg)) return { ok: true, inherited: false };
      // 候选源：当前活跃 profile（排除自身）→ default
      const candidates = [];
      try {
        const active = _getActiveProfile();
        if (active && active !== id) candidates.push(active);
      } catch {}
      if (!candidates.includes("default")) candidates.push("default");
      let srcCfg = "", srcDir = "";
      for (const c of candidates) {
        const d = c === "default" ? DATA_DIR : `${PROFILES_DIR}/${c}`;
        try { srcCfg = readFileSync(`${d}/config.yaml`, "utf8"); } catch { continue; }
        if (_extractConfigModel(srcCfg)) { srcDir = d; break; }
        srcCfg = "";
      }
      if (!srcCfg) {
        log(`[profiles] ${id} 缺少模型配置且无可用源 profile，跳过继承`);
        return { ok: false, error: "no source model config" };
      }
      const modelBlock = (srcCfg.match(/^model:[ \t]*\n(?:[ \t]+[^\n]*\n?)+/m) || [""])[0];
      const providersBlock = (srcCfg.match(/^providers:[ \t]*\n(?:[ \t]+[^\n]*\n?)+/m) || [""])[0];
      let out = cfg;
      // 替换或追加 model 块（兼容空 model: / model: null 骨架）
      if (/^model:[ \t]*\n/m.test(out)) {
        out = out.replace(/^model:[ \t]*\n(?:[ \t]+[^\n]*\n?)*/m, modelBlock);
      } else if (/^model:[ \t]*\S[^\n]*$/m.test(out)) {
        out = out.replace(/^model:[ \t]*\S[^\n]*$/m, modelBlock.replace(/\n$/, ""));
      } else {
        if (out && !out.endsWith("\n")) out += "\n";
        out += modelBlock + "\n";
      }
      if (providersBlock) {
        if (/^providers:[ \t]*\n/m.test(out)) {
          out = out.replace(/^providers:[ \t]*\n(?:[ \t]+[^\n]*\n?)*/m, providersBlock);
        } else if (/^providers:[ \t]*\S[^\n]*$/m.test(out)) {
          out = out.replace(/^providers:[ \t]*\S[^\n]*$/m, providersBlock.replace(/\n$/, ""));
        } else {
          if (!out.endsWith("\n")) out += "\n";
          out += providersBlock + "\n";
        }
      }
      if (!out.endsWith("\n")) out += "\n";
      writeFileSync(cfgPath, out);
      // 合并 .env：源中目标缺失的密钥补入（如 CUSTOM_*_API_KEY）
      try {
        const srcEnv = readFileSync(`${srcDir}/.env`, "utf8");
        let dstEnv = ""; try { dstEnv = readFileSync(`${dir}/.env`, "utf8"); } catch {}
        const have = new Set(dstEnv.split("\n").map(l => { const i = l.indexOf("="); return i > 0 ? l.slice(0, i).trim() : ""; }).filter(Boolean));
        const add = [];
        srcEnv.split("\n").forEach(l => {
          const i = l.indexOf("=");
          if (i <= 0) return;
          const k = l.slice(0, i).trim();
          if (k && !have.has(k)) add.push(l);
        });
        if (add.length) {
          dstEnv = dstEnv.replace(/\s*$/, "") + (dstEnv.trim() ? "\n" : "") + add.join("\n") + "\n";
          writeFileSync(`${dir}/.env`, dstEnv);
        }
      } catch {}
      log(`[profiles] ${id} 已继承模型配置（源=${srcDir}）`);
      return { ok: true, inherited: true };
    } catch (e) {
      log(`[profiles] ${id} 继承模型配置异常: ${e.message}`);
      return { ok: false, error: e.message };
    }
  }

  function _setActiveProfile(id) {
    // 激活前确保 profile 具备模型配置（空 profile 继承当前活跃/default 的 model/providers/密钥）
    try { _ensureProfileModel(id); } catch {}
    // 使用官方 CLI 切换（设置 sticky default，后续 hermes 命令都指向该 profile）
    try {
      const r = spawnSync(HERMES_BIN, ["profile", "use", id], { stdout: "pipe", stderr: "pipe", timeout: 10000 });
      if (r.status === 0) {
        log(`[profiles] hermes profile use ${id} 成功`);
      } else {
        const err = (r.stderr || "").toString().trim();
        log(`[profiles] hermes profile use ${id} 失败: ${err}`);
      }
    } catch (e) {
      log(`[profiles] hermes profile use 异常: ${e.message}`);
    }
    // 同时写入本地记录文件（供 CLI 不可用时兜底）
    try { writeFileSync(`${DATA_DIR}/.active_profile`, id || "default"); } catch {}
    _activeProfileCache = id || "default";  // 同步内存缓存，避免陈旧
  }

  function _createProfile(id, body) {
    const dir = `${PROFILES_DIR}/${id}`;
    if (existsSync(dir)) return { ok: false, error: "profile '" + id + "' 已存在" };
    // 使用官方 CLI 创建（会生成完整环境：config.yaml、.env、SOUL.md、skills/、命令别名等）
    const args = ["profile", "create", id];
    if (body.clone) args.push("--clone");
    if (body.clone_all) args.push("--clone-all");
    if (body.clone_from) args.push("--clone-from", body.clone_from);
    try {
      const r = spawnSync(HERMES_BIN, args, { stdout: "pipe", stderr: "pipe", timeout: 30000 });
      const out = (r.stdout || "").toString().trim();
      const err = (r.stderr || "").toString().trim();
      if (r.status !== 0) {
        log(`[profiles] hermes profile create ${id} 失败: ${err || out}`);
        // CLI 失败时兜底：手动创建基础目录结构
        mkdirSync(dir, { recursive: true });
        writeFileSync(`${dir}/SOUL.md`, body.prompt || `# ${body.name || id}\n你是一个名为 ${body.name || id} 的 AI 助手。\n`);
        writeFileSync(`${dir}/config.yaml`, body.model ? `model:\n  default: ${body.model}\n` : "");
        writeFileSync(`${dir}/.env`, "");
      } else {
        log(`[profiles] hermes profile create ${id} 成功`);
        // CLI 创建成功后，覆盖/追加用户自定义内容
        if (body.prompt) writeFileSync(`${dir}/SOUL.md`, body.prompt);
        if (body.model) {
          // 追加模型配置到 config.yaml
          let cfg = ""; try { cfg = readFileSync(`${dir}/config.yaml`, "utf8"); } catch {}
          if (!cfg.includes("default:")) {
            cfg += `\nmodel:\n  default: ${body.model}\n`;
            writeFileSync(`${dir}/config.yaml`, cfg);
          }
        }
      }
    } catch (e) {
      log(`[profiles] hermes profile create 异常: ${e.message}，使用兜底创建`);
      mkdirSync(dir, { recursive: true });
      writeFileSync(`${dir}/SOUL.md`, body.prompt || `# ${body.name || id}\n`);
      writeFileSync(`${dir}/config.yaml`, body.model ? `model:\n  default: ${body.model}\n` : "");
      writeFileSync(`${dir}/.env`, "");
    }
    // v0.21.145：clone 复制来的 .env 可能带上主实例的平台通道凭据（WEIXIN_*/TELEGRAM_* 等），
    // 子 profile 也持有通道配置 → 多实例抢连同一微信/QQ 账号（通道重复对话的根因之一）。
    // 创建后统一剥离平台通道凭据，仅保留 LLM API 密钥类。
    try {
      const envFile = `${dir}/.env`;
      if (existsSync(envFile)) {
        const txt = readFileSync(envFile, "utf8");
        const CHANNEL_PREFIXES = ["WEIXIN_", "TELEGRAM_", "QQ_", "DINGTALK_", "FEISHU_", "WECOM_", "SLACK_", "DISCORD_", "WHATSAPP_", "MATRIX_", "YUANBAO_", "SIGNAL_", "GOOGLE_CHAT_", "WECHAT_"];
        const kept = txt.split("\n").filter(l => {
          const k = String(l).split("=")[0].trim();
          return !k || !CHANNEL_PREFIXES.some(p => k.startsWith(p));
        }).join("\n");
        if (kept.trim() !== txt.trim()) writeFileSync(envFile, kept);
        log(`[profiles] ${id} 已剥离平台通道凭据（仅保留 LLM API 密钥）`);
      }
    } catch (e) {}
    // 写入 UI 元数据（emoji、显示名等，Hermes CLI 不管理这些）
    const meta = { name: body.name || id, emoji: body.emoji || "🤖", created_at: Date.now() };
    if (body.scene) meta.scene = String(body.scene).trim();
    if (Array.isArray(body.quick_prompts) && body.quick_prompts.length) {
      meta.quick_prompts = body.quick_prompts.filter(s => typeof s === "string" && s.trim()).slice(0, 12);
    }
    writeFileSync(`${dir}/metadata.json`, JSON.stringify(meta, null, 2));
    return { ok: true, id };
  }

  // 将技能 id 列表写入 profile 的 config.yaml skills 块（替换旧块或追加；default 写主配置）
  function _writeProfileSkills(id, skills) {
    const cfgPath = id === "default" ? `${DATA_DIR}/config.yaml` : `${PROFILES_DIR}/${id}/config.yaml`;
    if (!existsSync(cfgPath)) return;
    let cfg = ""; try { cfg = readFileSync(cfgPath, "utf8"); } catch { return; }
    const list = Array.isArray(skills) ? skills.filter(s => typeof s === "string" && s.trim()) : [];
    if (!list.length) return; // 空数组 = 不动（避免误清）
    const skillsYaml = list.map(s => "  - " + s.trim()).join("\n") + "\n";
    if (/^skills:[ \t]*\n/m.test(cfg)) cfg = cfg.replace(/^skills:[ \t]*\n(?:[ \t].*\n?)*/m, "skills:\n" + skillsYaml);
    else cfg = cfg.replace(/\n*$/, "\n") + "skills:\n" + skillsYaml;
    writeFileSync(cfgPath, cfg);
    log(`[profiles] ${id} skills 已更新: ${list.join(", ")}`);
  }

  // 模型名 → hermes 内置 provider id（仅收录 auth.py ProviderConfig 确认存在的 id；无匹配返回 null 保留现有 provider）。
  // 注：模型名含 ":" 或 "/"（如 ollama 的 deepseek-v4-flash:0731）视为自定义模型，不联动内置 provider。
  function _modelProviderId(model) {
    const m = String(model || "").toLowerCase();
    if (m.includes(":") || m.includes("/")) return null;
    const rules = [
      [/^deepseek/, "deepseek"], [/^qwen/, "alibaba"], [/^kimi/, "kimi-coding"],
      [/^minimax/, "minimax"], [/^claude/, "anthropic"], [/^gemini/, "gemini"],
      [/^grok/, "xai"],
    ];
    for (const [re, id] of rules) if (re.test(m)) return id;
    return null;
  }

  // 在 config.yaml 的 providers: 段内查找 default_model 与目标模型精确匹配的 provider id
  //（覆盖 ollama/custom 等用户自建 provider，如 249 的 custom_umsalmjwyizjv），无匹配返回 null。
  function _providerForModel(yml, model) {
    if (!yml || !model) return null;
    const lines = yml.split("\n");
    let inProv = false, curId = null;
    for (const l of lines) {
      if (/^providers:[ \t]*$/.test(l)) { inProv = true; continue; }
      if (inProv) {
        if (/^[a-zA-Z_]/.test(l)) break; // providers 段结束（下一顶层键）
        const m = l.match(/^  ([a-zA-Z_][\w-]*):/);
        if (m) { curId = m[1]; continue; }
        if (curId) {
          const dm = l.match(/default_model:[ \t]*(\S+)/);
          if (dm && dm[1] === model) return curId;
        }
      }
    }
    return null;
  }

  // 块级文本编辑 config.yaml 的 model 块：替换/新增 default 与 provider 行，
  // 清除 0.19 遗留的嵌套 "model: xxx" 键（hermes 0.20 不识别该格式），无 model 块时追加。
  // 不调 hermes config set：0.20 的 config set 会写 0.19 旧格式或产生空键骨架。
  function _setModelInConfig(yml, model, providerId) {
    const lines = yml.split("\n");
    let idx = -1;
    for (let i = 0; i < lines.length; i++) { if (/^model:[ \t]*$/.test(lines[i])) { idx = i; break; } }
    if (idx < 0) {
      const add = "model:\n" + (providerId ? `  provider: ${providerId}\n` : "") + `  default: ${model}\n`;
      return (yml ? yml.replace(/\n?$/, "\n") : "") + add;
    }
    let end = idx + 1;
    while (end < lines.length && /^[ \t]/.test(lines[end])) end++;
    const out = [lines[idx]];
    let hasDefault = false, hasProvider = false;
    for (let i = idx + 1; i < end; i++) {
      const l = lines[i];
      if (/^[ \t]+default:/.test(l)) { out.push(l.replace(/^([ \t]+default:).*$/, `$1 ${model}`)); hasDefault = true; }
      else if (providerId && /^[ \t]+provider:/.test(l)) { out.push(l.replace(/^([ \t]+provider:).*$/, `$1 ${providerId}`)); hasProvider = true; }
      else if (/^[ \t]+model:/.test(l)) { /* 0.19 遗留嵌套 model 键：清除 */ }
      else out.push(l);
    }
    if (providerId && !hasProvider) out.push(`  provider: ${providerId}`);
    if (!hasDefault) out.push(`  default: ${model}`);
    return lines.slice(0, idx).concat(out, lines.slice(end)).join("\n");
  }

  function _updateProfile(id, body) {
    if (id === "default") {
      // 默认 profile：更新主目录下的 SOUL.md / config.yaml
      if (body.prompt != null) writeFileSync(`${DATA_DIR}/SOUL.md`, body.prompt);
      if (body.skills != null && Array.isArray(body.skills)) _writeProfileSkills("default", body.skills);
      if (body.model) {
        // 纯文本块级编辑 model 块（hermes config set 在 0.20 会写 0.19 旧嵌套键 model.model
        // 或产生空键骨架，弃用）；provider 推断：providers 段 default_model 匹配优先，其次内置前缀
        try {
          let yml = readFileSync(HERMES_CONFIG, "utf8");
          const pid = _providerForModel(yml, body.model) || _modelProviderId(body.model);
          yml = _setModelInConfig(yml, body.model, pid);
          writeFileSync(HERMES_CONFIG, yml, { mode: 0o644 });
        } catch (e) { log(`[profiles] 更新主配置模型失败: ${e.message}`); }
      }
      return { ok: true };
    }
    const dir = `${PROFILES_DIR}/${id}`;
    if (!existsSync(dir)) return { ok: false, error: "profile not found" };
    // 更新 SOUL.md（个性/指令）
    if (body.prompt != null) writeFileSync(`${dir}/SOUL.md`, body.prompt);
    // 更新模型配置（纯文本块级编辑，见 _setModelInConfig 注释）
    if (body.model) {
      try {
        let yml = readFileSync(`${dir}/config.yaml`, "utf8");
        const pid = _providerForModel(yml, body.model) || _modelProviderId(body.model);
        yml = _setModelInConfig(yml, body.model, pid);
        writeFileSync(`${dir}/config.yaml`, yml);
      } catch (e) { log(`[profiles] 更新 ${id} 模型失败: ${e.message}`); }
    }
    // 更新 .env（API 密钥等）
    if (body.env && typeof body.env === "object") {
      let envContent = ""; try { envContent = readFileSync(`${dir}/.env`, "utf8"); } catch {}
      const envLines = envContent.split("\n");
      const envMap = {};
      envLines.forEach(line => {
        const s = line.trim();
        if (!s || s.startsWith("#")) return;
        const idx = s.indexOf("=");
        if (idx > 0) envMap[s.slice(0, idx).trim()] = s.slice(idx + 1).trim();
      });
      Object.keys(body.env).forEach(k => { if (body.env[k] != null) envMap[k] = body.env[k]; });
      const newEnv = Object.keys(envMap).map(k => `${k}=${envMap[k]}`).join("\n") + "\n";
      writeFileSync(`${dir}/.env`, newEnv);
    }
    // 更新 skills（写入 config.yaml 的 skills 块；[] = 清空独立技能回到预置）
    if (body.skills != null && Array.isArray(body.skills)) {
      _writeProfileSkills(id, body.skills);
    }
    // 更新 UI 元数据
    let meta = {}; try { meta = JSON.parse(readFileSync(`${dir}/metadata.json`, "utf8")); } catch {}
    if (body.name != null) meta.name = body.name;
    if (body.emoji != null) meta.emoji = body.emoji;
    if (body.scene != null) meta.scene = String(body.scene).trim() || "通用";
    if (body.quick_prompts != null) {
      meta.quick_prompts = Array.isArray(body.quick_prompts)
        ? body.quick_prompts.filter(s => typeof s === "string" && s.trim()).slice(0, 12)
        : [];
    }
    meta.updated_at = Date.now();
    writeFileSync(`${dir}/metadata.json`, JSON.stringify(meta, null, 2));
    return { ok: true };
  }

  function _deleteProfile(id) {
    if (id === "default") return { ok: false, error: "无法删除默认 profile（~/.hermes）" };
    const dir = `${PROFILES_DIR}/${id}`;
    if (!existsSync(dir)) return { ok: false, error: "profile not found" };
    // 属主修正：profile 目录可能由部署/手动操作以其他用户创建（rmSync 报 EACCES 删除失败），
    // 手动删除前先 chown 到当前用户（sudoers 已授 hermes-agent 免密 chown；无 sudo 时直 chown 兜底）
    const _fixOwn = () => {
      try {
        execSync(`sudo -n chown -R "$(id -un):$(id -gn)" "${dir}" 2>/dev/null || chown -R "$(id -un):$(id -gn)" "${dir}"`, { timeout: 10000 });
      } catch (e) { /* 忽略：chown 失败时 rmSync 仍会尝试并给出明确错误 */ }
    };
    // 使用官方 CLI 删除（会停止网关、移除 systemd 服务、删除命令别名）
    try {
      const r = spawnSync(HERMES_BIN, ["profile", "delete", id, "--yes"], { stdout: "pipe", stderr: "pipe", timeout: 15000 });
      if (r.status === 0) {
        log(`[profiles] hermes profile delete ${id} 成功`);
      } else {
        const err = (r.stderr || "").toString().trim();
        log(`[profiles] hermes profile delete ${id} CLI 失败(${err})，手动删除目录`);
        _fixOwn();
        rmSync(dir, { recursive: true, force: true });
      }
    } catch (e) {
      log(`[profiles] hermes profile delete 异常: ${e.message}，手动删除`);
      _fixOwn();
      try { rmSync(dir, { recursive: true, force: true }); } catch (e2) { return { ok: false, error: e2.message }; }
    }
    if (_getActiveProfile() === id) _setActiveProfile("default");
    return { ok: true };
  }

  // GET /api/profiles → 列出所有 profiles（与 hermes profile list 对齐）
  if (path === "/api/profiles" && req.method === "GET") {
    try {
      return new Response(JSON.stringify({ ok: true, profiles: _listProfiles(), active: _getActiveProfile() }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // Compatibility route shares the versioned expert store.
  const expertEditMatch = path.match(/^\/api\/experts\/([a-zA-Z0-9_-]+)$/);
  if (expertEditMatch && req.method === "PUT") {
    try { return new Response(JSON.stringify({ok:true,expert:saveExpert(expertEditMatch[1],await req.json())}),{headers:jsonHeaders()}); }
    catch(error){return new Response(JSON.stringify({ok:false,error:error.message}),{status:error.status||400,headers:jsonHeaders()});}
  }

  // POST /api/profiles → 创建 profile（调用 hermes profile create）
  if (path === "/api/profiles" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      let _rawId = (body.id || body.name || "").trim();
      let id = _rawId.toLowerCase().replace(/[^a-z0-9_-]/g, "_");
      // 中文/特殊字符名会被替换成纯下划线（如「法律顾问」→「____」），
      // 会与历史遗留的下划线 profile 撞名导致「已存在」误报 → 用时间戳保证唯一
      if (!id || /^_+$/.test(id)) id = "agent_" + Date.now().toString(36);
      const r = _createProfile(id, body);
      if (r.ok && Array.isArray(body.skills) && body.skills.length) {
        try { _writeProfileSkills(id, body.skills); } catch (e) { log(`[profiles] 写入 ${id} skills 失败: ${e.message}`); }
      }
      return new Response(JSON.stringify(r), { status: r.ok ? 200 : 400, headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // PUT /api/profiles/:id → 更新 profile（SOUL.md / config / .env）
  const profileUpdateMatch = path.match(/^\/api\/profiles\/([a-zA-Z0-9_-]+)$/);
  if (profileUpdateMatch && req.method === "PUT") {
    try {
      const body = await req.json().catch(() => ({}));
      const r = _updateProfile(profileUpdateMatch[1], body);
      return new Response(JSON.stringify(r), { status: r.ok ? 200 : 404, headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // DELETE /api/profiles/:id → 删除 profile（调用 hermes profile delete）
  if (profileUpdateMatch && req.method === "DELETE") {
    try {
      const r = _deleteProfile(profileUpdateMatch[1]);
      return new Response(JSON.stringify(r), { status: r.ok ? 200 : 400, headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // POST /api/profiles/:id/activate → 切换活跃 profile（调用 hermes profile use）
  const profileActivateMatch = path.match(/^\/api\/profiles\/([a-zA-Z0-9_-]+)\/activate$/);
  if (profileActivateMatch && req.method === "POST") {
    try {
      const id = profileActivateMatch[1];
      if (id !== "default" && !existsSync(`${PROFILES_DIR}/${id}`)) {
        return new Response(JSON.stringify({ ok: false, error: "profile not found" }), { status: 404, headers: jsonHeaders() });
      }
      _setActiveProfile(id);
      // 切换 profile 后触发网关重启以加载新 profile 的配置
      _triggerGatewayRestart("profile-switch-" + id);
      return new Response(JSON.stringify({ ok: true, active: id }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // GET /api/profiles/:id/env → 读取 profile 的 .env 键值（脱敏）
  const profileEnvMatch = path.match(/^\/api\/profiles\/([a-zA-Z0-9_-]+)\/env$/);
  if (profileEnvMatch && req.method === "GET") {
    try {
      const id = profileEnvMatch[1];
      const envPath = id === "default" ? `${DATA_DIR}/.env` : `${PROFILES_DIR}/${id}/.env`;
      const envObj = {};
      try {
        const content = readFileSync(envPath, "utf8");
        content.split("\n").forEach(line => {
          const s = line.trim();
          if (!s || s.startsWith("#")) return;
          const idx = s.indexOf("=");
          if (idx < 0) return;
          const key = s.slice(0, idx).trim();
          const val = s.slice(idx + 1).trim();
          // 过滤历史脏键（如模型名 "sensenova-6.7-flash-lite"、非法字符），避免假键混入面板
          if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) return;
          // 脱敏：只显示前4位 + ***
          envObj[key] = val.length > 8 ? val.slice(0, 4) + "****" : (val ? "****" : "");
        });
      } catch {}
      return new Response(JSON.stringify({ ok: true, env: envObj }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // PUT /api/profiles/:id/env → 更新 profile 的 .env（API 密钥等），保存后重启网关生效
  // body: { env: { KEY: value } }，value 为空字符串则删除该键；不存在的键不处理
  if (profileEnvMatch && req.method === "PUT") {
    try {
      const id = profileEnvMatch[1];
      const body = await req.json().catch(() => ({}));
      const updates = body.env && typeof body.env === "object" ? body.env : {};
      // 键名 sanitize：仅接受标准环境变量名（拒绝模型名/含特殊字符的历史脏键），同时删除 .env 中已有的非法键
      const KEY_RE = /^[A-Za-z_][A-Za-z0-9_]*$/;
      const cleanUpdates = {};
      Object.keys(updates).forEach(k => { if (KEY_RE.test(k)) cleanUpdates[k] = updates[k]; });
      const keys = Object.keys(cleanUpdates);
      if (!keys.length) return new Response(JSON.stringify({ ok: false, error: "env 为空或包含非法键名" }), { status: 400, headers: jsonHeaders() });
      const envPath = id === "default" ? `${DATA_DIR}/.env` : `${PROFILES_DIR}/${id}/.env`;
      let lines = [];
      try {
        const content = readFileSync(envPath, "utf8");
        lines = content.split("\n");
      } catch {}
      const seen = new Set();
      let existed = false;
      const out = lines.map(line => {
        const s = line.trim();
        if (!s || s.startsWith("#") || s.indexOf("=") < 0) return line;
        const key = s.slice(0, s.indexOf("=")).trim();
        if (!KEY_RE.test(key)) return null; // 历史脏键 → 本次保存时清洗删除
        if (seen.has(key)) return line; // 重复键：保留首条，后续由追加逻辑处理
        seen.add(key);
        if (!(key in cleanUpdates)) return line;
        existed = true;
        const val = String(cleanUpdates[key] || "").trim();
        return val ? `${key}=${val}` : null; // 空值 → 删除该行
      }).filter(l => l !== null);
      keys.forEach(key => {
        if (seen.has(key)) return;
        const val = String(cleanUpdates[key] || "").trim();
        if (val) out.push(`${key}=${val}`);
      });
      mkdirSync(dirname(envPath), { recursive: true });
      writeFileSync(envPath, out.join("\n").replace(/\n+$/, "") + "\n");
      // 密钥变更需重启网关才生效（网关只在启动时读 .env）
      _triggerGatewayRestart("profile-env-" + id);
      return new Response(JSON.stringify({ ok: true, updated: keys, restarting: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ─── 专家：内置清单与创建 ──────────────────────────────────────────────
  // GET /api/experts?scope=builtin|market → 内置专家清单（2026-08-05 起市场已并入内置，两值同返回合并清单）
  if (path === "/api/experts" && req.method === "GET") {
    try {return new Response(JSON.stringify({ok:true,...expertCatalog({limit:400}),overrides:{}}),{headers:jsonHeaders()});}
    catch(error){return new Response(JSON.stringify({ok:false,error:error.message}),{status:error.status||503,headers:jsonHeaders()});}
  }
  // POST /api/experts/create → 内置专家模板 → profile 创建（含 skills 写入）并激活
  // body: { slug }
  if (path === "/api/experts/create" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const slug = String(body.slug || "").trim();
      const exp = BUILTIN_EXPERTS_ALL.find(e => e.slug === slug || e.id === slug);
      if (!exp) return new Response(JSON.stringify({ ok: false, error: "未找到专家模板: " + slug }), { status: 404, headers: jsonHeaders() });
      const id = (exp.slug || exp.name || "").trim().toLowerCase().replace(/[^a-z0-9_-]/g, "_");
      let r = _createProfile(id, { name: exp.name, emoji: exp.emoji, prompt: exp.prompt, scene: exp.scene, quick_prompts: exp.quick_prompts });
      if (!r.ok) {
        // 已存在 → 直接激活（不改写已有配置）
        if (String(r.error).includes("已存在")) {
          _setActiveProfile(id);
          _triggerGatewayRestart("expert-activate-" + id);
          return new Response(JSON.stringify({ ok: true, profile: { id, name: exp.name }, activated: true }), { headers: jsonHeaders() });
        }
        return new Response(JSON.stringify(r), { status: 400, headers: jsonHeaders() });
      }
      // 写入 profile 的 skills 块（hermes 技能 id 列表；替换旧块或追加）
      if (Array.isArray(exp.skills) && exp.skills.length) {
        const cfgPath = `${PROFILES_DIR}/${id}/config.yaml`;
        let cfg = ""; try { cfg = readFileSync(cfgPath, "utf8"); } catch {}
        const skillsYaml = exp.skills.map(s => "  - " + s).join("\n") + "\n";
        if (/^skills:[ \t]*\n/m.test(cfg)) cfg = cfg.replace(/^skills:[ \t]*\n(?:[ \t].*\n?)*/m, "skills:\n" + skillsYaml);
        else cfg = cfg.replace(/\n*$/, "\n") + "skills:\n" + skillsYaml;
        writeFileSync(cfgPath, cfg);
        log(`[experts] ${id} skills 已写入: ${exp.skills.join(", ")}`);
      }
      _setActiveProfile(id);
      _triggerGatewayRestart("expert-create-" + id);
      return new Response(JSON.stringify({ ok: true, profile: { id, name: exp.name } }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ─── 聊天：配置 API ──────────────────────────────────────────────────────
  // ───────────────────────────────────────────────────────────────
  // 扩展能力（LightAgent 集成）：toolsets / mcp_servers / skills / persona
  // 统一持久化到 ${VAR_DIR}/extensions.json（控制面板专属，Hermes 不解析，零风险），
  // 并同步写入 Hermes config.yaml 对应段使其真实生效。
  // ───────────────────────────────────────────────────────────────
  function _yamlScalarSafe(val){
    const s = String(val == null ? "" : val);
    const risky = s === "" ||
      /^[\s>|@`"'%#&*!?\[\]{},-]/.test(s) ||
      /\s$/.test(s) ||
      /:(\s|$)/.test(s) ||
      /\s#/.test(s);
    return risky ? JSON.stringify(s) : s;
  }

  // 通用：跳过某个顶层键之下的缩进块与列表项
  function _skipBlock(lines, i){
    while (i < lines.length &&
           (lines[i].startsWith("  ") || lines[i].startsWith("\t") ||
            /^-\s/.test(lines[i])) && lines[i].trim() !== "") {
      i++;
    }
    return i;
  }

  // 替换/新增 config.yaml 顶层「列表」块（如 toolsets:）
  // 通过 _setTopLevelBlock 写入：兼容 inline 与 block 形态，并清除重复顶层键；
  // 条目自动去重（防重复累积：残留顶格项 + 新项导致 toolsets 越写越长）
  function _setYamlListBlock(content, key, items){
    const uniq = [];
    const seen = new Set();
    (items || []).forEach(it => { const s = String(it).trim(); if (s && !seen.has(s)) { seen.add(s); uniq.push(s); } });
    const block = `${key}:\n` + uniq.map(it => `  - ${_yamlScalarSafe(it)}`).join("\n");
    return _setTopLevelBlock(content, key, block);
  }

  // 替换/新增 config.yaml 顶层「映射」块（如 mcp_servers:）
  // 通过 _setTopLevelBlock 写入：兼容 inline（key: {}）与 block 形态，并清除重复顶层键
  // 支持嵌套 map（如 env: {KEY: value}），不再序列化为 [object Object]
  function _setYamlMapBlock(content, key, obj){
    let block;
    const names = Object.keys(obj);
    if (names.length === 0) {
      block = `${key}: {}`;
    } else {
      block = `${key}:\n`;
      names.forEach(name => {
        block += `  ${_yamlScalarSafe(name)}:\n`;
        const entry = obj[name] || {};
        Object.entries(entry).forEach(([k, v]) => {
          if (Array.isArray(v)){
            block += `    ${k}:\n` + v.map(x => `      - ${_yamlScalarSafe(x)}`).join("\n") + "\n";
          } else if (v && typeof v === "object"){
            // 嵌套 map（env: {KEY: value} 等）：逐键序列化，避免 [object Object]
            block += `    ${k}:\n`;
            Object.entries(v).forEach(([k2, v2]) => {
              if (v2 !== undefined && v2 !== null && v2 !== ""){
                block += `      ${_yamlScalarSafe(k2)}: ${_yamlScalarSafe(v2)}\n`;
              }
            });
          } else if (v !== undefined && v !== null && v !== ""){
            block += `    ${k}: ${_yamlScalarSafe(v)}\n`;
          }
        });
      });
    }
    return _setTopLevelBlock(content, key, block);
  }

  // 合并 skills.external_dirs（保留 skills 段其它字段）
  function _mergeSkillsExternalDirs(content, dirs){
    const lines = content.split("\n");
    const out = [];
    let i = 0, inSkills = false, replaced = false;
    while (i < lines.length){
      const line = lines[i];
      if (line === "skills:"){ inSkills = true; out.push(line); i++; continue; }
      if (inSkills && !line.startsWith("  ") && line.trim() !== ""){
        if (!replaced){ out.push("  external_dirs:"); dirs.forEach(d => out.push("    - " + _yamlScalarSafe(d))); replaced = true; }
        inSkills = false;
        out.push(line); i++; continue;
      }
      if (inSkills && /^\s*external_dirs:/.test(line)){
        out.push("  external_dirs:");
        dirs.forEach(d => out.push("    - " + _yamlScalarSafe(d)));
        replaced = true;
        i++;
        while (i < lines.length && (lines[i].startsWith("    ") || /^\s+-\s/.test(lines[i]))) i++;
        continue;
      }
      out.push(line); i++;
    }
    if (inSkills && !replaced){ out.push("  external_dirs:"); dirs.forEach(d => out.push("    - " + _yamlScalarSafe(d))); }
    return out.join("\n");
  }

  function _readExtensionsFile(){
    try {
      const p = `${VAR_DIR}/extensions.json`;
      if (existsSync(p)) return JSON.parse(readFileSync(p, "utf8"));
    } catch (e) { throw Error('扩展配置无法读取，原文件已保留'); }
    return null;
  }
  function _writeExtensionsFile(obj){
    atomicWriteJSON(`${VAR_DIR}/extensions.json`,obj);
  }
  // 从 config.yaml 提取某个顶层块的原始文本（用于 GET 推断）
  // 兼容 block 形态（key:\n 缩进内容）与 inline 形态（key: {} / key: value）
  function _yamlBlockOf(yml, key){
    // 坑：原先写的是 ...|\\Z) —— JS 正则无 \Z（Python 语法），被当字面量 Z，
    // 惰性匹配会在块内遇到第一个大写 Z 时提前截断（zotero 的 ZOTERO_* 环境变量即中招），
    // 导致 mcp_servers 只解析出 zotero 一个。改用 (?![\s\S]) 表示「字符串真正结束」。
    const m = yml.match(new RegExp("^" + key + ":\\n([\\s\\S]*?)(?=^[a-zA-Z_]+:|(?![\\s\\S]))", "m"));
    if (m) return m[1];
    const im = yml.match(new RegExp("^" + key + ":\\s*\\{[^\\n]*\\}\\s*$", "m"));
    if (im) return "";
    const iv = yml.match(new RegExp("^" + key + ":\\s*([^\\n]*)\\s*$", "m"));
    if (iv) return iv[1] + "\n";
    return "";
  }

  // 从 config.yaml 顶层「列表」块提取条目数组（如 toolsets:）
  function _extractYamlList(content, key){
    const block = _yamlBlockOf(content, key);
    if (!block) return [];
    const out = [];
    block.split("\n").forEach(function(line){
      const m = line.match(/^\s*-\s+(.+)$/);
      if (m){
        let v = m[1].trim();
        if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
        out.push(v);
      }
    });
    return out;
  }

  // 写 / 替换 config.yaml 顶层「扁平映射」块（如 memory: 下直接是标量）
  // 通过 _setTopLevelBlock 写入：兼容 inline 与 block 形态，并清除重复顶层键
  function _setYamlFlatMap(content, key, obj){
    const items = Object.keys(obj).filter(k => obj[k] !== undefined && obj[k] !== null && obj[k] !== "");
    const block = items.length
      ? key + ":\n" + items.map(k => "  " + k + ": " + _yamlScalarSafe(obj[k])).join("\n")
      : key + ": {}";
    return _setTopLevelBlock(content, key, block);
  }

  // ── 健壮替换/删除 config.yaml 顶层块（消除重复顶层键，根因修复）──
  // newBlock 为空（falsy 或纯空白）表示「删除该顶层块」；否则整体替换为 newBlock（不含尾随换行）。
  // 同时兼容 block 形态（key: 换行缩进）与 inline 形态（key: {…} / key: value），
  // 并跳过所有重复的顶层键——重复的 model:/providers: 正是网关报
  // "No inference provider configured" 进而 Dashboard 502 的根因。
  function _isTopLevelKey(line, key) {
    if (/^\s/.test(line)) return false;          // 缩进的行不是顶层键
    if (line === key + ":") return true;
    if (line.startsWith(key + ":")) return true; // 含 inline 形态 key: value / key: {…}
    return false;
  }
  function _setTopLevelBlock(content, key, newBlock) {
    const lines = content.split("\n");
    const out = [];
    let inserted = false;
    const removeOnly = !newBlock || !String(newBlock).trim();
    let firstIdx = -1;
    for (let k = 0; k < lines.length; k++) {
      if (_isTopLevelKey(lines[k], key)) { firstIdx = k; break; }
    }
    for (let k = 0; k < lines.length; k++) {
      const line = lines[k];
      if (_isTopLevelKey(line, key)) {
        const isFirst = (k === firstIdx);
        if (isFirst && !inserted && !removeOnly) { out.push(newBlock); inserted = true; }
        // 跳过该顶层块的整段（block: 后续缩进行 + 顶格列表残留项；inline: 仅本行）
        if (line === key + ":") {
          let j = k + 1;
          // 缩进行是块的正常内容；顶格 "- item" 是历史残留的非法行（hermes 解析失败会
          // 回退默认配置导致 "No inference provider configured"），一并跳过清除
          while (j < lines.length && (lines[j].startsWith(" ") || lines[j].startsWith("\t") || /^-\s/.test(lines[j]))) j++;
          k = j - 1; // for 循环会执行 k++
        }
        continue;
      }
      out.push(line);
    }
    if (!inserted && !removeOnly) out.push(newBlock); // 无任何现存块：追加到末尾
    return out.join("\n");
  }

  function _expandHome(p){
    if (!p) return p;
    if (p === "~") return (process.env.HOME || process.env.USERPROFILE || "");
    if (p.startsWith("~/")) return (process.env.HOME || process.env.USERPROFILE || "") + p.slice(1);
    return p;
  }

  function _baseName(p){ return (p || "").split("/").filter(Boolean).pop() || ""; }
  function _dirName(p){ const a = (p || "").split("/").filter(Boolean); a.pop(); return "/" + a.join("/"); }
  function _joinPath(a, b){ return (a || "").replace(/\/$/, "") + "/" + (b || "").replace(/^\//, ""); }

  // 调用 hermes skills list --source all 解析已安装技能（Name | Category | Source | Trust | Status）
  function _listHermesSkills(){
    try {
      const r = spawnSync(HERMES_BIN, ["skills", "list", "--source", "all"], {
        stdout: "pipe", stderr: "pipe",
        env: { ...process.env, HOME: DATA_DIR, HERMES_HOME: DATA_DIR }
      });
      const out = (r.stdout ? r.stdout.toString() : "") || (r.stderr ? r.stderr.toString() : "");
      const skills = [];
      out.split("\n").forEach(line => {
        const parts = line.split("│").map(s => s.trim()).filter(Boolean);
        if (parts.length < 5) return;
        const name = parts[0], category = parts[1], source = parts[2], trust = parts[3], status = parts[4];
        if (name === "Name" || source === "Source" || !name || !source) return;
        skills.push({ name, category, source, trust, status });
      });
      return skills;
    } catch (e) { return []; }
  }

  // ── 平台频道配置读写（~/.hermes/.env + ~/.hermes/config.yaml）──
  function _readEnvFile(){
    return channelRW.active?channelRW.read('env'):envRW.read();
  }
  function _writeEnvFile(content){
    if(channelRW.active)channelRW.write('env',content);else envRW.write(content);return true;
  }
  function _getEnvValue(content,key){return envValue(content,key);}
  function _setEnvValue(content,key,value){return setEnvValue(content,key,String(value??""));}
  // 原有凭证只读兼容；面板修改保存在 VAR，读取失败不回退为空。
  function _readConnectorsState(){ return panelConnectorStore.all(); }
  // 解析现有 mcp_servers 顶层映射块为 { name: {url, headers:{...}, env:{...}} }
  // 支持嵌套 map（headers/env 子块）与列表（args），自适应子块类型
  function _parseMcpServers(yml){
    const block = _yamlBlockOf(yml, "mcp_servers");
    const obj = {};
    if (!block.trim()) return obj;
    const lines = block.split("\n");
    let curName = null, curEntry = null, inMap = null;
    for (const line of lines){
      // 顶层条目（2 空格缩进 name:）
      const nm = line.match(/^  ([A-Za-z0-9_-]+):\s*$/);
      if (nm){
        if (curName) obj[curName] = curEntry;
        curName = nm[1]; curEntry = {}; inMap = null; continue;
      }
      // 4 空格 key:（条目字段；v 为空 → 子块，暂存 null 由后续行确定类型）
      const sk = line.match(/^    ([A-Za-z0-9_-]+):\s*(.*)$/);
      if (sk && curName && curEntry){
        const k = sk[1];
        let v = sk[2].trim();
        inMap = null;
        if (v === ""){ curEntry[k] = null; inMap = k; }
        else {
          // 去除引号包裹（与 _yamlScalarSafe 相反）
          if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
          curEntry[k] = v;
        }
        continue;
      }
      // 6 空格 key: value（子 map 成员：headers/env 等）
      const hk = line.match(/^      ([A-Za-z0-9_-]+):\s*(.*)$/);
      if (hk && curEntry && inMap){
        if (curEntry[inMap] === null || curEntry[inMap] === undefined) curEntry[inMap] = {};
        else if (Array.isArray(curEntry[inMap])) curEntry[inMap] = {};
        let hv = hk[2].trim();
        if ((hv.startsWith('"') && hv.endsWith('"')) || (hv.startsWith("'") && hv.endsWith("'"))) hv = hv.slice(1, -1);
        curEntry[inMap][hk[1]] = hv;
        continue;
      }
      // 6 空格 - item（子列表成员：args 等）
      const li = line.match(/^      -\s*(.*)$/);
      if (li && curEntry && inMap){
        if (curEntry[inMap] === null || curEntry[inMap] === undefined) curEntry[inMap] = [];
        else if (!Array.isArray(curEntry[inMap])) curEntry[inMap] = [];
        let val = li[1].trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) val = val.slice(1, -1);
        curEntry[inMap].push(val);
        continue;
      }
    }
    if (curName) obj[curName] = curEntry;
    return obj;
  }
  // 合并写入 mcp_servers（保留用户其它条目，仅增/改/删本连接器对应项）
  function _upsertMcpServer(name, entry){
    const result=configTransaction({python:join(VENV_BIN,PY_BIN),serverRoot:join(APP_DIR,'server'),state:join(VAR_DIR,'panel-state'),file:_runtimeConfigPath(),
      body:{action:'mcp_entry',name,entry,reason:'修改MCP服务 '+name}});
    return result;
  }
  function _readHermesConfig(){return channelRW.active?channelRW.read('yaml'):configRW.read();}
  function _writeHermesConfig(content){if(channelRW.active)channelRW.write('yaml',content);else configRW.write(content);return true;}
  // ── YAML 标量安全引用（保留 token 中的 : # 等字符）──
  function _yamlQuote(v){
    if (v === true) return "true";
    if (v === false) return "false";
    if (v === null || v === undefined) return '""';
    const s = String(v);
    if (s === "") return '""';
    if (/[:#\[\]{}&*!|>'"%@`,]/.test(s) || /^\s|\s$/.test(s) || /[\n\r\t]/.test(s)) {
      return '"' + s.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"';
    }
    return s;
  }
  function _yamlUnquote(s){
    if (s === "true") return true;
    if (s === "false") return false;
    if (s === "null" || s === "~" || s === "") return null;
    if ((s[0] === '"' && s[s.length-1] === '"') || (s[0] === "'" && s[s.length-1] === "'")) {
      return s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\");
    }
    return s;
  }
  function _objToYaml(obj, spaces){
    const pad = " ".repeat(spaces);
    let out = "";
    for (const k of Object.keys(obj)) {
      const v = obj[k];
      if (v === undefined || v === null) continue;
      if (typeof v === "object" && !Array.isArray(v)) {
        out += pad + k + ":\n" + _objToYaml(v, spaces + 2);
      } else if (Array.isArray(v)) {
        out += pad + k + (v.length ? ":\n" + v.map(x => pad + "  - " + _yamlQuote(x) + "\n").join("") : ": []\n");
      } else {
        out += pad + k + ": " + _yamlQuote(v) + "\n";
      }
    }
    return out;
  }
  function _setValByPath(obj, path, val){
    const parts = path.split(".");
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) { const p = parts[i]; cur[p] = (cur[p] && typeof cur[p] === "object") ? cur[p] : {}; cur = cur[p]; }
    cur[parts[parts.length - 1]] = val;
  }
  function _getValByPath(obj, path){
    const parts = path.split("."); let cur = obj;
    for (const p of parts) { if (cur == null || typeof cur !== "object") return undefined; cur = cur[p]; }
    return cur;
  }
  // 读取 config.yaml 中 platforms.<id> 下的嵌套键值（支持任意缩进深度）
  function _runtimeConfigPath(){
    try {
      const ap = readFileSync(`${DATA_DIR}/.active_profile`, "utf8").trim();
      const pp = `${DATA_DIR}/profiles/${ap}/config.yaml`;
      if (ap && /^[A-Za-z0-9_-]{1,100}$/.test(ap) && existsSync(pp)) return pp;
    } catch (e) {}
    return HERMES_CONFIG;
  }
  function _readPlatformConfig(id){
    let yml = "";
    try { yml = readFileSync(_runtimeConfigPath(), "utf8"); } catch (e) {}
    const lines = yml.split("\n");
    // 1. 找到 platforms: 段
    let platHeader = -1;
    for (let i = 0; i < lines.length; i++) { if (/^platforms:\s*$/.test(lines[i])) { platHeader = i; break; } }
    if (platHeader < 0) return {};
    // 2. 在 platforms 下找到目标 id 块
    const escaped = id.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const blockRe = new RegExp("^  " + escaped + ":\\s*(.*)$");
    let blockStart = -1, inlineVal = "";
    for (let i = platHeader + 1; i < lines.length; i++) {
      if (/^[a-zA-Z_]/.test(lines[i])) break; // 顶层键 → platforms 段结束
      const m = lines[i].match(blockRe);
      if (m) { blockStart = i; inlineVal = m[1].trim(); break; }
    }
    if (blockStart < 0) return {};
    if (inlineVal && inlineVal !== "{}") return _yamlUnquote(inlineVal); // 内联值
    // 3. 收集该块所有子行（缩进 >= 4 空格），遇到下一个 2 空格平台键或顶层键则停止
    const childLines = [];
    for (let i = blockStart + 1; i < lines.length; i++) {
      const l = lines[i];
      if (l.trim() === "") continue; // 跳过空行
      if (/^[a-zA-Z_]/.test(l)) break; // 顶层键
      if (/^  [a-zA-Z_]/.test(l)) break; // 下一个平台键
      if (/^    /.test(l)) childLines.push(l); // 4+ 空格缩进 → 属于此块
    }
    if (childLines.length === 0) return {};
    // 4. 按缩进层级递归解析为嵌套对象
    return _parseIndentBlock(childLines, 4);
  }
  // 解析一组按缩进排列的 YAML 行为嵌套对象（支持任意深度）
  function _parseIndentBlock(lines, baseIndent){
    const obj = {};
    const pad = " ".repeat(baseIndent);
    let i = 0;
    while (i < lines.length) {
      const l = lines[i];
      if (!l.startsWith(pad)) { i++; continue; } // 缩进不足，跳过
      // 检查是否正好是 baseIndent 级别的键
      const afterPad = l.slice(baseIndent);
      if (afterPad.startsWith(" ")) { i++; continue; } // 更深层，不属于当前级别
      const kvMatch = afterPad.match(/^([a-zA-Z_][\w-]*):\s*(.*)$/);
      if (!kvMatch) { i++; continue; }
      const key = kvMatch[1], val = kvMatch[2].trim();
      if (val && val !== "|" && val !== ">") {
        // 叶子键值
        if (val.startsWith("[") && val.endsWith("]")) {
          // 内联数组 [a, b, c]
          obj[key] = val.slice(1, -1).split(",").map(s => _yamlUnquote(s.trim())).filter(s => s !== "");
        } else {
          obj[key] = _yamlUnquote(val);
        }
        i++;
      } else {
        // 子块：收集更深缩进的行
        i++;
        const subLines = [];
        while (i < lines.length) {
          const sl = lines[i];
          if (sl.trim() === "") { i++; continue; }
          if (sl.startsWith(pad + "  ")) { subLines.push(sl); i++; } // 更深缩进
          else break;
        }
        if (subLines.length > 0) {
          // 检测子块是列表还是映射
          const firstSub = subLines.find(s => s.trim() !== "");
          if (firstSub && /^ *- /.test(firstSub.slice(baseIndent + 2))) {
            // YAML 列表
            obj[key] = subLines
              .filter(s => s.trim().startsWith("- "))
              .map(s => _yamlUnquote(s.trim().slice(2).trim()));
          } else {
            obj[key] = _parseIndentBlock(subLines, baseIndent + 2);
          }
        } else {
          obj[key] = val === "|" || val === ">" ? "" : (val === "" ? {} : _yamlUnquote(val));
        }
      }
    }
    return obj;
  }
  function _setPlatformConfig(id, obj){
    const block = "  " + id + ":\n" + _objToYaml(obj, 4);
    let yml = _readHermesConfig();
    if (!/^platforms:/m.test(yml)) {
      yml = (yml ? yml.replace(/\n?$/, "\n") : "") + "platforms:\n" + block;
      return yml;
    }
    // 定位 platforms: 段，按行解析各平台块，仅重建该段（保留其它顶层配置）
    const lines = yml.split("\n");
    let header = -1;
    for (let i = 0; i < lines.length; i++) { if (/^platforms:\s*$/.test(lines[i])) { header = i; break; } }
    if (header < 0) { yml = yml.replace(/\n?$/, "\n") + "platforms:\n" + block; return yml; }
    // 记录每个 2 空格平台块的 [起始行, 结束行]，并保留出现顺序
    const order = [];
    const blocks = {};
    let curId = null, curStart = null, suffixStart = lines.length;
    for (let i = header + 1; i < lines.length; i++) {
      const l = lines[i];
      if (/^[a-zA-Z_]/.test(l)) { // 顶层键 → platforms 段结束，记录后缀起点
        if (curId !== null) blocks[curId].e = i - 1;
        suffixStart = i;
        break;
      }
      const mm = l.match(/^  ([a-zA-Z_][\w-]*):/);
      if (mm) {
        if (curId !== null) blocks[curId].e = i - 1;
        curId = mm[1]; curStart = i;
        if (!blocks[curId]) { blocks[curId] = { s: i, e: i }; if (order[order.length - 1] !== curId) order.push(curId); }
      } else if (curId !== null) {
        blocks[curId].e = i;
      }
    }
    if (curId !== null && suffixStart === lines.length) blocks[curId].e = lines.length - 1; // 段延伸到文件末尾
    const newLines = [];
    for (let i = 0; i <= header; i++) newLines.push(lines[i]);
    let wroteTarget = false;
    order.forEach(pid => {
      if (pid === id) { newLines.push(block.replace(/\n$/, "")); wroteTarget = true; }
      else { for (let i = blocks[pid].s; i <= blocks[pid].e; i++) newLines.push(lines[i]); }
    });
    if (!wroteTarget) newLines.push(block.replace(/\n$/, ""));
    for (let i = suffixStart; i < lines.length; i++) newLines.push(lines[i]); // 保留 platforms 段之后的其它顶层配置
    return newLines.join("\n") + "\n";
  }

  // ─── 通讯平台 QR 扫码登录辅助函数 ────────────────────────────────────────
  function _findHermesRoot(){
    try {
      const pyResult = spawnSync(
        `${VENV_BIN}/${PY_BIN}`, ["-c", "import hermes_cli,os;print(os.path.dirname(os.path.dirname(hermes_cli.__file__)))"],
        { stdout: "pipe", stderr: "pipe" }
      );
      const root = (pyResult.stdout ? pyResult.stdout.toString() : "").trim();
      if (root && existsSync(`${root}/hermes_cli`)) return root;
    } catch {}
    return null;
  }
  function _findWhatsAppBridgeDir(){
    const root = _findHermesRoot();
    if (root && existsSync(`${root}/scripts/whatsapp-bridge/bridge.js`)) return `${root}/scripts/whatsapp-bridge`;
    return null;
  }
  function _findNpmBin(){
    if (!resolvedNodeBin) return null;
    const nodeDir = resolvedNodeBin.replace(/[\\/][^\\/]+$/, "");
    const checked = [];
    // 1) 与 node 同目录的可执行 npm（Linux/macOS 官方发行版）
    const siblingNpm = nodeDir + "/npm";
    checked.push(siblingNpm);
    if (existsSync(siblingNpm)) return { npm: siblingNpm, isScript: false, node: resolvedNodeBin };
    // Windows 开发环境：npm.cmd / npm.ps1
    if (process.platform === "win32") {
      const baseDir = nodeDir.replace(/[\\/]node$/, "");
      const siblingNpmCmd = baseDir + "/npm.cmd";
      checked.push(siblingNpmCmd);
      if (existsSync(siblingNpmCmd)) return { npm: siblingNpmCmd, isScript: false, node: resolvedNodeBin };
      const siblingNpmPs1 = baseDir + "/npm.ps1";
      checked.push(siblingNpmPs1);
      if (existsSync(siblingNpmPs1)) return { npm: siblingNpmPs1, isScript: false, node: resolvedNodeBin };
    }
    // 2) Node.js 发行版自带的 npm-cli.js（最可靠 fallback，很多打包环境只放 node，不放 npm 可执行文件）
    const npmCliScript = resolvePath(nodeDir, "..", "lib", "node_modules", "npm", "bin", "npm-cli.js");
    checked.push(npmCliScript);
    if (existsSync(npmCliScript)) return { npm: npmCliScript, isScript: true, node: resolvedNodeBin };
    // 3) PATH 中的 npm
    try {
      const r = spawnSync("sh", ["-c", "command -v npm"], { stdout: "pipe", stderr: "pipe" });
      const out = (r.stdout || "").toString().trim();
      if (out && existsSync(out)) return { npm: out, isScript: false, node: resolvedNodeBin };
    } catch {}
    // 4) 常见绝对路径
    const NPM_CANDIDATES = [
      "/var/apps/nodejs_v24/target/bin/npm",
      "/var/apps/nodejs_v22/target/bin/npm",
      "/var/apps/nodejs_v20/target/bin/npm",
      "/var/apps/nodejs/target/bin/npm",
      "/usr/local/bin/npm",
      "/usr/bin/npm",
      "/opt/bin/npm"
    ];
    for (const p of NPM_CANDIDATES) {
      checked.push(p);
      if (existsSync(p)) return { npm: p, isScript: false, node: resolvedNodeBin };
    }
    log(`[whatsapp] npm not found; resolvedNodeBin=${resolvedNodeBin}; checked=${checked.join(", ")}`);
    return null;
  }
  function _ensureWhatsAppBridgeDeps(bridgeDir){
    if (existsSync(`${bridgeDir}/node_modules`)) return true;
    if (!resolvedNodeBin) throw new Error("未找到 Node.js，无法启动 WhatsApp bridge");
    const npmInfo = _findNpmBin();
    if (!npmInfo) {
      throw new Error("npm was not found. WhatsApp setup needs Node.js and npm. (node路径: " + (resolvedNodeBin || "null") + ")");
    }
    try {
      const env = { ...process.env, PATH: (resolvedNodeDir ? resolvedNodeDir + ":" : "") + (process.env.PATH || "") };
      const args = ["install", "--silent"];
      const result = npmInfo.isScript
        ? spawnSync(npmInfo.node, [npmInfo.npm, ...args], { cwd: bridgeDir, env, stdout: "pipe", stderr: "pipe", timeout: 300000 })
        : spawnSync(npmInfo.npm, args, { cwd: bridgeDir, env, stdout: "pipe", stderr: "pipe", timeout: 300000 });
      if (result.exitCode !== 0){
        const err = (result.stderr || "").toString().trim() || "npm install 返回非零退出码";
        throw new Error("安装 WhatsApp bridge 依赖失败：" + err);
      }
      return true;
    } catch (e) {
      if (e && e.message) throw e;
      throw new Error("安装 WhatsApp bridge 依赖失败，请检查网络");
    }
  }
  function _spawnWhatsAppPairing(sessionDir, mode){
    const bridgeDir = _findWhatsAppBridgeDir();
    if (!bridgeDir) throw new Error("未找到 WhatsApp bridge 脚本，请确认 hermes-agent 已正确安装");
    if (!resolvedNodeBin) throw new Error("未找到 Node.js，无法启动 WhatsApp bridge");
    if (!_ensureWhatsAppBridgeDeps(bridgeDir)) throw new Error("安装 WhatsApp bridge 依赖失败，请检查网络");
    try { mkdirSync(sessionDir, { recursive: true }); } catch {}
    const env = { ...process.env, WHATSAPP_MODE: mode || "self-chat", WHATSAPP_DM_POLICY: "pairing" };
    return spawn(
      resolvedNodeBin,
      [`${bridgeDir}/bridge.js`, "--pair-only", "--pair-json", "--session", sessionDir],
      { cwd: bridgeDir, stdio: ["ignore", "pipe", "pipe"], env }
    );
  }
  function _terminateProc(proc){
    if (!proc) return;
    try { if (proc.pid) process.kill(proc.pid, "SIGTERM"); } catch {}
    try { proc.kill(); } catch {}
  }
  function _watchWhatsAppPairing(pairing_id, proc){
    if (!proc || !proc.stdout) return;
    try {
      const reader = proc.stdout ? Readable.toWeb(proc.stdout).getReader() : null;
      if (!reader) return;
      const decoder = new TextDecoder();
      let buf = "";
      const processChunk = async () => {
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            buf += decoder.decode(value, { stream: true });
            const lines = buf.split("\n");
            buf = lines.pop();
            for (const raw of lines) {
              const line = raw.trim(); if (!line) continue;
              try {
                const payload = JSON.parse(line);
                const event = String(payload.event || "").trim();
                const rec = _whatsappPairings.get(pairing_id);
                if (!rec || rec.proc !== proc) return;
                if (event === "qr") {
                  const qr = String(payload.qr || "").trim();
                  if (qr) { rec.qr_payload = qr; rec.status = "waiting"; rec.error = null; }
                } else if (event === "connected") {
                  const user = payload.user || {};
                  rec.account_id = String(user.id || "").trim() || null;
                  rec.account_name = String(user.name || "").trim() || null;
                  rec.account_phone = rec.account_id ? rec.account_id.replace(/[^0-9]/g, "").replace(/^\d+?:(\d+)@s\.whatsapp\.net$/, "$1") : null;
                  rec.status = "connected"; rec.error = null;
                } else if (event === "error") {
                  rec.status = "error"; rec.error = String(payload.error || "WhatsApp 配对失败");
                }
              } catch {}
            }
          }
        } catch {}
        // 进程结束处理
        try { await new Promise((resolve) => proc.on("exit", resolve)); } catch {}
        const rec = _whatsappPairings.get(pairing_id);
        if (!rec || rec.proc !== proc) return;
        if (!["connected", "error", "expired", "cancelled"].includes(rec.status)) {
          rec.status = "error"; rec.error = "WhatsApp 配对进程意外退出";
        }
      };
      processChunk();
    } catch {}
  }
  function _pruneTelegramPairings(){
    const now = Date.now();
    for (const [id, rec] of _telegramPairings) { if (rec.expires_at_ts <= now) _telegramPairings.delete(id); }
  }
  function _pruneWhatsAppPairings(){
    const now = Date.now();
    const terminal = {"connected":1,"error":1,"expired":1,"cancelled":1};
    for (const [id, rec] of _whatsappPairings) {
      if (!terminal[rec.status] && rec.expires_at_ts <= now) {
        rec.status = "expired"; rec.error = "二维码已过期，请重新配对";
        _terminateProc(rec.proc);
      }
      if (terminal[rec.status] && rec.expires_at_ts + 300000 <= now) _whatsappPairings.delete(id);
    }
  }
  function _normalizeTelegramUserId(value){
    const s = String(value || "").trim();
    if (/^\d+$/.test(s)) return s;
    return null;
  }
  function _normalizeWhatsAppAllowedUsers(value){
    const s = String(value || "").trim();
    if (!s) return "";
    const parts = s.split(/[,;\s]+/).map(x => x.trim()).filter(Boolean);
    const out = [];
    for (const p of parts) {
      if (p === "*") { out.push("*"); continue; }
      const digits = p.replace(/\D/g, "");
      if (digits) out.push(digits);
    }
    return out.join(",");
  }

  // 通道绑定角色 → 顶层 profile_routes 同步（行级编辑，保留其余 YAML 原样）
  // hermes 0.20：multiplex_profiles: true + profile_routes 列表（name/platform/profile），
  // 平台级 route 匹配该平台全部消息。绑定 profile 必须已存在（UI 绑定列表来自 /api/profiles）。
  function _syncChannelProfileRoute(yml, id, profile){
    const routeName = "channel-" + id;
    // 1) 确保 multiplex_profiles: true
    if (/^multiplex_profiles:/m.test(yml)) {
      yml = yml.replace(/^multiplex_profiles:.*$/m, "multiplex_profiles: true");
    } else {
      yml = (yml ? yml.replace(/\n?$/, "\n") : "") + "multiplex_profiles: true\n";
    }
    const lines = yml.split("\n");
    let blockStart = -1;
    for (let i = 0; i < lines.length; i++) { if (/^profile_routes:\s*$/.test(lines[i])) { blockStart = i; break; } }
    const routeLine = "  - name: " + routeName;
    if (profile) {
      const entryLines = [routeLine, "    platform: " + id, "    profile: " + profile];
      if (blockStart < 0) {
        // 无 profile_routes 块 → 追加
        return yml.replace(/\n?$/, "\n") + "profile_routes:\n" + entryLines.join("\n") + "\n";
      }
      // 块存在：定位块尾（顶层键 / 2 空格列表项之外）
      let blockEnd = lines.length;
      for (let i = blockStart + 1; i < lines.length; i++) { if (/^[a-zA-Z_]/.test(lines[i])) { blockEnd = i; break; } }
      // 找现有同名条目（- name: channel-<id>）
      let found = -1;
      for (let i = blockStart + 1; i < blockEnd; i++) { if (lines[i].includes(routeLine)) { found = i; break; } }
      if (found >= 0) {
        let j = found + 1;
        while (j < blockEnd && !/^  - /.test(lines[j])) j++;
        lines.splice(found, j - found, ...entryLines);
        return lines.join("\n");
      }
      lines.splice(blockEnd, 0, ...entryLines);
      return lines.join("\n");
    }
    // 解除绑定：删除同名条目
    if (blockStart >= 0) {
      let found = -1;
      for (let i = blockStart + 1; i < lines.length; i++) {
        if (lines[i].includes(routeLine)) { found = i; break; }
        if (/^[a-zA-Z_]/.test(lines[i])) break;
      }
      if (found >= 0) {
        let j = found + 1;
        while (j < lines.length && !/^  - /.test(lines[j]) && !/^[a-zA-Z_]/.test(lines[j])) j++;
        lines.splice(found, j - found);
        return lines.join("\n");
      }
    }
    return yml;
  }

  function _toggleChannel(id, enabled){
    const cfg = _readPlatformConfig(id);
    cfg.enabled = !!enabled;
    cfg.updated_at = Date.now();
    let yml = _setPlatformConfig(id, cfg);
    _writeHermesConfig(yml);
    log(`[channel] ${id} 已${enabled ? "启用" : "禁用"}（platforms.${id}.enabled=${enabled}），重启网关生效`);
    _triggerGatewayRestart(`channel ${id} ${enabled ? "enable" : "disable"}`);
    return { ok: true, id, enabled: !!enabled };
  }
  function _listChannels(){
    const env = _readEnvFile();
    const out = {};
    Object.keys(CHANNEL_DEFS).forEach(id => {
      const def = CHANNEL_DEFS[id];
      const cfg = _readPlatformConfig(id);
      let configured = false;
      (def.fields || []).forEach(f => { if (f.env && _getEnvValue(env, f.env)) configured = true; });
      if (id === "whatsapp" && (_getEnvValue(env, "WHATSAPP_ENABLED") || cfg.enabled === "true" || cfg.enabled === true)) configured = true;
      if (id === "weixin") configured = !!_getEnvValue(env, "WEIXIN_TOKEN");
      out[id] = {
        id, name: def.name, icon: def.icon, configured, qrLogin: !!def.qrLogin, note: def.note || "",
        enabled: (cfg && cfg.enabled !== false),
        last_configured_at: (cfg && cfg.updated_at) ? cfg.updated_at : null,
        credentials: (def.fields || []).filter(f => f.env).map(f => ({ env: f.env, path: f.path, label: f.label, value: _getEnvValue(env, f.env) || "" })),
        config: cfg
      };
    });
    return out;
  }
  function _saveChannel(id,body){return channelRW.run(()=>_saveChannelChanges(id,body));}
function _saveChannelChanges(id, body){
    const def = CHANNEL_DEFS[id]; if (!def) return { ok: false, error: "unknown channel" };
    let env = _readEnvFile();
    const cfg = _readPlatformConfig(id);
    // 凭证字段：写 .env + 写 platforms.<id>.<path>
    (def.fields || []).forEach(f => {
      if (!f.env) return;
      const v = (body.credentials && body.credentials[f.env] != null) ? body.credentials[f.env]
              : (body.config && _getValByPath(body.config, f.path) != null ? _getValByPath(body.config, f.path) : null);
      if (v == null) return;
      env = _setEnvValue(env, f.env, v || "");
      if (f.path) _setValByPath(cfg, f.path, v || "");
    });
    _writeEnvFile(env);
    // 行为开关
    if (body.toggles && typeof body.toggles === "object") {
      Object.keys(body.toggles).forEach(p => { const v = body.toggles[p]; if (v != null) _setValByPath(cfg, p, v); });
    }
    // 其余 config（非凭证字段）兜底写入
    if (body.config && typeof body.config === "object") {
      Object.keys(body.config).forEach(p => {
        if ((def.fields || []).some(f => f.path === p)) return;
        const v = body.config[p]; if (v != null) _setValByPath(cfg, p, v);
      });
    }
    // qqbot：默认开启群消息（open），否则群里 @ 不回复
    if (id === "qqbot") {
      if (!_getValByPath(cfg, "extra.group_policy")) _setValByPath(cfg, "extra.group_policy", "open");
      if (!_getValByPath(cfg, "extra.dm_policy")) _setValByPath(cfg, "extra.dm_policy", "open");
    }
    // 确保 skills 始终为数组（YAML {} 会解析为空对象，导致前端 indexOf 崩溃）
    if (cfg.skills != null && !Array.isArray(cfg.skills)) {
      if (typeof cfg.skills === "object") cfg.skills = Object.keys(cfg.skills);
      else cfg.skills = [];
    }
    // 通道级模型/系统提示：网关只认 channel_overrides[chat_id]（platforms.<id>.model 会被忽略），
    // 保存时同步到该平台全部已知 chat_id（新增会话由 _syncChannelOverrides 定时补齐）
    const chModel = (body.config && body.config.model != null) ? String(body.config.model).trim() : "";
    const chSysPrompt = (body.config && body.config.system_prompt != null) ? String(body.config.system_prompt).trim() : "";
    if (chModel || chSysPrompt) {
      const chatIds = _gatewayChatIds(id);
      if (chatIds.length) {
        const ov = (cfg.channel_overrides && typeof cfg.channel_overrides === "object") ? cfg.channel_overrides : {};
        chatIds.forEach(cid => {
          const cur = (ov[cid] && typeof ov[cid] === "object") ? ov[cid] : {};
          if (chModel) cur.model = chModel; else delete cur.model;
          if (chSysPrompt) cur.system_prompt = chSysPrompt; else delete cur.system_prompt;
          if (Object.keys(cur).length) ov[cid] = cur; else delete ov[cid];
        });
        cfg.channel_overrides = ov;
        log(`[ChannelOverride] 通道 ${id} 保存：模型覆盖已应用到 ${chatIds.length} 个会话`);
      }
    } else if (cfg.channel_overrides && typeof cfg.channel_overrides === "object") {
      // 用户清空模型/系统提示（跟随角色）→ 移除本功能写入的 model/system_prompt
      const ov = cfg.channel_overrides;
      Object.keys(ov).forEach(cid => {
        if (ov[cid] && typeof ov[cid] === "object") {
          delete ov[cid].model;
          delete ov[cid].system_prompt;
          if (!Object.keys(ov[cid]).length) delete ov[cid];
        }
      });
      if (!Object.keys(ov).length) delete cfg.channel_overrides;
      log(`[ChannelOverride] 通道 ${id}：用户清空模型/系统提示，已移除覆盖`);
    }
    // wecom 群聊策略兜底：hermes 0.20 wecom 适配器默认 group_policy=pairing，
    // 群聊消息一律被 _is_group_allowed 拒绝（仅 debug 日志，无任何回复）。
    // 保存通道配置时若未显式设置，强制 open（所有群可收发），否则用户拉 bot 进群永远没反应。
    if (id === "wecom" && _getValByPath(cfg, "extra.group_policy") == null) {
      _setValByPath(cfg, "extra.group_policy", "open");
      log(`[ChannelPolicy] wecom 群聊策略未配置，已兜底为 open（允许群消息）`);
    }
    cfg.updated_at = Date.now();
    let yml = _setPlatformConfig(id, cfg);
    // 通道绑定角色 → 顶层 profile_routes 同步（multiplex 路由）
    // hermes 0.20 网关不读 platforms.<id>.profile 字段（官方 dashboard 的落盘字段），
    // 只有顶层 profile_routes 生效：multiplex_profiles: true 时平台消息按路由绑定 profile 运行。
    if (id === "wecom" || id === "weixin") {
      const boundP = (cfg.profile != null && String(cfg.profile).trim() !== "") ? String(cfg.profile).trim() : null;
      yml = _syncChannelProfileRoute(yml, id, boundP);
      log(boundP ? `[ChannelRoute] 通道 ${id} 绑定角色 ${boundP} → profile_routes 已同步`
                 : `[ChannelRoute] 通道 ${id} 未绑定角色，profile_routes 对应条目已清理`);
    }
    _writeHermesConfig(yml);
    // ── 自动启用通道对应的 hermes 插件 toolset ───────────────────────────
    // wecom / dingtalk / feishu 等是 hermes 插件平台，必须在 config.yaml 的
    // toolsets 里列出对应条目（如 hermes-wecom）网关才会在启动时加载该插件。
    // 用户保存通道配置时自动补上，避免「配置了却不连」的困惑。
    const _PLUGIN_TOOLSET = {
      wecom: "hermes-wecom", wecom_callback: "hermes-wecom-callback",
      dingtalk: "hermes-dingtalk", feishu: "hermes-feishu",
      telegram: "hermes-telegram", discord: "hermes-discord",
      slack: "hermes-slack", matrix: "hermes-matrix",
      signal: "hermes-signal", qqbot: "hermes-qqbot",
      whatsapp: "hermes-whatsapp", email: "hermes-email",
      homeassistant: "hermes-homeassistant", mattermost: "hermes-mattermost",
    };
    if (_PLUGIN_TOOLSET[id]) {
      try {
        const needed = _PLUGIN_TOOLSET[id];
        let y2 = _readHermesConfig();
        const curTs = _extractYamlList(y2, "toolsets");
        if (!curTs.includes(needed)) {
          curTs.push(needed);
          y2 = _setYamlListBlock(y2, "toolsets", curTs);
          _writeHermesConfig(y2);
          log(`[ChannelToolset] 自动启用 ${needed}（通道 ${id} 需要此插件）`);
        }
      } catch (e) { log(`[ChannelToolset] 启用 ${_PLUGIN_TOOLSET[id]} 失败: ${e.message}`); }
    }
    return { ok: true };
  }

  // ── 通道「测试」按钮后端（对齐 Octop probe_channel：真实连接验证凭证）────────────────
  // wecom 用 wss 握手、weixin 用 iLink getconfig（只读零副作用）、telegram 用 getMe，
  // 其余无在线探测协议的渠道做必填凭证齐全检查。
  function _testChannel(id, body){
    const def = CHANNEL_DEFS[id]; if (!def) return { ok: false, error: "unknown channel" };
    const env = _readEnvFile();
    const cred = (body && body.credentials) || {};
    const saved = envKey => _getEnvValue(env, envKey);
    if (id === "wecom") {
      const botId = String(cred.WECOM_BOT_ID || saved("WECOM_BOT_ID") || "").trim();
      const secret = String(cred.WECOM_SECRET || saved("WECOM_SECRET") || "").trim();
      if (!botId || !secret) return { ok: false, error: "请先填写或扫码获取 Bot ID / Secret 再测试" };
      return _testWecom(botId, secret);
    }
    if (id === "weixin") {
      const token = String(cred.WEIXIN_TOKEN || saved("WEIXIN_TOKEN") || "").trim();
      const accountId = String(cred.WEIXIN_ACCOUNT_ID || saved("WEIXIN_ACCOUNT_ID") || "").trim();
      const baseUrl = String(cred.WEIXIN_BASE_URL || saved("WEIXIN_BASE_URL") || "https://ilinkai.weixin.qq.com").trim();
      if (!token) return { ok: false, error: "请先填写或扫码获取 Token 再测试" };
      return _testWeixin(token, accountId, baseUrl);
    }
    if (id === "telegram") {
      const t = String(cred.TELEGRAM_BOT_TOKEN || saved("TELEGRAM_BOT_TOKEN") || "").trim();
      if (!t) return { ok: false, error: "请先填写 Bot Token 再测试" };
      return _testTelegram(t);
    }
    // 其余渠道：必填凭证齐全检查（label 含「(可选)/（可选）」的跳过）
    const required = (def.fields || []).filter(f => f.env && !/\(可选\)|（可选）/.test(f.label));
    const missing = required.map(f => (cred[f.env] || saved(f.env)) ? null : f.label).filter(Boolean);
    if (missing.length) return { ok: false, error: "缺少必填凭证：" + missing.join("、") + "，请填写后再测试" };
    const hasAny = (def.fields || []).some(f => f.env && (cred[f.env] || saved(f.env)));
    if (!hasAny) return { ok: false, error: "尚未配置任何凭证，请先填写" };
    return { ok: true, message: "凭据已保存完整，网关重启后生效（该渠道无在线探测接口）" };
  }

  // 企微「AI 智能机器人」wss 握手验证（vendored ws 库，协议对齐 hermes adapter 源码：
  // 订阅 cmd=aibot_subscribe（非 subscribe）、回包按 headers.req_id 匹配、跳过 ping 心跳、
  // errcode==0/缺失即凭证有效，错误字段为 errmsg。实测假凭证返回 errcode=853000）。
  // device_id 每次随机生成，测试不会踢掉真实连接（与 hermes adapter 行为一致）。
  // 注意：不可用 Node 内置全局 WebSocket——undici 在 NAS Node 24 上 #onSocketClose TypeError
  // （本机与 NAS 实测连 wss 均失败）；monitor 的 WS 服务同款 ws 库握手实测通过。
  function _testWecom(botId, secret) {
    return new Promise(resolve => {
      let done = false;
      let ws = null;
      let timer = null;
      const finish = r => {
        if (done) return; done = true;
        if (timer) clearTimeout(timer);
        try { if (ws) ws.close(); } catch {}
        resolve(r);
      };
      try { ws = new WebSocket("wss://openws.work.weixin.qq.com"); }
      catch (e) { return resolve({ ok: false, error: "无法建立 WebSocket：" + e.message }); }
      timer = setTimeout(() => finish({ ok: false, error: "连接超时（12 秒），请检查网络后重试" }), 12000);
      const reqId = "probe-" + Date.now() + "-" + Math.random().toString(16).slice(2, 10);
      ws.on("open", () => {
        try {
          ws.send(JSON.stringify({
            cmd: "aibot_subscribe",
            headers: { req_id: reqId },
            body: { bot_id: botId, secret: secret, device_id: Math.random().toString(16).slice(2, 18) }
          }));
        } catch (e) { finish({ ok: false, error: "发送握手请求失败：" + e.message }); }
      });
      ws.on("message", data => {
        let msg = null;
        try { msg = JSON.parse(String(data)); } catch {}
        if (!msg) return;
        if (msg.cmd === "ping") return;                              // 心跳包，忽略
        if ((msg.headers || {}).req_id !== reqId) return;            // 非本次握手的回包，忽略
        const code = msg.errcode;
        if (code === 0 || code === null || code === undefined) return finish({ ok: true, message: "企业微信凭证有效，可正常收发消息" });
        if (code === 853000) return finish({ ok: false, error: "Bot ID / Secret 无效（errcode=853000），请重新扫码授权" });
        finish({ ok: false, error: "握手失败（errcode=" + code + "）：" + (msg.errmsg || "") });
      });
      ws.on("error", e => finish({ ok: false, error: "WebSocket 连接失败：" + (e.message || "网络错误") }));
      ws.on("close", () => finish({ ok: false, error: "连接被关闭，握手未完成" }));
    });
  }

  // 从活跃 profile 的 weixin/accounts/<account_id>.context-tokens.json 提取 peer（key 形如 xxx@im.wechat）
  function _findWeixinPeer(accountId){
    try {
      const active = _getActiveProfile();
      const dir = `${DATA_DIR}/profiles/${active}/weixin/accounts`;
      if (!existsSync(dir)) return "";
      const files = readdirSync(dir).filter(f => f.endsWith(".context-tokens.json"));
      const candidates = [];
      if (accountId) candidates.push(...files.filter(f => f.startsWith(accountId)));
      candidates.push(...files);
      for (const f of candidates) {
        try {
          const d = JSON.parse(readFileSync(`${dir}/${f}`, "utf8"));
          const keys = Object.keys(d || {});
          if (keys.length) return keys[0];
        } catch {}
      }
    } catch {}
    return "";
  }

  // 微信 iLink getconfig：只读查询，校验 token 有效性（ret===-14 会话过期，ret==0/null 通过）
  async function _testWeixin(token, accountId, baseUrl){
    const base = (baseUrl || "https://ilinkai.weixin.qq.com").replace(/\/+$/, "");
    const peer = _findWeixinPeer(accountId);
    if (!peer) return { ok: false, error: "未找到微信会话凭证，请先在微信上给助手发一条消息，再回来测试" };
    const uin = Buffer.from(String(Date.now()) + Math.random()).toString("base64").replace(/=+$/, "");
    let res;
    try {
      res = await fetch(`${base}/ilink/bot/getconfig`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + token,
          "AuthorizationType": "ilink_bot_token",
          "X-WECHAT-UIN": uin,
          "iLink-App-Id": "bot",
          "iLink-App-ClientVersion": String((2 << 16) | (2 << 8) | 0),
        },
        body: JSON.stringify({ ilink_user_id: peer, base_info: { channel_version: "2.2.0" } }),
        signal: AbortSignal.timeout(15000)
      });
    } catch (e) {
      return { ok: false, error: "请求微信服务器失败：" + e.message };
    }
    const data = await res.json().catch(() => ({}));
    const ret = data.ret;
    if (ret === -14) return { ok: false, error: "登录会话已过期（ret=-14），请重新扫码登录微信" };
    if (ret === 0 || ret === "0" || ret == null) return { ok: true, message: "微信 Token 有效，可正常收发消息" };
    if (ret === -8 || ret === -16) return { ok: false, error: "Token 无效或已失效（ret=" + ret + "），请重新扫码登录" };
    return { ok: false, error: "接口返回异常（ret=" + ret + "）：" + (data.errmsg || data.msg || "") };
  }

  async function _testTelegram(token){
    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/getMe`, { signal: AbortSignal.timeout(10000) });
      const data = await res.json().catch(() => ({}));
      if (data && data.ok) return { ok: true, message: "Telegram Bot Token 有效：@" + ((data.result && data.result.username) || "") };
      return { ok: false, error: "Telegram Token 无效：" + (data.description || `getMe 返回 ${res.status}`) };
    } catch (e) {
      return { ok: false, error: "请求 Telegram 服务器失败：" + e.message };
    }
  }

  // 解析技能目录中的 SKILL.md frontmatter（name / description / emoji）
  function _readSkillFrontmatter(dir){
    try {
      const skills = [];
      const scan = (d) => {
        const sk = _joinPath(d, "SKILL.md");
        if (existsSync(sk)) skills.push(_parseSkillMd(sk, d));
        try {
          readdirSync(d).forEach(n => {
            const sub = _joinPath(d, n);
            if (_isDir(sub) && existsSync(_joinPath(sub, "SKILL.md"))) skills.push(_parseSkillMd(_joinPath(sub, "SKILL.md"), sub));
          });
        } catch (e) {}
      };
      scan(dir);
      return skills;
    } catch (e){ return []; }
  }
  function _isDir(p){ try { return statSync(p).isDirectory(); } catch (e){ return false; } }
  function _parseSkillMd(file, dir){
    const raw = readFileSync(file, "utf8");
    const m = raw.match(/^---\s*\n([\s\S]*?)\n---/);
    let name = _baseName(dir); let description = ""; let emoji = "";
    if (m){
      m[1].split("\n").forEach(l => {
        const mm = l.match(/^([a-zA-Z_]+):\s*(.*)$/);
        if (!mm) return;
        const k = mm[1].trim().toLowerCase(); const v = mm[2].trim().replace(/^["']|["']$/g, "");
        if (k === "name") name = v;
        else if (k === "description") description = v;
        else if (k === "emoji") emoji = v;
      });
    }
    return { name, description, emoji, file, dir };
  }

  // 绝对化相对 URL
  function _absUrl(u, base){
    try {
      if (/^(https?:)?\/\//i.test(u) || /^(mailto:|tel:|data:)/i.test(u)) return u;
      const bu = new URL(base);
      if (u.startsWith("//")) return bu.protocol + u;
      if (u.startsWith("/")) return bu.origin + u;
      const dir = bu.pathname.endsWith("/") ? bu.pathname : bu.pathname.replace(/\/[^\/]*$/, "/");
      return bu.origin + dir + u;
    } catch (e){ return u; }
  }

  // 净化远程 HTML 以便内嵌展示（去脚本、去内联事件、重写相对 URL）
  function _sanitizeHtmlForEmbed(html, base){
    let out = html;
    out = out.replace(/<script[\s\S]*?<\/script>/gi, "");
    out = out.replace(/<noscript[\s\S]*?<\/noscript>/gi, "");
    out = out.replace(/<meta[^>]*http-equiv\s*=\s*["']?refresh["']?[^>]*>/gi, "");
    out = out.replace(/(<(?:a|link|img|source|iframe)\b[^>]*\b)(href|src|data-src)\s*=\s*("|')([^"']*)\3/gi,
      (m, pre, attr, q, val) => {
        if (/^(javascript:|data:)/i.test(val)) return m;
        return pre + attr + "=" + q + _absUrl(val, base) + q;
      });
    out = out.replace(/\s(on\w+)\s*=\s*("|')(?:[^"']*)\2/gi, "");
    out = out.replace(/\s(on\w+)\s*=\s*[^\s>]+/gi, "");
    return out;
  }

  // 从远程 HTML 中提取技能 / 专家包链接（SkillHub / agentskills.io 风格卡片）
  function _extractSkillLinks(html, base, type){
    const items = []; const seen = {};
    // 先尝试解析 SkillHub 卡片结构：<a href="...">...<div class="...">标题</div>...描述...</a>
    const cardRe = /<a\b[^>]*\bhref\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
    let m;
    while ((m = cardRe.exec(html)) !== null){
      const href = m[1];
      const raw = m[2];
      if (!/(\/skills?\/|\/skillspackage|\/skill-package|\/skill\/)/i.test(href)) continue;
      const abs = _absUrl(href, base);
      if (seen[abs]) continue;
      seen[abs] = true;

      // 清理标签但保留换行
      let text = raw.replace(/<script[\s\S]*?<\/script>/gi, "")
                    .replace(/<style[\s\S]*?<\/style>/gi, "")
                    .replace(/<[^>]+>/g, "\n")
                    .replace(/\n+/g, "\n")
                    .trim();
      const lines = text.split("\n").map(l => l.replace(/\s+/g, " ").trim()).filter(l => l.length > 0 && l !== "SkillHub");

      // 标题：第一行非 SkillHub / 认证标记 / 分类标记的文本
      let title = "";
      let description = "";
      for (let i = 0; i < lines.length; i++) {
        const l = lines[i];
        if (!title && !/^([0-9.]+\s*万|需配置|办公效率|内容创作|知识管理|AI Agent|开发编程|IT 运维|设计|多媒体|行业专业|商业运营|{\[).*/i.test(l)) {
          title = l; continue;
        }
        if (title && !description && l !== title && l.length > 5) {
          description = l; break;
        }
      }
      if (!title) title = _baseName(abs.split("?")[0]).replace(/[-_]/g, " ");
      title = title.replace(/\.html?$/i, "").slice(0, 80);
      description = description.slice(0, 160);

      items.push({ title, description, url: abs, type: type || "skill" });
    }
    return items;
  }

  // ── Hermes 官方技能目录（从 GitHub 仓库 Markdown 解析）──
  const HERMES_CATALOG_CACHE = { ts: 0, data: null };
  const HERMES_CATALOG_TTL = 10 * 60 * 1000;
  const HERMES_CATALOG_URLS = {
    bundled: [
      "https://raw.githubusercontent.com/NousResearch/hermes-agent/main/website/docs/reference/skills-catalog.md",
      "https://cdn.jsdelivr.net/gh/NousResearch/hermes-agent@main/website/docs/reference/skills-catalog.md"
    ],
    optional: [
      "https://raw.githubusercontent.com/NousResearch/hermes-agent/main/website/docs/reference/optional-skills-catalog.md",
      "https://cdn.jsdelivr.net/gh/NousResearch/hermes-agent@main/website/docs/reference/optional-skills-catalog.md"
    ]
  };
  async function _fetchTextWithFallback(urls){
    for (const url of urls) {
      try {
        const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(15000) });
        if (r.ok) return await r.text();
      } catch (e) {}
    }
    throw new Error("无法获取 Hermes 技能目录");
  }
  function _parseHermesCatalog(md, kind){
    const items = [];
    let category = "";
    const lines = md.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      const heading = line.match(/^#{2,3}\s+(.+)$/);
      if (heading) { category = heading[1].trim(); continue; }
      if (line.startsWith("|") && /Skill\s*\|/.test(line) && /Description\s*\|/.test(line)) { i++; continue; }
      if (line.startsWith("|")) {
        const cols = line.split("|").map(s => s.trim()).filter(s => s.length > 0);
        if (cols.length < 2) continue;
        const m = cols[0].match(/\[([^\]]+)\]\(([^)]+)\)/);
        if (!m) continue;
        const name = m[1].replace(/[`\\*]/g, "").trim();
        const href = m[2].trim();
        const description = cols[1].replace(/\s+/g, " ").trim();
        let path = "";
        let installCmd = "";
        let webUrl = href.startsWith("http") ? href : ("https://hermes-agent.nousresearch.com" + href);
        if (kind === "bundled") {
          path = (cols[2] || "").replace(/`/g, "").trim();
          installCmd = "hermes skills reset " + (path || name) + " --restore";
        } else {
          path = "official/" + category + "/" + name;
          installCmd = "hermes skills install " + path;
        }
        items.push({ kind, category, name, description, path, installCmd, webUrl });
      }
    }
    return items;
  }
  async function _getHermesCatalog(){
    const now = Date.now();
    if (HERMES_CATALOG_CACHE.data && (now - HERMES_CATALOG_CACHE.ts) < HERMES_CATALOG_TTL) return HERMES_CATALOG_CACHE.data;
    const [bundledMd, optionalMd] = await Promise.all([
      _fetchTextWithFallback(HERMES_CATALOG_URLS.bundled),
      _fetchTextWithFallback(HERMES_CATALOG_URLS.optional)
    ]);
    const data = { bundled: _parseHermesCatalog(bundledMd, "bundled"), optional: _parseHermesCatalog(optionalMd, "optional"), fetchedAt: now };
    HERMES_CATALOG_CACHE.data = data;
    HERMES_CATALOG_CACHE.ts = now;
    return data;
  }

  if (path === "/api/config" && req.method === "GET") {
    const result=await panelModels.execute({action:'read'});
    if(!result.ok)return new Response(JSON.stringify(result),{status:result.status||503,headers:jsonHeaders()});
    const ext=_readExtensionsFile()||{};
    return new Response(JSON.stringify({...result,extensions:ext,extensions_revision:createHash('sha256').update(JSON.stringify(ext)).digest('hex')}),{headers:jsonHeaders()});
  }

  // ── 本地已安装技能枚举 ──
  if (path === "/api/extensions/skills/local" && req.method === "GET") {
    try {
      const ext = _readExtensionsFile() || {};
      const dirs = (ext.skills_dirs || []).map(_expandHome).filter(Boolean);
      const dirSkills = [];
      dirs.forEach(d => { if (_isDir(d)) _readSkillFrontmatter(d).forEach(s => dirSkills.push({ name: s.name, description: s.description, emoji: s.emoji, dir: s.dir, file: s.file, origin: "dir" })); });
      const hermesSkills = _listHermesSkills().map(s => ({
        name: s.name, category: s.category, source: s.source, trust: s.trust,
        status: s.status, emoji: "", description: "", origin: "hermes"
      }));
      // 去重：Hermes  skills 为主，目录扫描补充
      const seen = new Set();
      const skills = [];
      hermesSkills.forEach(s => { seen.add(s.name); skills.push(s); });
      dirSkills.forEach(s => { if (!seen.has(s.name)) { seen.add(s.name); skills.push(s); } });
      return new Response(JSON.stringify({ ok: true, skills, dirs, hermesCount: hermesSkills.length, dirCount: dirSkills.length }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── 远程技能页（nousresearch 文档 / SkillHub）──
  if (path === "/api/extensions/skills/remote" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const target = u.searchParams.get("url");
      const mode = u.searchParams.get("mode") || "embed";
      if (!target) return new Response(JSON.stringify({ ok: false, error: "missing url" }), { status: 400, headers: jsonHeaders() });
      const r = await fetch(target, {
        headers: { "User-Agent": "Mozilla/5.0 (compatible; HermesDashboard/1.0)", "Accept": "text/html,application/xhtml+xml,*/*" },
        signal: AbortSignal.timeout(15000),
      });
      const html = await r.text();
      if (mode === "list") {
        const type = u.searchParams.get("type") || "skill";
        const items = _extractSkillLinks(html, target, type);
        return new Response(JSON.stringify({
          ok: true, url: target, items,
          note: items.length ? "" : "该页面为客户端渲染(SPA)，服务端未返回技能列表；请使用「打开原站」查看完整内容，或稍后在原站复制 SKILL.md 后通过「本地已安装」目录加载。",
        }), { headers: jsonHeaders() });
      }
      // embed 模式：如果页面是客户端渲染 SPA（仅有 loading 骨架），内嵌无法执行其 JS，改为返回提示
      const isClientRenderedSPA = /Loading\s+(the\s+)?catalog|Fetching\s+[0-9]+k?\+?\s+skills|__NEXT_DATA__|data-reactroot/i.test(html);
      if (isClientRenderedSPA) {
        return new Response(JSON.stringify({
          ok: true, url: target, spa: true,
          note: "该页面为客户端渲染(SPA)，内嵌浏览器无法执行其动态加载脚本。请点击「打开原站」在新窗口浏览，或在原站找到 SKILL.md 后通过「本地已安装」目录加载。"
        }), { headers: jsonHeaders() });
      }
      return new Response(JSON.stringify({ ok: true, url: target, html: _sanitizeHtmlForEmbed(html, target) }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 502, headers: jsonHeaders() });
    }
  }

  // ── SkillHub 技能 / 专家包搜索（官方 API：GET /api/skills?keyword=&type=package）──
  if (path === "/api/extensions/skills/search" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const keyword = (u.searchParams.get("keyword") || "").trim();
      const type = u.searchParams.get("type") || "skills"; // skills | packages
      const pageSize = Math.min(Math.max(parseInt(u.searchParams.get("pageSize") || "24", 10) || 24, 1), 50);
      if (!keyword) return new Response(JSON.stringify({ ok: false, error: "empty" }), { status: 200, headers: jsonHeaders() });
      const apiUrl = "https://api.skillhub.cn/api/skills?keyword=" + encodeURIComponent(keyword) +
        "&sortBy=score&pageSize=" + pageSize + (type === "packages" ? "&type=package" : "");
      const r = await fetch(apiUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (compatible; HermesDashboard/1.0)",
          "Accept": "application/json",
          "Origin": "https://www.skillhub.cn",
          "Referer": "https://www.skillhub.cn/",
        },
        signal: AbortSignal.timeout(15000),
      });
      if (!r.ok) {
        const note = (r.status === 429) ? "（SkillHub 请求过于频繁，请稍后再试）" : "";
        return new Response(JSON.stringify({ ok: false, error: "SkillHub API 返回 " + r.status + note }), { status: 502, headers: jsonHeaders() });
      }
      const j = await r.json();
      const arr = (j && j.data && Array.isArray(j.data.skills)) ? j.data.skills : [];
      const items = arr.map(function(it){
        const nsObj = (typeof it.namespace === "object" && it.namespace) ? it.namespace : null;
        const canonical = (nsObj && nsObj.canonicalName) ? nsObj.canonicalName : ("@" + (it.ownerName || "user") + "/" + (it.slug || ""));
        const desc = it.description_zh || it.description || "";
        const subcats = Array.isArray(it.subCategories) ? it.subCategories.map(function(s){ return (s && s.name) ? s.name : ""; }).filter(Boolean) : [];
        const webUrl = (it.homepage || "").replace("api.skillhub.cn", "www.skillhub.cn") || ("https://www.skillhub.cn/skills/" + (it.slug || ""));
        return {
          name: it.name || it.slug || "未命名",
          slug: it.slug || "",
          namespace: canonical,
          description: desc,
          category: it.category || "",
          iconUrl: it.iconUrl || "",
          downloads: it.downloads || 0,
          installs: it.installs || 0,
          stars: it.stars || 0,
          version: it.version || "",
          source: it.source || "",
          tags: subcats,
          webUrl: webUrl,
          installCmd: "hermes skills install " + canonical,
        };
      });
      return new Response(JSON.stringify({ ok: true, type: type, keyword: keyword, total: (j.data && j.data.total) || items.length, items }), { headers: jsonHeaders() });
    } catch (e) {
      const msg = /timeout/i.test(String(e && e.message || e)) ? "SkillHub API 请求超时" : ("搜索失败：" + (e && e.message || e));
      return new Response(JSON.stringify({ ok: false, error: msg }), { status: 502, headers: jsonHeaders() });
    }
  }

  // ── Hermes 官方技能目录搜索（解析 GitHub Markdown）──
  if (path === "/api/extensions/skills/hermes-catalog" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const keyword = (u.searchParams.get("keyword") || "").trim().toLowerCase();
      const type = u.searchParams.get("type") || "all"; // bundled | optional | all
      const catalog = await _getHermesCatalog();
      let arr = [];
      if (type === "bundled" || type === "all") arr = arr.concat(catalog.bundled);
      if (type === "optional" || type === "all") arr = arr.concat(catalog.optional);
      if (keyword) {
        arr = arr.filter(it => ((it.name + " " + it.category + " " + it.description).toLowerCase().indexOf(keyword) !== -1));
      }
      return new Response(JSON.stringify({ ok: true, type, keyword, total: arr.length, items: arr.slice(0, 100) }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 502, headers: jsonHeaders() });
    }
  }

  // ── 安装远程技能（best-effort：尝试从页面提取 SKILL.md）──
  if (path === "/api/extensions/skills/install" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const url = body.url;
      if (!url) return new Response(JSON.stringify({ ok: false, error: "missing url" }), { status: 400, headers: jsonHeaders() });
      const r = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0", "Accept": "text/html,text/markdown,*/*" }, signal: AbortSignal.timeout(20000) });
      const content = await r.text();
      let md = null;
      if (/^---\s*\n/.test(content)) md = content;
      else {
        const m = content.match(/(?:href|src)\s*=\s*["']([^"']+\.md)["']/i) || content.match(/(https?:\/\/[^\s"'<>]+\.md\b)/i);
        if (m) { const mdUrl = m[1]; const r2 = await fetch(_absUrl(mdUrl, url), { signal: AbortSignal.timeout(20000) }); md = await r2.text(); }
      }
      if (!md) return new Response(JSON.stringify({ ok: false, error: "未能从该页面提取 SKILL.md 内容（请确认链接指向技能详情页）" }), { status: 422, headers: jsonHeaders() });
      const fm = md.match(/^---\s*\n([\s\S]*?)\n---/);
      let name = body.name || (fm ? (fm[1].match(/name:\s*(.+)/i) || [])[1] : "") || "";
      name = (name || "skill-" + Date.now()).trim().replace(/^["']|["']$/g, "").replace(/[^\w.-]/g, "_");
      name = skillInstallName(name);
      if (!name) return new Response(JSON.stringify({ ok: false, error: "技能名称只能包含字母、数字、下划线、点和连字符，且不能包含路径片段" }), { status: 400, headers: jsonHeaders() });
      const destDir = `${VAR_DIR}/skills/${name}`;
      mkdirSync(destDir, { recursive: true });
      writeFileSync(`${destDir}/SKILL.md`, md);
      const ext = _readExtensionsFile() || { toolsets: {}, mcp_servers: [], skills_dirs: [], persona: "default", memory: { enabled: true, char_limit: 2200 } };
      ext.skills_dirs = ext.skills_dirs || [];
      if (!ext.skills_dirs.includes(destDir)) ext.skills_dirs.push(destDir);
      _writeExtensionsFile(ext);
      const yamlPath = `${DATA_DIR}/config.yaml`;
      if (existsSync(yamlPath)) { let y = readFileSync(yamlPath, "utf8"); y = _mergeSkillsExternalDirs(y, ext.skills_dirs); writeFileSync(yamlPath, y); }
      return new Response(JSON.stringify({ ok: true, name, dir: destDir }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── 连接器/技能市场：精选目录（连接器能力改由 SkillHub 技能交付，技能由网关原生加载，根治「调用失败」）──
  // 每条目：id（安装目录名）/name/icon/desc/slug/namespace/guide_url（获取指引外链）/cred_hint（凭证提示）/official（官方认证）/mcp（MCP 型技能的服务器与凭证字段）
  const SKILL_MARKET_CATALOG = [
    { id: "ima", name: "腾讯 IMA", icon: "📚", desc: "腾讯 IMA 笔记 / 知识库读写与智能检索", slug: "ima-skills", namespace: "@tencent-adm", guide_url: "https://www.skillhub.cn/skills/tencent-adm/ima-skills", cred_hint: "IMA API Key", official: true },
    { id: "tencent-news", name: "腾讯新闻", icon: "📰", desc: "7×24 实时新闻搜索与热点追踪", slug: "tencent-news", namespace: "@tencent-adm", guide_url: "https://www.skillhub.cn/skills/tencent-adm/tencent-news", cred_hint: "腾讯新闻 API Key", official: true },
    { id: "tencent-docs", name: "腾讯文档", icon: "📝", desc: "docs.qq.com 文档读写 / 协作全功能", slug: "tencent-docs", namespace: "@tencent-adm", guide_url: "https://www.skillhub.cn/skills/tencent-adm/tencent-docs", cred_hint: "腾讯文档 API Key", official: true },
    { id: "wecom", name: "企业微信", icon: "💼", desc: "通讯录 / 消息 / 文档 / 日程 / 会议 / 待办", slug: "wecom-unified", namespace: "@tencent-adm", guide_url: "https://www.skillhub.cn/skills/tencent-adm/wecom-unified", cred_hint: "企业微信 Bot ID / Secret", official: true },
    { id: "tencent-meeting", name: "腾讯会议", icon: "🎥", desc: "会议预约 / 纪要 / 转写 / 录制", slug: "tencent-meeting-skill", namespace: "@wemeeting", guide_url: "https://www.skillhub.cn/skills/wemeeting/tencent-meeting-skill", cred_hint: "腾讯会议身份认证 Token", official: true },
    { id: "mail", name: "个人邮箱", icon: "📧", desc: "QQ / 网易 / Gmail / 新浪 / 搜狐 邮箱（Agently Mail）", slug: "agently-mail", namespace: "@tencent-adm", guide_url: "https://www.skillhub.cn/skills/tencent-adm/agently-mail", cred_hint: "邮箱授权码 / 应用专用密码", official: true },
    { id: "tencent-esign", name: "腾讯电子签", icon: "✍️", desc: "合同起草 / 审查 / 对比 / 法条法规检索", slug: "tencent-esign-contract", namespace: "@tencent-adm", guide_url: "https://www.skillhub.cn/skills/tencent-adm/tencent-esign-contract", cred_hint: "SIGN-TOKEN（qian.tencent.com/aiSkill 获取）", official: true },
    { id: "tencentmap", name: "腾讯地图", icon: "🗺️", desc: "地点搜索 / 路线规划 / 天气 / 旅游攻略", slug: "tencentmap-map-assistant", namespace: "@tencent-adm", guide_url: "https://www.skillhub.cn/skills/tencent-adm/tencentmap-map-assistant", cred_hint: "腾讯位置服务 Key（lbs.qq.com 获取）", official: true },
    { id: "baidu-netdisk", name: "百度网盘", icon: "💾", desc: "网盘文件上传 / 下载 / 转存 / 分享 / 搜索", slug: "baidu-netdisk-skills", namespace: "@wscats", guide_url: "https://www.skillhub.cn/skills/wscats/baidu-netdisk-skills", cred_hint: "百度网盘授权码（技能内 login.sh 引导）" },
    { id: "mcdonalds", name: "麦当劳点餐", icon: "🍔", desc: "门店 / 餐品 / 优惠券查询与点餐（MCP）", slug: "mcdonalds-mcp-china", namespace: "@meteorsliu", guide_url: "https://www.skillhub.cn/skills/meteorsliu/mcdonalds-mcp-china", cred_hint: "麦当劳 MCP Token（open.mcd.cn/mcp 获取）", mcp: { name: "mcd-mcp", url: "https://mcp.mcd.cn", fields: [{ key: "token", label: "MCP Token", header: "Authorization", prefix: "Bearer " }] } },
    { id: "lexiang", name: "腾讯乐享", icon: "🤝", desc: "腾讯乐享知识库检索（MCP）", slug: "lexiang-mcp-skill", namespace: "@lexiang", guide_url: "https://www.skillhub.cn/skills/lexiang/lexiang-mcp-skill", cred_hint: "乐享 Token + Company From", official: true, mcp: { name: "lexiang-mcp", url: "https://mcp.lexiang-app.com/mcp", fields: [{ key: "token", label: "乐享 Token", header: "Authorization", prefix: "Bearer " }, { key: "company_from", label: "Company From", header: "X-Company-From" }] } },
    { id: "weread", name: "微信读书", icon: "📖", desc: "搜书 / 书架 / 笔记 / 书评 / 阅读统计", slug: "weread-skills-official", namespace: "@user_0b9d349a", guide_url: "https://www.skillhub.cn/skills/user_0b9d349a/weread-skills-official", cred_hint: "微信读书 API Key" },
    { id: "ctrip-wendao", name: "携程问道", icon: "✈️", desc: "携程官方 AI 旅伴（行程 / 机酒规划）", slug: "wendao-skill", namespace: "@trips-ai", guide_url: "https://www.skillhub.cn/skills/trips-ai/wendao-skill", cred_hint: "携程问道 API Token" },
    { id: "meituan-travel", name: "美团旅行", icon: "🏨", desc: "酒店 / 机票 / 火车票 / 门票查询预订", slug: "meituan-travel", namespace: "@user_fe933096", guide_url: "https://www.skillhub.cn/skills/user_fe933096/meituan-travel", cred_hint: "美团旅行助手 Token" },
    { id: "youdaonote", name: "有道云笔记", icon: "🗒️", desc: "笔记剪藏 / 资讯推送 / 知识管理", slug: "youdaonote-clip", namespace: "@lephix", guide_url: "https://www.skillhub.cn/skills/lephix/youdaonote-clip", cred_hint: "有道云笔记 API Key" },
    { id: "fliggy", name: "飞猪旅行", icon: "🧳", desc: "飞猪旅行搜索（机票 / 酒店 / 度假）", slug: "fliggy-travel-new", namespace: "@user_b95ee7e5", guide_url: "https://www.skillhub.cn/skills/user_b95ee7e5/fliggy-travel-new", cred_hint: "飞猪 API Key" },
    { id: "baidu-map", name: "百度地图", icon: "🧭", desc: "附近地点 / 地图热点检索", slug: "baidu-nearby", namespace: "@longjf25", guide_url: "https://www.skillhub.cn/skills/longjf25/baidu-nearby", cred_hint: "百度地图 API Key" },
    { id: "qq-music", name: "QQ音乐", icon: "🎵", desc: "音乐搜索 / 歌单 / 播放控制", slug: "qq-music", namespace: "@mike47512", guide_url: "https://www.skillhub.cn/skills/mike47512/qq-music", cred_hint: "QQ音乐 API Key" },
    { id: "legal", name: "元典法律", icon: "⚖️", desc: "法律数据库检索（案例 / 法规 / 企业）", slug: "legal-search", namespace: "@user_72ffbadb", guide_url: "https://www.skillhub.cn/skills/user_72ffbadb/legal-search", cred_hint: "元典法律智能 API Key" },
  ];

  // GET /api/extensions/skills/market-catalog → 精选连接器技能目录（含已安装状态 + 全部已安装目录名，供搜索结果对照）
  if (path === "/api/extensions/skills/market-catalog" && req.method === "GET") {
    try {
      const installedNames = [];
      const skillsRoot = join(VAR_DIR, "skills");
      try {
        if (_isDir(skillsRoot)) readdirSync(skillsRoot).forEach(n => { const d = join(skillsRoot, n); if (_isDir(d) && existsSync(join(d, "SKILL.md"))) installedNames.push(n); });
      } catch (e) {}
      const installed = new Set(installedNames);
      const items = SKILL_MARKET_CATALOG.map(c => Object.assign({}, c, { installed: installed.has(c.id) }));
      return new Response(JSON.stringify({ ok: true, items, installed_names: installedNames }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // POST /api/extensions/skills/install-package → 下载 SkillHub 完整技能包（含 scripts/references 子目录），注册 skills_dirs；MCP 型同时注册 MCP 服务器
  // body: { slug, namespace, name?, mcp?: { name, url, headers } }
  if (path === "/api/extensions/skills/install-package" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const slug = (body.slug || "").trim();
      const namespace = (body.namespace || "").trim();
      if (!slug) return new Response(JSON.stringify({ ok: false, error: "missing slug" }), { status: 400, headers: jsonHeaders() });
      const name = skillInstallName(body.name || slug);
      if (!name) return new Response(JSON.stringify({ ok: false, error: "技能名称只能包含字母、数字、下划线、点和连字符，且不能包含路径片段" }), { status: 400, headers: jsonHeaders() });

      const apiBase = "https://api.skillhub.cn/api/v1/skills/" + encodeURIComponent(slug);
      const nsQ = namespace ? ("namespace=" + encodeURIComponent(namespace)) : "";
      const hdrs = { "User-Agent": "Mozilla/5.0 (compatible; HermesDashboard/1.0)", "Accept": "application/json, text/markdown, */*", "Origin": "https://www.skillhub.cn", "Referer": "https://www.skillhub.cn/" };

      // 1. 文件列表（version 缺省取最新）
      const listR = await fetch(apiBase + "/files" + (nsQ ? ("?" + nsQ) : ""), { headers: hdrs, signal: AbortSignal.timeout(20000) });
      if (!listR.ok) return new Response(JSON.stringify({ ok: false, error: "SkillHub 文件列表返回 " + listR.status }), { status: 502, headers: jsonHeaders() });
      const listJ = await listR.json().catch(() => ({}));
      const files = Array.isArray(listJ.files) ? listJ.files : [];
      if (!files.length) return new Response(JSON.stringify({ ok: false, error: "该技能没有可下载的文件" }), { status: 422, headers: jsonHeaders() });

      // 2. 目标目录（前端传 name 指定，默认用 slug）
      const destDir = join(VAR_DIR, "skills", name);
      mkdirSync(destDir, { recursive: true });

      // 3. 逐文件下载：/file 端点 302→COS，默认跟随重定向（版本/存储桶无关）
      const downloaded = []; const failed = [];
      for (const f of files) {
        const relPath = String(f.path || "");
        if (!relPath || relPath.includes("..") || /^[\\/]/.test(relPath)) { failed.push({ path: relPath, error: "非法路径" }); continue; }
        const fileUrl = apiBase + "/file?path=" + encodeURIComponent(relPath) + (nsQ ? ("&" + nsQ) : "");
        try {
          const fr = await fetch(fileUrl, { headers: hdrs, signal: AbortSignal.timeout(30000) });
          if (!fr.ok) { failed.push({ path: relPath, error: "HTTP " + fr.status }); continue; }
          const buf = Buffer.from(await fr.arrayBuffer());
          const destPath = join(destDir, relPath);
          mkdirSync(dirname(destPath), { recursive: true });
          writeFileSync(destPath, buf);
          downloaded.push(relPath);
        } catch (e) { failed.push({ path: relPath, error: e.message }); }
      }
      if (!downloaded.length) return new Response(JSON.stringify({ ok: false, error: "未能下载任何文件", failed }), { status: 502, headers: jsonHeaders() });

      // 4. 注册 skills_dirs（extensions.json + config.yaml）
      const ext = _readExtensionsFile() || { toolsets: {}, mcp_servers: [], skills_dirs: [], persona: "default", memory: { enabled: true, char_limit: 2200 } };
      ext.skills_dirs = ext.skills_dirs || [];
      if (!ext.skills_dirs.includes(destDir)) ext.skills_dirs.push(destDir);
      _writeExtensionsFile(ext);
      const yamlPath = `${DATA_DIR}/config.yaml`;
      if (existsSync(yamlPath)) { let y = readFileSync(yamlPath, "utf8"); y = _mergeSkillsExternalDirs(y, ext.skills_dirs); writeFileSync(yamlPath, y); }

      // 5. MCP 型技能：注册 MCP 服务器
      let mcpRegistered = null;
      if (body.mcp && body.mcp.url) {
        const mName = body.mcp.name || (name + "-mcp");
        _upsertMcpServer(mName, { url: body.mcp.url, headers: body.mcp.headers || {} });
        mcpRegistered = body.mcp.url;
      }

      // 6. 触发网关重启以加载新技能 / MCP（skills_dirs 或 mcp_servers 变更均需重启后对 AI 生效）
      _triggerGatewayRestart("skill-install-" + name);

      return new Response(JSON.stringify({ ok: true, name, dir: destDir, files: downloaded, failed, mcp: mcpRegistered, restart_required: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // POST /api/extensions/skills/uninstall -> uninstall an installed skill: remove dir, drop from skills_dirs & config.yaml, restart gateway
  // body: { name } (skill install dir name)
  if (path === "/api/extensions/skills/uninstall" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const name = String(body.name || "").trim();
      if (!name || name.indexOf("/") >= 0 || name.indexOf("..") >= 0) return new Response(JSON.stringify({ ok: false, error: "invalid name" }), { status: 400, headers: jsonHeaders() });
      const destDir = join(VAR_DIR, "skills", name);
      const ext = _readExtensionsFile() || { toolsets: {}, mcp_servers: [], skills_dirs: [], persona: "default", memory: { enabled: true, char_limit: 2200 } };
      ext.skills_dirs = (ext.skills_dirs || []).filter(function (d) { return d !== destDir && _expandHome(d) !== destDir; });
      _writeExtensionsFile(ext);
      const yamlPath = `${DATA_DIR}/config.yaml`;
      if (existsSync(yamlPath)) { let y = readFileSync(yamlPath, "utf8"); y = _mergeSkillsExternalDirs(y, ext.skills_dirs); writeFileSync(yamlPath, y); }
      let removed = false;
      try { if (_isDir(destDir)) { rmSync(destDir, { recursive: true, force: true }); removed = true; } } catch (e) {}
      // MCP 型技能：同步移除已注册的 MCP 服务器（避免遗留指向已删除技能的失效 MCP）
      const mcpName = String(body.mcp_name || "").trim();
      if (mcpName) { try { _upsertMcpServer(mcpName, null); } catch (e) {} }
      _triggerGatewayRestart("skill-uninstall-" + name);
      return new Response(JSON.stringify({ ok: true, name, removed, restart_required: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // POST /api/extensions/skills/config-mcp -> save MCP skill credentials (write into the MCP server headers, restart gateway)
  // body: { name (mcp server name), url, headers: { headerName: value } } —— blank values keep previously saved ones
  if (path === "/api/extensions/skills/config-mcp" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const name = String(body.name || "").trim();
      const url = String(body.url || "").trim();
      if (!name || !url) return new Response(JSON.stringify({ ok: false, error: "missing name/url" }), { status: 400, headers: jsonHeaders() });
      const incoming = (body.headers && typeof body.headers === "object") ? body.headers : {};
      // merge with existing headers: blank input keeps the saved value, so re-saving never wipes configured creds
      const current = _parseMcpServers(_readHermesConfig())[name] || {};
      const headers = Object.assign({}, (current.headers && typeof current.headers === "object") ? current.headers : {});
      Object.keys(incoming).forEach(function (k) { const v = String(incoming[k] == null ? "" : incoming[k]).trim(); if (v !== "") headers[k] = v; });
      _upsertMcpServer(name, { url: url, headers: headers });
      _triggerGatewayRestart("skill-config-mcp-" + name);
      return new Response(JSON.stringify({ ok: true, name, restart_required: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ─── 定时任务（Cron）管理 API（读取活跃 profile 的 jobs.json，兼容旧全局路径）───
  // 注：hermes 0.20.0 起 cron 数据按 profile 隔离（profiles/<id>/cron/jobs.json），
  // 若仍读全局 DATA_DIR/cron/jobs.json 将永远得到空列表（0.20 升级遗留问题，此处修复）。
  const CRON_DIR = `${DATA_DIR}/cron`;
  const CRON_JOBS_FILE = `${CRON_DIR}/jobs.json`;

  // 优先读活跃 profile 的 jobs.json；不存在时回退全局路径（兼容旧版/异常状态）
  function _cronJobsFile() {
    try {
      const prof = _getActiveProfile();
      if (prof) {
        const p = `${DATA_DIR}/profiles/${prof}/cron/jobs.json`;
        if (existsSync(p)) return p;
      }
    } catch {}
    return CRON_JOBS_FILE;
  }

  function _readCronJobs() {
    const f = _cronJobsFile();
    if (!existsSync(f)) return [];
    const data = JSON.parse(readFileSync(f, 'utf8').replace(/^\uFEFF/, ''));
    const jobs = Array.isArray(data) ? data : data.jobs;
    if (!Array.isArray(jobs)) throw new Error('任务存储格式损坏，未修改原文件');
    return jobs;
  }

  if (path === "/api/cron-jobs" && req.method === "GET") {
    try {
      const jobs = _readCronJobs().map(job => ({...job, panel_revision: cronRevision(job)}));
      // 附带 webhook 投递配置（前端展示 🔗 通道与投递状态）
      const webhooks = _readCronWebhooks();
      const hooks = {};
      Object.keys(webhooks).forEach(id => {
        hooks[id] = (webhooks[id] || []).map(h => ({
          url: h.url, label: h.label || "", message: h.message || "",
          last_run_at: h.last_run_at || null, last_status: h.last_status || null, last_error: h.last_error || null,
        }));
      });
      return new Response(JSON.stringify({ ok: true, jobs, webhooks: hooks }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message, jobs: [] }), { status: 500, headers: jsonHeaders() });
    }
  }

  const cronUpdateResponse = await handleCronUpdate(req, path);
  if (cronUpdateResponse) return cronUpdateResponse;
  const cronHooksResponse = await handleCronHooks(req, path);
  if (cronHooksResponse) return cronHooksResponse;
  const cronHistoryResponse = await handleCronHistory(req, path);
  if (cronHistoryResponse) return cronHistoryResponse;

  // ─── 记忆 / 灵魂管理 API（读写 DATA_DIR 下的 SOUL.md、MEMORY.md、notes.md）───
  // 2026-08-24 profilefix：优先跟随请求的 ?profile= 参数（前端传当前会话绑定的 agent），
  // 无参数时回退 .active_profile 文件；notes.md 保持全局共享（收件箱）。
  function _resolveProfileDir(pid) {
    if (pid && pid !== "default" && existsSync(`${DATA_DIR}/profiles/${pid}`)) {
      return `${DATA_DIR}/profiles/${pid}`;
    }
    return DATA_DIR;
  }
  function _activeProfileDir() {
    try {
      const ap = readFileSync(`${DATA_DIR}/.active_profile`, "utf8").trim();
      if (ap && ap !== "default" && existsSync(`${DATA_DIR}/profiles/${ap}`)) {
        return `${DATA_DIR}/profiles/${ap}`;
      }
    } catch (e) {}
    return DATA_DIR;
  }
  if (path === "/api/memory" && req.method === "GET") {
    try {
      const _u = new URL(req.url, "http://localhost");
      const _reqProfile = (_u.searchParams.get("profile") || "").trim();
      const _profileDir = _reqProfile ? _resolveProfileDir(_reqProfile) : _activeProfileDir();
      let soul = "", memory = "", notes = "", user = "", agents = "";
      try { soul = readFileSync(`${_profileDir}/SOUL.md`, "utf8"); } catch {}
      try { memory = readFileSync(`${_profileDir}/memories/MEMORY.md`, "utf8"); } catch {}
      try { notes = readFileSync(`${DATA_DIR}/notes.md`, "utf8"); } catch {}
      /* 2026-11-13（资料面板「助手」板块）：USER.md 与 AGENTS.md 也要能读能改。
         两者都在 profile 目录下，路径写死不接受请求参数，避免变成任意文件读写。 */
      try { user = readFileSync(`${_profileDir}/memories/USER.md`, "utf8"); } catch {}
      try { agents = readFileSync(`${_profileDir}/AGENTS.md`, "utf8"); } catch {}
      // 读取记忆配置（config.yaml 中的 memory 段）
      const cfg = _readHermesConfig();
      const memEnabled = !/memory:\s*\n\s*enabled:\s*false/.test(cfg);
      const _effProfile = _reqProfile || _getActiveProfile();
      /* 能力清单：只取技能名，不读正文（355 个 SKILL.md 全文会把响应撑到几兆）。 */
      let skills = [];
      try {
        const sdir = `${_profileDir}/skills`;
        for (const name of readdirSync(sdir)) {
          const f = `${sdir}/${name}/SKILL.md`;
          if (existsSync(f)) { try { skills.push({ name, bytes: statSync(f).size }); } catch {} }
        }
        skills.sort((a, b) => a.name.localeCompare(b.name));
      } catch {}
      /* 密码本：只给键名和掩码，值不出服务端。要看值走 POST reveal（需要显式确认）。 */
      let envKeys = [];
      try {
        const raw = readFileSync(`${DATA_DIR}/.env`, "utf8");
        envKeys = raw.split(/\r?\n/).map(l => l.trim()).filter(l => l && !l.startsWith("#")).map(l => {
          const i = l.indexOf("=");
          return i > 0 ? { key: l.slice(0, i).trim(), hint: (l.slice(i + 1).trim().length ? "已设置" : "空") } : null;
        }).filter(Boolean);
      } catch {}
      return new Response(JSON.stringify({ ok: true, soul, memory, notes, user, agents, skills, env_keys: envKeys, memory_enabled: memEnabled, profile: _effProfile, profile_dir: _profileDir }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // POST /api/memory → 保存灵魂/记忆/笔记
  if (path === "/api/memory" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const _reqProfile = (body.profile || "").trim();
      const _profileDir = _reqProfile ? _resolveProfileDir(_reqProfile) : _activeProfileDir();
      if (body.soul !== undefined) {
        writeFileSync(`${_profileDir}/SOUL.md`, String(body.soul), { mode: 0o644 });
      }
      if (body.memory !== undefined) {
        if (!existsSync(`${_profileDir}/memories`)) mkdirSync(`${_profileDir}/memories`, { recursive: true });
        writeFileSync(`${_profileDir}/memories/MEMORY.md`, String(body.memory), { mode: 0o644 });
      }
      if (body.notes !== undefined) {
        writeFileSync(`${DATA_DIR}/notes.md`, String(body.notes), { mode: 0o644 });
      }
      /* USER.md / AGENTS.md 写入：同样只认固定路径；写前留一份 .bak 便于回滚。 */
      if (body.user !== undefined) {
        if (!existsSync(`${_profileDir}/memories`)) mkdirSync(`${_profileDir}/memories`, { recursive: true });
        const f = `${_profileDir}/memories/USER.md`;
        if (existsSync(f)) { try { copyFileSync(f, f + ".bak"); } catch {} }
        writeFileSync(f, String(body.user), { mode: 0o644 });
      }
      if (body.agents !== undefined) {
        const f = `${_profileDir}/AGENTS.md`;
        if (existsSync(f)) { try { copyFileSync(f, f + ".bak"); } catch {} }
        writeFileSync(f, String(body.agents), { mode: 0o644 });
      }
      const _effProfile = _reqProfile || _getActiveProfile();
      return new Response(JSON.stringify({ ok: true, profile: _effProfile, profile_dir: _profileDir }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  if (path === "/api/usage" && req.method === "GET") {
    return handleUsage(req, path);
  }

  // ─── 学习轨迹 API（技能图谱 + 使用统计，读取 skills 目录 + Dashboard state.db）───
  if (path === "/api/learning-trajectory" && req.method === "GET") {
    try {
      const skills = [];
      const relations = [];
      // 1. 读取本地 skills 目录
      const skillsDir = `${DATA_DIR}/skills`;
      if (existsSync(skillsDir)) {
        const dirs = readdirSync(skillsDir).filter(d => {
          try { return statSync(`${skillsDir}/${d}`).isDirectory(); } catch { return false; }
        });
        dirs.forEach(dir => {
          let meta = {};
          try { meta = JSON.parse(readFileSync(`${skillsDir}/${dir}/metadata.json`, "utf8")); } catch {}
          let category = meta.category || "other";
          // 尝试从 SKILL.md 或 skill.yaml 提取分类
          if (category === "other") {
            try {
              const skillMd = readFileSync(`${skillsDir}/${dir}/SKILL.md`, "utf8");
              const catMatch = skillMd.match(/category:\s*(.+)/i);
              if (catMatch) category = catMatch[1].trim();
            } catch {}
          }
          skills.push({
            id: dir,
            name: meta.name || dir,
            category,
            description: meta.description || "",
            usage_count: meta.usage_count || 0,
            created_at: meta.created_at || null,
            source: meta.source || "local"
          });
        });
      }
      // 2. 尝试从 Dashboard 获取技能使用统计
      if (isPortListening(DASHBOARD_PORT)) {
        try {
          const h = new Headers();
          h.set("X-Hermes-Session-Token", DASHBOARD_SESSION_TOKEN);
          const r = await fetch(`http://${DASHBOARD_BIND}:${DASHBOARD_PORT}/api/skills`, {
            headers: h, signal: AbortSignal.timeout(6000),
          });
          if (r.ok) {
            const data = await r.json();
            const dashSkills = Array.isArray(data) ? data : (data.skills || []);
            dashSkills.forEach(ds => {
              const existing = skills.find(s => s.id === (ds.id || ds.name));
              if (existing) {
                existing.usage_count = ds.usage || ds.usage_count || ds.usageCount || existing.usage_count;
                if (ds.category) existing.category = ds.category;
              } else {
                skills.push({
                  id: ds.id || ds.name,
                  name: ds.name || ds.id,
                  category: ds.category || "other",
                  description: ds.description || "",
                  usage_count: ds.usage || ds.usage_count || ds.usageCount || 0,
                  created_at: ds.created_at || null,
                  source: "dashboard"
                });
              }
            });
          }
        } catch {}
      }
      // 3. 构建关系（同分类技能之间建立关联）
      const byCat = {};
      skills.forEach(s => {
        if (!byCat[s.category]) byCat[s.category] = [];
        byCat[s.category].push(s.id);
      });
      Object.keys(byCat).forEach(cat => {
        const ids = byCat[cat];
        for (let i = 0; i < ids.length && i < 8; i++) {
          for (let j = i + 1; j < ids.length && j < 8; j++) {
            relations.push({ from: ids[i], to: ids[j], type: "same_category" });
          }
        }
      });
      // 4. 笔记边（2026-11-11 第 10 项）：技能名出现在知识库笔记正文里 → 图上连一条虚线。
      //    只回传真正被引用到的笔记，最多 120 篇 / 400 条边——960 个节点会把 SVG 拖死。
      let notes = [];
      let noteEdges = [];
      try {
        const corpus = _scanKnowledgeNotes();
        if (corpus.length && skills.length) {
          const nameToSkills = new Map();
          skills.forEach(s => {
            const key = String(s.name || s.id || "").replace(/^@[^/]+\//, "").replace(/\.md$/i, "").trim();
            if (key.length < 3) return;
            if (!nameToSkills.has(key)) nameToSkills.set(key, []);
            nameToSkills.get(key).push(s.id);
          });
          if (nameToSkills.size) {
            const keys = [...nameToSkills.keys()].sort((a, b) => b.length - a.length);
            const re = new RegExp(keys.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|"), "g");
            const hits = new Map();
            for (const note of corpus) {
              const seen = new Set();
              for (const m of note.text.matchAll(re)) seen.add(m[0]);
              if (!seen.size) continue;
              for (const k of seen) {
                for (const sid of (nameToSkills.get(k) || [])) {
                  if (noteEdges.length >= 400) break;
                  noteEdges.push({ from: sid, to: note.path, via: "mention" });
                  hits.set(note.path, (hits.get(note.path) || 0) + 1);
                }
              }
            }
            notes = corpus
              .filter(n => hits.has(n.path))
              .map(n => ({ path: n.path, title: n.title, links: hits.get(n.path) }))
              .sort((a, b) => b.links - a.links)
              .slice(0, 120);
            const keep = new Set(notes.map(n => n.path));
            noteEdges = noteEdges.filter(e => keep.has(e.to));
          }
        }
      } catch (e) { log(`[learning-trajectory] 笔记边计算失败: ${e?.message || e}`); }
      return new Response(JSON.stringify({ ok: true, skills, relations, notes, note_edges: noteEdges }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message, skills: [], relations: [], notes: [], note_edges: [] }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── 平台频道 / 通讯 ────────────────────────────────────────────────
  if (path === "/api/channels" && req.method === "GET") {
    try {
      return new Response(JSON.stringify({ ok: true, channels: _listChannels(), defs: CHANNEL_DEFS }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // POST /api/channels/:id/toggle → 启用/禁用渠道（platforms.<id>.enabled + 重启网关）
  const toggleM = path.match(/^\/api\/channels\/([^/]+)\/toggle$/);
  if (toggleM && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const r = _toggleChannel(toggleM[1], body.enabled !== false);
      return new Response(JSON.stringify(r), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── 通道会话同步：从 Dashboard 拉取各平台会话，按 channel 分组返回给前端 ──
  if (path === "/api/channel-sessions" && req.method === "GET") {
    try {
      const groups = {};
      // 1) 从 Dashboard API 拉取会话（两个端口：9219=Dashboard, 8742=Gateway）
      // 9219 用 X-Hermes-Session-Token，返回 {sessions:[...]}（含 cron/tui）
      // 8742 用 Authorization: Bearer <MONITOR_TOKEN>，返回 {data:[...]}（含 QQ/微信等通道）
      try {
        const dh = new Headers();
        dh.set("X-Hermes-Session-Token", DASHBOARD_SESSION_TOKEN);
        const dr = await fetch(`http://${DASHBOARD_BIND}:9219/api/sessions`, { headers: dh, signal: AbortSignal.timeout(8000) });
        if (dr.ok) {
          const ddata = await dr.json();
          const dsessions = Array.isArray(ddata) ? ddata : (ddata.sessions || ddata.data || ddata.items || []);
          dsessions.forEach(s => {
            const platform = s.platform || s.source || s.channel || "api_server";
            if (platform === "api_server") return;
            if (!groups[platform]) groups[platform] = [];
            groups[platform].push({
              id: s.id || s.session_id || "", title: s.title || s.name || "未命名会话", platform,
              updated_at: s.updated_at || s.last_active || s.started_at || s.created_at || 0,
              message_count: s.message_count || (s.messages ? s.messages.length : 0), model: s.model || "",
              chat_id: s.chat_id || (s.extra && s.extra.chat_id) || (s.meta && s.meta.chat_id) || "",
            });
          });
        }
      } catch (e) {}
      try {
        const gh = new Headers();
        gh.set("Authorization", "Bearer " + MONITOR_TOKEN);
        const gr = await fetch(`http://${DASHBOARD_BIND}:${GATEWAY_PORT}/api/sessions`, { headers: gh, signal: AbortSignal.timeout(8000) });
        if (gr.ok) {
          const gdata = await gr.json();
          const gsessions = Array.isArray(gdata) ? gdata : (gdata.data || gdata.sessions || gdata.items || []);
          gsessions.forEach(s => {
            const platform = s.platform || s.source || s.channel || "api_server";
            if (platform === "api_server") return;
            if (!groups[platform]) groups[platform] = [];
            groups[platform].push({
              id: s.id || s.session_id || "", title: s.title || s.name || "未命名会话", platform,
              updated_at: s.updated_at || s.last_active || s.started_at || s.created_at || 0,
              message_count: s.message_count || 0, model: s.model || "",
              chat_id: s.chat_id || (s.extra && s.extra.chat_id) || (s.meta && s.meta.chat_id) || "",
            });
          });
        }
      } catch (e) {}
      // 1.5) 双源去重（v0.21.144+145）：Dashboard(9219) 与 Gateway(8742) 会返回同一批通道会话，
      //      此前各自 push 导致微信/QQ 等通道出现重复对话条目。
      //      v0.21.145 增强：优先按 (platform, chat_id) 去重（同一聊天只保留一条，保留最新），
      //      hermes 列表 API 未暴露 chat_id 时退化为 (platform, session id)。
      try {
        Object.keys(groups).forEach(k => {
          // 1.5a) 先按 session id 去重（2026-11-03 修）：Dashboard(9219) 行带 chat_id，
          //       Gateway(8742) 的 /api/sessions 行根本没有 chat_id 字段，
          //       于是下面按 chat_id 拼的 key 与按 id 拼的 key 永远对不上，
          //       同一个会话被两边各 push 一次 → 面板里每个频道/子区都显示成两条一模一样的。
          //       先按 id 收一遍，保留先到的 Dashboard 行（带 chat_id/display_name）。
          const seenIds = new Set();
          groups[k] = groups[k].filter(s => {
            const id = String(s.id || "");
            if (id && seenIds.has(id)) return false;
            if (id) seenIds.add(id);
            return true;
          });
          // 1.5b) 再按 (platform, chat_id) 去重（同一聊天只保留一条）
          const seen = new Map();
          groups[k] = groups[k].filter(s => {
            const chatId = String(s.chat_id || (s.extra && s.extra.chat_id) || (s.meta && s.meta.chat_id) || "").trim();
            const key = chatId ? (k + "|" + chatId) : (k + "|" + (s.id || ""));
            if (seen.has(key)) return false;
            seen.set(key, s.updated_at || 0);
            return true;
          });
        });
      } catch (e) {}
      // 2) 补充：已配置但暂无会话的通道也显示（让用户看到 QQ/微信等已绑定通道）
      try {
        const env = _readEnvFile();
        const chMap = {
          qqbot: ["QQ_APP_ID", "QQ_CLIENT_SECRET"],
          weixin: ["WEIXIN_TOKEN", "WEIXIN_ACCOUNT_ID"],
          wecom: ["WECOM_BOT_ID", "WECOM_SECRET"],
          telegram: ["TELEGRAM_BOT_TOKEN"],
          discord: ["DISCORD_BOT_TOKEN"],
          slack: ["SLACK_BOT_TOKEN"],
          whatsapp: ["WHATSAPP_ENABLED"],
          feishu: ["FEISHU_APP_ID", "FEISHU_APP_SECRET"],
          dingtalk: ["DINGTALK_APP_KEY", "DINGTALK_APP_SECRET"],
          matrix: ["MATRIX_ACCESS_TOKEN"],
        };
        Object.keys(chMap).forEach(id => {
          const keys = chMap[id];
          const has = keys.some(k => _getEnvValue(env, k));
          if (has && !groups[id]) groups[id] = [];
        });
      } catch (e) {}
      Object.keys(groups).forEach(k => groups[k].sort((a, b) => (b.updated_at || 0) - (a.updated_at || 0)));
      return new Response(JSON.stringify({ ok: true, groups }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: true, groups: {}, error: e.message }), { headers: jsonHeaders() });
    }
  }
  // ── 通道会话消息：获取指定 session 的聊天消息（从 Dashboard API 拉取）──
  const chSessMsgMatch = path.match(/^\/api\/channel-sessions\/([^/]+)\/messages$/);
  if (chSessMsgMatch && req.method === "GET") {
    try {
      const sessionId = decodeURIComponent(chSessMsgMatch[1]);
      if (!isPortListening(DASHBOARD_PORT)) {
        return new Response(JSON.stringify({ ok: false, error: "Dashboard 未运行", messages: [] }), { headers: jsonHeaders() });
      }
      const h = new Headers();
      h.set("X-Hermes-Session-Token", DASHBOARD_SESSION_TOKEN);
      // 尝试多种 Dashboard API 格式获取会话消息
      let messages = [];
      let sessionTitle = "";
      // 方式1: /api/sessions/:id/messages
      try {
        const r1 = await fetch(`http://${DASHBOARD_BIND}:${DASHBOARD_PORT}/api/sessions/${encodeURIComponent(sessionId)}/messages`, {
          headers: h, signal: AbortSignal.timeout(8000),
        });
        if (r1.ok) {
          const d1 = await r1.json();
          messages = Array.isArray(d1) ? d1 : (d1.messages || d1.items || []);
        }
      } catch {}
      // 方式2: 如果方式1失败，尝试 /api/sessions/:id（可能包含 messages 字段）
      if (!messages.length) {
        try {
          const r2 = await fetch(`http://${DASHBOARD_BIND}:${DASHBOARD_PORT}/api/sessions/${encodeURIComponent(sessionId)}`, {
            headers: h, signal: AbortSignal.timeout(8000),
          });
          if (r2.ok) {
            const d2 = await r2.json();
            sessionTitle = d2.title || d2.name || "";
            messages = d2.messages || d2.history || [];
          }
        } catch {}
      }
      // 方式3: 从全部 sessions 列表中查找（兜底）
      if (!messages.length) {
        try {
          const r3 = await fetch(`http://${DASHBOARD_BIND}:${DASHBOARD_PORT}/api/sessions`, {
            headers: h, signal: AbortSignal.timeout(8000),
          });
          if (r3.ok) {
            const d3 = await r3.json();
            const allSessions = Array.isArray(d3) ? d3 : (d3.sessions || d3.items || []);
            const found = allSessions.find(s => (s.id || s.session_id) === sessionId);
            if (found) {
              sessionTitle = found.title || found.name || "";
              messages = found.messages || found.history || [];
            }
          }
        } catch {}
      }
      // 标准化消息格式
      const normalized = messages.map(m => ({
        role: m.role || (m.is_user ? "user" : "assistant"),
        content: m.content || m.text || m.message || "",
        timestamp: m.timestamp || m.created_at || m.ts || 0,
        model: m.model || "",
        tool_calls: m.tool_calls || null,
      }));
      return new Response(JSON.stringify({ ok: true, messages: normalized, title: sessionTitle, session_id: sessionId }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message, messages: [] }), { status: 500, headers: jsonHeaders() });
    }
  }
  // DELETE /api/channel-sessions/:id → 删除通道会话（cron/微信/QQ 等，读来自 hermes gateway）
  // 优先 Gateway(8742) DELETE /api/sessions/:id；Dashboard(9219) 兜底。修复"cron/微信会话删不掉"。
  const chSessDelMatch = path.match(/^\/api\/channel-sessions\/([^/]+)$/);
  if (chSessDelMatch && req.method === "DELETE") {
    try {
      const sessionId = decodeURIComponent(chSessDelMatch[1]);
      // ① Gateway 8742（hermes 会话主存储）
      try {
        const gh = new Headers();
        gh.set("Authorization", "Bearer " + MONITOR_TOKEN);
        const gr = await fetch(`http://${DASHBOARD_BIND}:${GATEWAY_PORT}/api/sessions/${encodeURIComponent(sessionId)}`, { method: "DELETE", headers: gh, signal: AbortSignal.timeout(10000) });
        if (gr.ok) return new Response(JSON.stringify({ ok: true, via: "gateway" }), { headers: jsonHeaders() });
      } catch (e) {}
      // ② Dashboard 9219（兜底）
      try {
        const dh = new Headers();
        dh.set("X-Hermes-Session-Token", DASHBOARD_SESSION_TOKEN);
        const dr = await fetch(`http://${DASHBOARD_BIND}:${DASHBOARD_PORT}/api/sessions/${encodeURIComponent(sessionId)}`, { method: "DELETE", headers: dh, signal: AbortSignal.timeout(10000) });
        if (dr.ok) return new Response(JSON.stringify({ ok: true, via: "dashboard" }), { headers: jsonHeaders() });
      } catch (e) {}
      return new Response(JSON.stringify({ ok: false, error: "删除失败：gateway 与 dashboard 均未确认删除" }), { status: 500, headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // POST /api/channels/:id/test → 通道「测试」按钮（对齐 Octop probe_channel：真实连接验证凭证）
  const chTestMatch = path.match(/^\/api\/channels\/([a-zA-Z0-9_]+)\/test$/);
  if (chTestMatch && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const r = await _testChannel(chTestMatch[1], body);
      return new Response(JSON.stringify(r), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // POST /api/channels/:id  → 保存凭证 + 行为配置
  const chSaveMatch = path.match(/^\/api\/channels\/([a-zA-Z0-9_]+)$/);
  if (chSaveMatch && req.method === "POST") {
    try {
      const id = chSaveMatch[1];
      const body = await req.json().catch(() => ({}));
      const r = _saveChannel(id, body);
      if (!r.ok) return new Response(JSON.stringify(r), { status: 400, headers: jsonHeaders() });
      // 保存后立即重启网关使新凭证/配置生效（微信此前缺失：网关只在 spawn 时读 .env/config.yaml，
      // 不重启则继续用旧 token，用户会误以为「无法重新配置」）。对齐 telegram/whatsapp 的 qr/apply 行为。
      _triggerGatewayRestart(id + "-bind");
      return new Response(JSON.stringify(Object.assign({ restarting: true }, r)), { headers: jsonHeaders() });
    } catch (e) {
      log(`[ChannelSave] 通道 ${chSaveMatch[1]} 保存失败: ${e?.message || e}`);
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // POST /api/channels/:id/clear → 清空渠道配置（env 凭据 + platforms.<id> 块），并重启网关
  const chClearMatch = path.match(/^\/api\/channels\/([a-zA-Z0-9_]+)\/clear$/);
  if (chClearMatch && req.method === "POST") {
    try {
      const id = chClearMatch[1];
      const def = CHANNEL_DEFS[id];
      if (!def) return new Response(JSON.stringify({ ok: false, error: "unknown channel" }), { status: 400, headers: jsonHeaders() });
      // 1) 清空 .env 中该渠道的全部凭据键
      let env = _readEnvFile();
      (def.fields || []).forEach(f => { if (f.env) env = _setEnvValue(env, f.env, ""); });
      _writeEnvFile(env);
      // 2) 清空 config.yaml 中 platforms.<id> 整块
      _writeHermesConfig(_setPlatformConfig(id, {}));
      log(`[ChannelClear] 渠道 ${id} 配置已清空（env 凭据 + platforms.${id} 块）`);
      _triggerGatewayRestart(id + "-clear");
      return new Response(JSON.stringify({ ok: true, clearing: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // 微信扫码登录：获取二维码（腾讯 iLink 公共接口，无需自备 App）
  // ── 频道绑定：QQ 扫码（Hermes qqbot onboard：create_bind_task / poll_bind_result）──
  if (path === "/api/channels/qqbot/qr" && req.method === "GET") {
    try {
      const key = Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString("base64");
      const r = await fetch("https://q.qq.com/lite/create_bind_task", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json", "User-Agent": "HermesDashboard/1.0" },
        body: JSON.stringify({ key }),
        signal: AbortSignal.timeout(20000),
      });
      const data = await r.json().catch(() => ({}));
      if (data.retcode !== 0) throw new Error(data.msg || "create_bind_task failed");
      const taskId = (data.data || {}).task_id;
      if (!taskId) throw new Error("missing task_id");
      _qqQrCache.set(taskId, { key, createdAt: Date.now() });
      for (const [k, v] of _qqQrCache) if (Date.now() - v.createdAt > 600000) _qqQrCache.delete(k);
      const qrUrl = "https://q.qq.com/qqbot/openclaw/connect.html?task_id=" + encodeURIComponent(taskId) + "&_wv=2&source=hermes";
      return new Response(JSON.stringify({ ok: true, task_id: taskId, qrcode_url: qrUrl, use_render_qr: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message || String(e) }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/channels/qqbot/qr/status" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const taskId = u.searchParams.get("task_id") || "";
      if (!taskId || !_qqQrCache.has(taskId)) return new Response(JSON.stringify({ ok: false, error: "unknown task" }), { status: 404, headers: jsonHeaders() });
      const { key } = _qqQrCache.get(taskId);
      const r = await fetch("https://q.qq.com/lite/poll_bind_result", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json", "User-Agent": "HermesDashboard/1.0" },
        body: JSON.stringify({ task_id: taskId }),
        signal: AbortSignal.timeout(20000),
      });
      const data = await r.json().catch(() => ({}));
      if (data.retcode !== 0) throw new Error(data.msg || "poll failed");
      const d = data.data || {};
      const status = Number(d.status || 0);
      if (status === 2) {
        const slot = Number(u.searchParams.get("slot") || 1);
        const enc = String(d.bot_encrypt_secret || "");
        const keyBuf = Buffer.from(key, "base64");
        const raw = Buffer.from(enc, "base64");
        const iv = raw.slice(0, 12);
        const ctTag = raw.slice(12);
        const k = await crypto.subtle.importKey("raw", keyBuf, "AES-GCM", false, ["decrypt"]);
        const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, k, ctTag);
        const clientSecret = Buffer.from(pt).toString("utf8");
        const appId = String(d.bot_appid || "");
        const openid = String(d.user_openid || "");
        let env = _readEnvFile();
        const cfg = _readPlatformConfig("qqbot");
        cfg.enabled = true;
        cfg.extra = cfg.extra || {};
        if (slot <= 1) {
          // 机器人1（主账号）
          env = _setEnvValue(env, "QQ_APP_ID", appId);
          env = _setEnvValue(env, "QQ_CLIENT_SECRET", clientSecret);
          cfg.extra.app_id = appId;
          cfg.extra.client_secret = clientSecret;
        } else {
          // 机器人 N（2-5）：写入 slot 对应的 env + extra.accounts
          env = _setEnvValue(env, "QQ_APP_ID_" + slot, appId);
          env = _setEnvValue(env, "QQ_CLIENT_SECRET_" + slot, clientSecret);
          if (!Array.isArray(cfg.extra.accounts)) cfg.extra.accounts = [];
          while (cfg.extra.accounts.length < slot - 1) cfg.extra.accounts.push({});
          cfg.extra.accounts[slot - 2] = { app_id: appId, client_secret: clientSecret };
        }
        _writeEnvFile(env);
        cfg.extra.group_policy = "open";
        cfg.extra.dm_policy = "open";
        cfg.updated_at = Date.now();
        _writeHermesConfig(_setPlatformConfig("qqbot", cfg));
        // 自动设置 home channel（消除首次对话提示；cron/跨平台消息投递默认目标）
        try {
          if (openid) {
            const hcCfg = _readPlatformConfig("qqbot");
            hcCfg.home_channel = { platform: "qqbot", chat_id: openid, name: "QQ 绑定会话", user_id: openid };
            _writeHermesConfig(_setPlatformConfig("qqbot", hcCfg));
            log("[QQBot] 已自动设置 home_channel: " + openid);
          }
        } catch (e) { log("[QQBot] home_channel 设置失败: " + e.message); }
        _triggerGatewayRestart("qqbot-bind");
        _qqQrCache.delete(taskId);
        return new Response(JSON.stringify({ ok: true, status: "confirmed", app_id: appId, user_openid: openid }), { headers: jsonHeaders() });
      }
      if (status === 3) return new Response(JSON.stringify({ ok: true, status: "expired" }), { headers: jsonHeaders() });
      return new Response(JSON.stringify({ ok: true, status: "wait" }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message || String(e) }), { status: 500, headers: jsonHeaders() });
    }
  }

  if (path === "/api/channels/weixin/qr" && req.method === "GET") {
    try {
      const res = await fetch("https://ilinkai.weixin.qq.com/ilink/bot/get_bot_qrcode?bot_type=3", { signal: AbortSignal.timeout(15000) });
      const data = await res.json().catch(() => ({}));
      if (!data || !data.qrcode) return new Response(JSON.stringify({ ok: false, error: "无法获取微信二维码，请检查网络后重试" }), { status: 502, headers: jsonHeaders() });
      // iLink 返回的 qrcode_img_content 是一个 deep-link URL（https://liteapp.weixin.qq.com/q/...），不是图片 base64
      const deepLink = data.qrcode_img_content || "";
      return new Response(JSON.stringify({ ok: true, qrcode: data.qrcode, qrcode_url: deepLink, qrcode_img: deepLink, use_render_qr: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 502, headers: jsonHeaders() });
    }
  }
  // 微信扫码登录：轮询扫码状态
  if (path === "/api/channels/weixin/qr/status" && req.method === "GET") {
    try {
      const url = new URL(req.url);
      const qrcode = url.searchParams.get("qrcode") || "";
      if (!qrcode) return new Response(JSON.stringify({ ok: false, error: "缺少 qrcode 参数" }), { status: 400, headers: jsonHeaders() });
      const res = await fetch("https://ilinkai.weixin.qq.com/ilink/bot/get_qrcode_status?qrcode=" + encodeURIComponent(qrcode), { signal: AbortSignal.timeout(35000) });
      const data = await res.json().catch(() => ({}));
      const status = data?.status || "wait";
      if (status === "confirmed") {
        return new Response(JSON.stringify({ ok: true, status, account_id: data.ilink_bot_id, token: data.bot_token, base_url: data.baseurl }), { headers: jsonHeaders() });
      }
      return new Response(JSON.stringify({ ok: true, status }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 502, headers: jsonHeaders() });
    }
  }
  // 企业微信扫码授权：腾讯官方 AI 机器人扫码接口（与 Octop 一致），
  // 无需预先配置 Corp ID / Agent ID / Secret——扫码授权后直接返回 bot_id + secret。
  // GET /api/channels/wecom/qr → 生成二维码（scode + auth_url）
  if (path === "/api/channels/wecom/qr" && req.method === "GET") {
    try {
      const res = await fetch("https://work.weixin.qq.com/ai/qc/generate?source=hermes&plat=3", {
        headers: { "Accept": "application/json" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) throw new Error(`腾讯扫码接口 ${res.status}`);
      const data = await res.json().catch(() => ({}));
      const d = (data && data.data) || {};
      const scode = String(d.scode || "").trim();
      const authUrl = String(d.auth_url || "").trim();
      if (!scode || !authUrl) throw new Error("接口响应缺少 scode/auth_url：" + JSON.stringify(data).slice(0, 200));
      _wecomQrCache.set(scode, { ts: Date.now(), bot_id: "", secret: "" });
      return new Response(JSON.stringify({ ok: true, scode, qr_payload: authUrl, qr_url: authUrl, deep_link: authUrl }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "无法生成企业微信二维码：" + e.message }), { status: 502, headers: jsonHeaders() });
    }
  }
  // GET /api/channels/wecom/qr/status?scode=... → 轮询扫码结果（3s 缓存避免频繁打腾讯接口）
  if (path === "/api/channels/wecom/qr/status" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const scode = (u.searchParams.get("scode") || "").trim();
      if (!scode) return new Response(JSON.stringify({ ok: false, error: "缺少 scode" }), { status: 400, headers: jsonHeaders() });
      const now = Date.now();
      const cached = _wecomQrCache.get(scode);
      if (cached && now - cached.ts < 3000) {
        if (cached.bot_id) return new Response(JSON.stringify({ ok: true, status: "ready", bot_id: cached.bot_id, secret: cached.secret }), { headers: jsonHeaders() });
        return new Response(JSON.stringify({ ok: true, status: "waiting" }), { headers: jsonHeaders() });
      }
      const res = await fetch("https://work.weixin.qq.com/ai/qc/query_result?scode=" + encodeURIComponent(scode), {
        headers: { "Accept": "application/json" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) throw new Error(`腾讯扫码接口 ${res.status}`);
      const data = await res.json().catch(() => ({}));
      const d = (data && data.data) || {};
      const status = String(d.status || "pending").trim();
      if (status === "success") {
        const botId = String((d.bot_info && d.bot_info.botid) || "").trim();
        const secret = String((d.bot_info && d.bot_info.secret) || "").trim();
        if (!botId || !secret) throw new Error("扫码成功但缺少 bot 信息");
        _wecomQrCache.set(scode, { ts: now, bot_id: botId, secret });
        return new Response(JSON.stringify({ ok: true, status: "ready", bot_id: botId, secret }), { headers: jsonHeaders() });
      }
      if (status === "error" || status === "expired") {
        return new Response(JSON.stringify({ ok: false, error: String(d.message || ("扫码" + status + "，请重新获取二维码")) }), { status: 410, headers: jsonHeaders() });
      }
      _wecomQrCache.set(scode, { ts: now, bot_id: "", secret: "" });
      return new Response(JSON.stringify({ ok: true, status: "waiting" }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "轮询企业微信状态失败：" + e.message }), { status: 502, headers: jsonHeaders() });
    }
  }
  // POST /api/channels/wecom/qr/apply → 保存 bot_id + secret 并启用平台（自动重启网关生效）
  if (path === "/api/channels/wecom/qr/apply" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const scode = String(body.scode || "").trim();
      const cached = scode ? _wecomQrCache.get(scode) : null;
      const botId = String(body.bot_id || (cached && cached.bot_id) || "").trim();
      const secret = String(body.secret || (cached && cached.secret) || "").trim();
      if (!botId || !secret) return new Response(JSON.stringify({ ok: false, error: "缺少 bot_id / secret，请先完成扫码授权" }), { status: 400, headers: jsonHeaders() });
      let env = _readEnvFile();
      env = _setEnvValue(env, "WECOM_BOT_ID", botId);
      env = _setEnvValue(env, "WECOM_SECRET", secret);
      _writeEnvFile(env);
      const cfg = _readPlatformConfig("wecom");
      cfg.enabled = true;
      cfg.extra = cfg.extra || {};
      cfg.extra.bot_id = botId;
      cfg.extra.secret = secret;
      cfg.updated_at = Date.now();
      _writeHermesConfig(_setPlatformConfig("wecom", cfg));
      // 自动启用 hermes-wecom 插件 toolset（网关需要此条目才加载 wecom 平台模块）
      try {
        let y2 = _readHermesConfig();
        const curTs = _extractYamlList(y2, "toolsets");
        if (!curTs.includes("hermes-wecom")) {
          curTs.push("hermes-wecom");
          _writeHermesConfig(_setYamlListBlock(y2, "toolsets", curTs));
          log(`[ChannelToolset] wecom QR apply: 自动启用 hermes-wecom`);
        }
      } catch (e) { log(`[ChannelToolset] wecom QR toolset 启用失败: ${e.message}`); }
      if (scode) _wecomQrCache.delete(scode);
      _triggerGatewayRestart("wecom-bind");
      return new Response(JSON.stringify({ ok: true, bot_id: botId, restart_required: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── 标记配置已改，等待正式应用重启生效 ─────────────────────────────────
  // 用于频道绑定 / 技能安装 / profile 切换 / 扩展配置等写完 config.yaml 或 .env 之后。
  // 本函数**不重启任何进程**，只做两件事：
  //   1. panelRuntime.changed(reason) 把这次改动记进变更清单（changes[]）
  //   2. 打一行日志
  // 真正重启由 server/panel-restart-ingress.js 负责：前端 panel-runtime-ui.js 读到
  // changes.length 后显示「N 项配置已保存，重启应用后生效」+「重启应用并生效」按钮，
  // 点击打 POST /proxy/dashboard/api/gateway/restart → runtime.requestRestart()
  // → fnos-cli app restart hermes-agent --yes，并用 restart ledger 判定成败。
  //
  // 历史（留着，免得有人照着旧注释改回去）：
  //   - 更早一版 POST Dashboard /api/gateway/restart，依赖 systemd user service；
  //     fnOS 未启用 linger，重启静默失败（gateway-restart.log:
  //     "Cannot restart gateway as a service — linger is not enabled"）。
  //   - 再之后改成直接杀 gateway 进程 + 重启，会掐断正在跑的会话，已废弃。
  //
  // 遗留：_gwRestartTimer / _gwRestartInProgress 两个模块级变量（line ~806）已无引用，
  // 留着是为了不碰无关代码；下次动这个模块时可以一并清掉。
  function _triggerGatewayRestart(reason) {
    panelRuntime.changed(reason||'配置修改');
    log('[config] 配置已保存，等待通过正式应用重启生效');
  }

  // 启动时自动注册已由模块级 _moduleLevelAutoRegisterMcp() 完成，此处无需重复

  // ── Telegram 扫码创建机器人 ───────────────────────────────────────────
  // GET /api/channels/telegram/qr  → 创建配对，返回 deep_link/qr_payload
  if (path === "/api/channels/telegram/qr" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const botName = (u.searchParams.get("bot_name") || "Hermes Agent").trim() || "Hermes Agent";
      const res = await fetch(`${TELEGRAM_ONBOARDING_URL}/v1/telegram/pairings`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify({ bot_name: botName }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) throw new Error(`onboarding service ${res.status}`);
      const data = await res.json().catch(() => ({}));
      const pairingId = String(data.pairing_id || "").trim();
      const pollToken = String(data.poll_token || "").trim();
      const expiresAt = String(data.expires_at || "").trim();
      const deepLink  = String(data.deep_link || "").trim();
      const qrPayload = String(data.qr_payload || deepLink || "").trim();
      if (!pairingId || !pollToken || !expiresAt || !deepLink) throw new Error("incomplete onboarding response");
      let expiresTs = Date.now() + 600000;
      try { const d = new Date(expiresAt.replace("Z", "+00:00")); if (!isNaN(d)) expiresTs = d.getTime(); } catch {}
      _pruneTelegramPairings();
      _telegramPairings.set(pairingId, { poll_token: pollToken, expires_at_ts: expiresTs, bot_token: null, bot_username: null, owner_user_id: null });
      return new Response(JSON.stringify({ ok: true, pairing_id: pairingId, qr_payload: qrPayload, deep_link: deepLink, expires_at: expiresAt }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "无法创建 Telegram 配对：" + e.message }), { status: 502, headers: jsonHeaders() });
    }
  }
  // GET /api/channels/telegram/qr/status?pairing_id=...
  if (path === "/api/channels/telegram/qr/status" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const pairingId = (u.searchParams.get("pairing_id") || "").trim();
      if (!pairingId) return new Response(JSON.stringify({ ok: false, error: "缺少 pairing_id" }), { status: 400, headers: jsonHeaders() });
      _pruneTelegramPairings();
      const rec = _telegramPairings.get(pairingId);
      if (!rec) return new Response(JSON.stringify({ ok: false, error: "配对会话不存在或已过期" }), { status: 404, headers: jsonHeaders() });
      if (rec.bot_token) return new Response(JSON.stringify({ ok: true, status: "ready", bot_username: rec.bot_username, owner_user_id: rec.owner_user_id }), { headers: jsonHeaders() });
      const res = await fetch(`${TELEGRAM_ONBOARDING_URL}/v1/telegram/pairings/${encodeURIComponent(pairingId)}`, {
        headers: { "Authorization": `Bearer ${rec.poll_token}`, "Accept": "application/json" },
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) throw new Error(`onboarding service ${res.status}`);
      const data = await res.json().catch(() => ({}));
      const status = String(data.status || "").trim();
      if (status === "waiting") return new Response(JSON.stringify({ ok: true, status: "waiting" }), { headers: jsonHeaders() });
      if (status === "ready") {
        const token = String(data.token || "").trim();
        if (!token) throw new Error("missing token in ready response");
        const botUsername = String(data.bot_username || "").trim() || null;
        const ownerId = (() => { const v = data.owner_user_id; if (typeof v === "number" && v > 0) return String(v); if (typeof v === "string" && /^\d+$/.test(v)) return v; return null; })();
        rec.bot_token = token; rec.bot_username = botUsername; rec.owner_user_id = ownerId;
        return new Response(JSON.stringify({ ok: true, status: "ready", bot_username: botUsername, owner_user_id: ownerId }), { headers: jsonHeaders() });
      }
      if (["expired", "claimed"].includes(status)) {
        _telegramPairings.delete(pairingId);
        return new Response(JSON.stringify({ ok: false, error: "配对已" + status + "，请重新扫码" }), { status: 410, headers: jsonHeaders() });
      }
      return new Response(JSON.stringify({ ok: true, status: "waiting" }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "轮询 Telegram 状态失败：" + e.message }), { status: 502, headers: jsonHeaders() });
    }
  }
  // POST /api/channels/telegram/qr/apply  → 保存 token + allowed_user_ids + 启用平台
  if (path === "/api/channels/telegram/qr/apply" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const pairingId = String(body.pairing_id || "").trim();
      const rawAllowed = Array.isArray(body.allowed_user_ids) ? body.allowed_user_ids : String(body.allowed_user_ids || "").split(/[,;\s]+/);
      const allowedUserIds = [];
      for (const v of rawAllowed) {
        const norm = _normalizeTelegramUserId(v);
        if (norm && !allowedUserIds.includes(norm)) allowedUserIds.push(norm);
      }
      if (!pairingId) return new Response(JSON.stringify({ ok: false, error: "缺少 pairing_id" }), { status: 400, headers: jsonHeaders() });
      if (allowedUserIds.length === 0) return new Response(JSON.stringify({ ok: false, error: "请至少填写一个允许的 Telegram 用户 ID（数字）" }), { status: 400, headers: jsonHeaders() });
      _pruneTelegramPairings();
      const rec = _telegramPairings.get(pairingId);
      if (!rec) return new Response(JSON.stringify({ ok: false, error: "配对会话不存在或已过期" }), { status: 404, headers: jsonHeaders() });
      if (!rec.bot_token) return new Response(JSON.stringify({ ok: false, error: "机器人尚未创建完成，请稍后再试" }), { status: 409, headers: jsonHeaders() });
      let env = _readEnvFile();
      env = _setEnvValue(env, "TELEGRAM_BOT_TOKEN", rec.bot_token);
      env = _setEnvValue(env, "TELEGRAM_ALLOWED_USERS", allowedUserIds.join(","));
      _writeEnvFile(env);
      const cfg = _readPlatformConfig("telegram");
      cfg.enabled = true;
      // 同步 allow_from 到 config.yaml：与上游 bootstrap 约定一致，
      // 即使 .env 被重建，白名单也能从配置恢复（双保险）。
      cfg.allow_from = allowedUserIds.join(",");
      cfg.updated_at = Date.now();
      _writeHermesConfig(_setPlatformConfig("telegram", cfg));
      _telegramPairings.delete(pairingId);
      // ── 关键安全修复 ──
      // 写入 TELEGRAM_ALLOWED_USERS 后必须重启网关，否则正在运行的网关
      // 不会加载新的白名单，导致任意 Telegram 帐号都能私聊操控机器人
      // （含授权 root 等高危操作）。见上游 adapter._is_user_authorized_from_message。
      _triggerGatewayRestart("telegram-bind");
      return new Response(JSON.stringify({ ok: true, bot_username: rec.bot_username, restart_required: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── WhatsApp 扫码配对 ─────────────────────────────────────────────────
  // GET /api/channels/whatsapp/qr?mode=bot|self-chat
  if (path === "/api/channels/whatsapp/qr" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const mode = ["bot", "self-chat"].includes(u.searchParams.get("mode")) ? u.searchParams.get("mode") : "self-chat";
      if (!resolvedNodeBin) return new Response(JSON.stringify({ ok: false, error: "未找到 Node.js，无法启动 WhatsApp bridge" }), { status: 500, headers: jsonHeaders() });
      const pairingId = randomBytes(16).toString("hex");
      const sessionDir = `${WHATSAPP_SESSION_DIR}/${pairingId}`;
      const expiresTs = Date.now() + WHATSAPP_ONBOARDING_TTL;
      let initialQr = "";
      // 如果已有 creds.json，视为已配对，直接返回 connected（与官方行为一致）
      if (existsSync(`${sessionDir}/creds.json`)) {
        _pruneWhatsAppPairings();
        _whatsappPairings.set(pairingId, { proc: null, status: "connected", qr_payload: "", mode, account_id: null, account_name: null, account_phone: null, error: null, expires_at_ts: expiresTs });
        return new Response(JSON.stringify({ ok: true, pairing_id: pairingId, status: "connected" }), { headers: jsonHeaders() });
      }
      const proc = _spawnWhatsAppPairing(sessionDir, mode);
      _pruneWhatsAppPairings();
      _whatsappPairings.set(pairingId, { proc, status: "starting", qr_payload: "", mode, account_id: null, account_name: null, account_phone: null, error: null, expires_at_ts: expiresTs });
      _watchWhatsAppPairing(pairingId, proc);
      // 等待一小段时间让 QR 出来（bridge 启动通常 1-3 秒）
      for (let i = 0; i < 30 && !initialQr; i++) { await new Promise(r => setTimeout(r, 200)); initialQr = (_whatsappPairings.get(pairingId) || {}).qr_payload || ""; }
      return new Response(JSON.stringify({ ok: true, pairing_id: pairingId, status: initialQr ? "waiting" : "starting", qr_payload: initialQr }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "无法启动 WhatsApp 配对：" + e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // GET /api/channels/whatsapp/qr/status?pairing_id=...
  if (path === "/api/channels/whatsapp/qr/status" && req.method === "GET") {
    try {
      const u = new URL(req.url, "http://localhost");
      const pairingId = (u.searchParams.get("pairing_id") || "").trim();
      if (!pairingId) return new Response(JSON.stringify({ ok: false, error: "缺少 pairing_id" }), { status: 400, headers: jsonHeaders() });
      _pruneWhatsAppPairings();
      const rec = _whatsappPairings.get(pairingId);
      if (!rec) return new Response(JSON.stringify({ ok: false, error: "配对会话不存在或已过期" }), { status: 404, headers: jsonHeaders() });
      if (rec.status === "expired") return new Response(JSON.stringify({ ok: false, error: rec.error || "二维码已过期" }), { status: 410, headers: jsonHeaders() });
      return new Response(JSON.stringify({
        ok: true, status: rec.status, qr_payload: rec.qr_payload,
        account_id: rec.account_id, account_name: rec.account_name, account_phone: rec.account_phone,
        error: rec.error
      }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  // POST /api/channels/whatsapp/qr/apply  → 保存 mode/allowed_users + 启用平台
  if (path === "/api/channels/whatsapp/qr/apply" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const pairingId = String(body.pairing_id || "").trim();
      if (!pairingId) return new Response(JSON.stringify({ ok: false, error: "缺少 pairing_id" }), { status: 400, headers: jsonHeaders() });
      _pruneWhatsAppPairings();
      const rec = _whatsappPairings.get(pairingId);
      if (!rec) return new Response(JSON.stringify({ ok: false, error: "配对会话不存在或已过期" }), { status: 404, headers: jsonHeaders() });
      if (rec.status !== "connected") return new Response(JSON.stringify({ ok: false, error: "WhatsApp 尚未配对完成" }), { status: 409, headers: jsonHeaders() });
      const allowedUsers = _normalizeWhatsAppAllowedUsers(body.allowed_users != null ? body.allowed_users : (rec.account_phone || ""));
      let env = _readEnvFile();
      env = _setEnvValue(env, "WHATSAPP_MODE", rec.mode || "self-chat");
      env = _setEnvValue(env, "WHATSAPP_DM_POLICY", "pairing");
      if (allowedUsers) env = _setEnvValue(env, "WHATSAPP_ALLOWED_USERS", allowedUsers);
      env = _setEnvValue(env, "WHATSAPP_ENABLED", "true");
      _writeEnvFile(env);
      const cfg = _readPlatformConfig("whatsapp");
      cfg.enabled = true;
      cfg.allow_from = allowedUsers || "";
      cfg.updated_at = Date.now();
      _writeHermesConfig(_setPlatformConfig("whatsapp", cfg));
      _whatsappPairings.delete(pairingId);
      // 同 Telegram：写入 WHATSAPP_ALLOWED_USERS 后重启网关，确保白名单生效
      _triggerGatewayRestart("whatsapp-bind");
      return new Response(JSON.stringify({ ok: true, account_id: rec.account_id, account_name: rec.account_name, restart_required: true }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── 诊断端点：查看 MCP 配置状态 ──
  if (path === "/api/debug/mcp-status" && req.method === "GET") {
    if (!checkToken(req)) return new Response(JSON.stringify({ok:false,error:'请重新登录后查看诊断状态'}), {status:401,headers:jsonHeaders()});
    try {
      const yml = _readHermesConfig();
      const mcpBlock = _yamlBlockOf(yml, "mcp_servers");
      const parsed = _parseMcpServers(yml);
      const st = _readConnectorsState();
      const gwConns = CONNECTOR_CATALOG.filter(function (c) { return c.mcp_mode === "gateway"; }).map(function (c) {
        const creds = st[c.kind] || {};
        return { kind: c.kind, name: c.name, has_creds: (c.fields || []).every(function (f) { return !!creds[f.key]; }), mcp_name: "conn-" + c.kind, in_config: !!parsed["conn-" + c.kind] };
      });
      return new Response(JSON.stringify({
        ok: true,
        hermes_config_path: HERMES_CONFIG,
        bridge_script_path: MCP_BRIDGE_SCRIPT,
        bridge_script_exists: existsSync(MCP_BRIDGE_SCRIPT),
        resolved_node_bin: resolvedNodeBin || null,
        ui_port: UI_PORT,
        mcp_servers_in_config: Object.keys(parsed).map(name => ({name, transport: parsed[name].url ? 'remote' : 'stdio', configured: true})),
        gateway_connectors: gwConns
      }, null, 2), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  const connectorToolResponse = await handleConnectorTools(req, path);
  if (connectorToolResponse) return connectorToolResponse;

  // 连接器配置由单一版本化状态服务处理；旧凭证仍留在原位置。
  const connectorResponse = await handleConnectorConfig(req, path, async (cat, creds) => {
    if (!creds) {
      _upsertMcpServer(cat.mcp_mode === 'remote' ? cat.kind : 'conn-' + cat.kind, null);
    } else if (cat.mcp_mode === 'remote') {
      const tokenField = (cat.fields || []).find(f => f.key === 'token' || f.key === 'api_key');
      const headers = tokenField ? {Authorization: 'Bearer ' + creds[tokenField.key]} : {};
      if (cat.kind === 'tencent-lexiang' && creds.company_from) headers['X-Company-From'] = creds.company_from;
      _upsertMcpServer(cat.kind, {url: cat.mcp_url, headers});
    } else {
      _ensureMcpBridgeScript();
      _upsertMcpServer('conn-' + cat.kind, {command: resolvedNodeBin || 'node', args: [MCP_BRIDGE_SCRIPT, cat.kind, String(UI_PORT)]});
    }
    _triggerGatewayRestart('connector-' + cat.kind);
    return {activation:'pending_restart'};
  });
  if (connectorResponse) return connectorResponse;
  const probeResponse = await createConnectorProbeHandler({checkToken, getConnector, readState: _readConnectorsState, probe: probeConnector})(req, path);
  if (probeResponse) return probeResponse;
  // Compatibility for remaining extension controls only. Model writes have a
  // separate versioned endpoint and can never ride along in this request.
  if(path==='/api/config'&&req.method==='POST'){
    const body=await req.json();
    if(!body.extensions||typeof body.extensions!=='object'||Array.isArray(body.extensions))return new Response(JSON.stringify({ok:false,error:'请刷新面板后使用模型配置编辑器'}),{status:410,headers:jsonHeaders()});
    const original=_readExtensionsFile()||{};
    if(body.extensions_revision!==createHash('sha256').update(JSON.stringify(original)).digest('hex'))return new Response(JSON.stringify({ok:false,error:'扩展配置已变化，请刷新后重试'}),{status:409,headers:jsonHeaders()});
    // Native tool/memory settings will be replaced by dedicated editors. Do not
    // rewrite MCP, providers, credentials or global defaults from UI snapshots.
    const content=_readHermesConfig();let updated=content;
    const extension=body.extensions;
    if(extension.toolsets){let list=_extractYamlList(content,'toolsets');for(const [key,on] of Object.entries(extension.toolsets)){if(on&&!list.includes(key))list.push(key);}updated=_setYamlListBlock(updated,'toolsets',list);}
    if(extension.memory)updated=_setYamlFlatMap(updated,'memory',{memory_enabled:extension.memory.enabled!==false,memory_char_limit:parseInt(extension.memory.char_limit,10)||2200});
    if(updated!==content){_writeHermesConfig(updated);_triggerGatewayRestart('扩展配置');}
    _writeExtensionsFile(extension);
    return new Response(JSON.stringify({ok:true,restart_required:updated!==content,extensions_revision:createHash('sha256').update(JSON.stringify(extension)).digest('hex')}),{headers:jsonHeaders()});
  }

  // ─── 主模型 API（读写 config.yaml 中的 model.provider + model.default） ──
  // Older auxiliary editors had destructive text rewrites. Only versioned structured updates are accepted.
  if (path === '/api/config/vision' || path === '/api/auxiliary/tasks') {
    return new Response(JSON.stringify({ok:false,error:'辅助模型已使用统一编辑器，请刷新面板后操作'}), {status:410,headers:jsonHeaders()});
  }

  if(['/api/config/primary-model','/api/config/restore-default-model','/api/provider-key','/api/config/test'].includes(path)){
    return new Response(JSON.stringify({ok:false,error:'此旧接口已关闭，请刷新面板使用模型配置与响应验证'}),{status:410,headers:jsonHeaders()});
  }
  if(path==='/api/models'&&req.method==='GET'){
    const config=await getChatConfig();
    return new Response(JSON.stringify({ok:true,models:config.providers.filter(p=>p.enabled).flatMap(p=>p.models.filter(m=>m.enabled).map(m=>({...m,provider:p.id})))}),{headers:jsonHeaders()});
  }

  // ─── 聊天：会话 API ────────────────────────────────────────────────────
  if (path === "/api/sessions" && req.method === "GET") {
    return new Response(JSON.stringify({ sessions: listSessions() }), { headers: jsonHeaders() });
  }

  if (path === "/api/sessions" && req.method === "POST") {
    const s = {
      id: crypto.randomUUID(),
      title: "New Chat",
      messages: [],
      created_at: Date.now(),
      updated_at: Date.now(),
    };
    saveSession(s);
    return new Response(JSON.stringify(s), { headers: jsonHeaders() });
  }

  // 会话重命名：改会话 JSON 的 title 并同步内存缓存（列表/标签页即时刷新）
  if (path === "/api/sessions/rename" && req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    const sid = String(body.id || "").trim();
    const title = String(body.title || "").trim().slice(0, 200);
    if (!sid || !title) {
      return new Response(JSON.stringify({ ok: false, error: "id 和 title 必填" }), { status: 400, headers: jsonHeaders() });
    }
    const f = sessionFile(sid);
    if (!existsSync(f)) {
      return new Response(JSON.stringify({ ok: false, error: "会话不存在" }), { status: 404, headers: jsonHeaders() });
    }
    try {
      const s = readJSON(f);
      s.title = title;
      s.updated_at = Date.now();
      writeJSON(f, s);
      if (_sessionMetaCache) _sessionMetaCache.map.set(s.id, _sessionMetaFromData(s));
      return new Response(JSON.stringify({ ok: true, id: sid, title }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "重命名失败: " + e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ── POST /api/sessions/fork —— 从某条消息 fork 出新会话（2026-11-24）──────
  // 语义：新会话 = 源会话里这条消息 **及它之前的全部消息**（标准 branch 语义）。
  // 旧实现是前端 forkMsg 把这一条气泡的文字画成引用块，新会话在后端其实是空的 ——
  // 模型下一轮什么都看不到。用户 2026-11-24 追问「fork 到底带不带上文」，查证为不带，
  // 这里改成真的复制 messages[0..idx]，上下文进新会话自己的 JSON。
  // 定位：优先 upto_ts（消息时间戳，前端 .msg 的 data-ts）；退化到 upto_index；都给不出就全带。
  if (path === "/api/sessions/fork" && req.method === "POST") {
    let fbody = {};
    try { fbody = await req.json(); } catch (_) { fbody = {}; }
    const fromId = String(fbody.from || "").trim();
    if (!fromId) return new Response(JSON.stringify({ ok: false, error: "from 必填" }), { status: 400, headers: jsonHeaders() });
    const srcFile = sessionFile(fromId);
    if (!existsSync(srcFile)) return new Response(JSON.stringify({ ok: false, error: "源会话不存在" }), { status: 404, headers: jsonHeaders() });
    let src;
    try { src = readJSON(srcFile); } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: "读取源会话失败: " + e.message }), { status: 500, headers: jsonHeaders() });
    }
    const all = Array.isArray(src.messages) ? src.messages : [];
    const wantTs = fbody.upto_ts != null && String(fbody.upto_ts) !== "" ? String(fbody.upto_ts) : "";
    let cut = all.length - 1;
    if (wantTs) {
      const hit = all.findIndex(m => m && String(m.ts) === wantTs);
      if (hit >= 0) cut = hit;
    } else if (Number.isInteger(fbody.upto_index)) {
      cut = Math.max(0, Math.min(all.length - 1, fbody.upto_index));
    }
    const kept = all.slice(0, cut + 1).map(m => {
      /* queue_status 是「这一轮跑没跑完」的实时状态，复制过去会污染新会话的生成条判断；
         其余字段（tools / sender / request_id）原样保留，执行记录在新会话里照样能看。 */
      const c = Object.assign({}, m);
      delete c.queue_status;
      return c;
    });
    const newS = {
      id: crypto.randomUUID(),
      title: ("branch: " + String(src.title || "新话题")).slice(0, 80),
      messages: kept,
      created_at: Date.now(),
      updated_at: Date.now(),
      forked_from: fromId,
      forked_at_ts: wantTs || null,
    };
    saveSession(newS);
    return new Response(JSON.stringify({ ok: true, session: newS, copied: kept.length, total: all.length }), { headers: jsonHeaders() });
  }

  // ── POST /api/chat/compress —— 面板会话真压缩（2026-11-13）───────────────
  // 面板上下文真身是 chat/sessions/<id>.json 的 messages，压缩由 python 脚本落地：
  // 早段消息换成语义摘要、保留最近一批、写回同一 session（id 不变），原文件先备份。
  // 之前 /compress 是假命令（只往对话里塞一句"帮我写摘要"），这里才是真入口。
  if (path === "/api/chat/compress" && req.method === "POST") {
    let _cbody = {};
    try { _cbody = await req.json(); } catch (_) { _cbody = {}; }
    const _csid = String(_cbody.session_id || "").trim();
    if (_csid && activeChatStreams.has(_csid)) {
      return new Response(JSON.stringify({ ok: false, error: "这个会话正在生成回复，等这一轮结束再压缩" }), { status: 409, headers: jsonHeaders() });
    }
    if (!_chatCompress) {
      _chatCompress = createChatCompress({ sessionsDir: SESSIONS_DIR, dataDir: DATA_DIR, serverDir: dirname(fileURLToPath(import.meta.url)), log });
    }
    const _cres = await _chatCompress(_cbody);
    return new Response(JSON.stringify(_cres.json), { status: _cres.status, headers: jsonHeaders() });
  }

  // 匹配 /api/sessions/:id/usage
  const usageMatch = path.match(/^\/api\/sessions\/([^/]+)\/usage$/);
  if (usageMatch && req.method === "GET") {
    const sid = decodeURIComponent(usageMatch[1]);
    const s = getSession(sid);
    if (!s) return new Response(JSON.stringify({ error: "not found" }), { status: 404, headers: jsonHeaders() });
    const ext = _readExtensionsFile() || { toolsets: {}, skills_dirs: [], persona: "default", memory: { enabled: true, char_limit: 2200 } };
    // 统计本地已安装技能数量
    let localSkillCount = 0;
    try {
      const dirs = ext.skills_dirs || [];
      for (const d of dirs) {
        if (existsSync(d)) {
          const files = readdirSync(d);
          localSkillCount += files.filter(f => f.toLowerCase() === "skill.md").length;
        }
      }
    } catch {}
    // 读取长期记忆文本（如果 memory 启用）
    let memoryText = "";
    if (ext.memory && ext.memory.enabled) {
      try {
        const memPath = `${DATA_DIR}/memories/MEMORY.md`;
        const userPath = `${DATA_DIR}/memories/USER.md`;
        if (existsSync(memPath)) memoryText += readFileSync(memPath, "utf8");
        if (existsSync(userPath)) memoryText += readFileSync(userPath, "utf8");
      } catch {}
    }
    const persona = EXT_PERSONAS[ext.persona] || {};
    const usage = computeSessionUsage(s, {
      extensions: ext,
      persona,
      systemPrompt: UI_CAPABILITIES_PROMPT,
      memoryText,
      localSkillCount,
      contextWindow: DEFAULT_CONTEXT_WINDOW,
    });
    return new Response(JSON.stringify({ ok: true, usage }), { headers: jsonHeaders() });
  }

  // 匹配 /api/sessions/:id/sync —— 多端同步签名（几十字节，前端轮询检测变化）
  const syncMatch = path.match(/^\/api\/sessions\/([^/]+)\/sync$/);
  if (syncMatch && req.method === "GET") {
    const sid = decodeURIComponent(syncMatch[1]);
    const sig = sessionSig(sid);
    if (sig === null) return new Response(JSON.stringify({ error: "not found" }), { status: 404, headers: jsonHeaders() });
    return new Response(JSON.stringify({ ok: true, sig }), { headers: jsonHeaders() });
  }

  // 归档列表必须先于 /api/sessions/:id，避免把 archived 当成普通会话 ID。
  if (path === "/api/sessions/archived" && req.method === "GET") {
    return new Response(JSON.stringify({sessions: Array.from(_buildArchivedMetaMap().values()).sort((a,b)=>b.updated_at-a.updated_at)}), {headers: jsonHeaders()});
  }
  const restoreMatch = path.match(/^\/api\/sessions\/([^/]+)\/restore$/);
  if (restoreMatch && req.method === "POST") {
    try { const s = restoreSession(decodeURIComponent(restoreMatch[1])); return new Response(JSON.stringify({ok:true,session:_sessionMetaFromData(s)}), {headers: jsonHeaders()}); }
    catch (e) { return new Response(JSON.stringify({error:e.message || '恢复失败'}), {status:e.status || 500, headers: jsonHeaders()}); }
  }

  // 彻底删除归档会话（批量）。必须先于 /api/sessions/:id，且复用 archived 前缀避免误判。
  if (path === "/api/sessions/archived/purge" && req.method === "POST") {
    let ids = [];
    try { const b = await req.json(); ids = Array.isArray(b && b.ids) ? b.ids : []; }
    catch { return new Response(JSON.stringify({error: "invalid body"}), {status: 400, headers: jsonHeaders()}); }
    ids = ids.map(x => String(x || "").trim()).filter(Boolean);
    if (!ids.length) return new Response(JSON.stringify({error: "没有选中会话"}), {status: 400, headers: jsonHeaders()});
    const results = ids.map(id => { try { purgeArchivedSession(id); return {id, ok: true}; } catch (e) { return {id, ok: false, error: e.message || "删除失败"}; } });
    const purged = results.filter(r => r.ok).length;
    return new Response(JSON.stringify({ok: purged > 0, purged, failed: results.length - purged, results}), {headers: jsonHeaders()});
  }

  // 压缩原文归档：跟「已归档会话」同一个弹窗、同一条彻底删除路径（先于 /api/sessions/:id）
  if (path === "/api/sessions/compressed" && req.method === "GET") {
    return new Response(JSON.stringify({ ok: true, sessions: listCompressedArchives() }), { headers: jsonHeaders() });
  }
  if (path === "/api/sessions/compressed/batch" && req.method === "GET") {
    const q = new URL(req.url, "http://127.0.0.1").searchParams;
    try { return new Response(JSON.stringify({ ok: true, batch: readCompressedBatch(q.get("id") || "", q.get("file") || "") }), { headers: jsonHeaders() }); }
    catch (e) { return new Response(JSON.stringify({ error: e.message || "读取失败" }), { status: e.status || 500, headers: jsonHeaders() }); }
  }
  if (path === "/api/sessions/compressed/delete" && req.method === "POST") {
    let b = {};
    try { b = await req.json(); } catch { return new Response(JSON.stringify({ error: "invalid body" }), { status: 400, headers: jsonHeaders() }); }
    try { const r = deleteCompressedBatch(String(b.id || ""), String(b.file || "")); return new Response(JSON.stringify({ ok: true, ...r }), { headers: jsonHeaders() }); }
    catch (e) { return new Response(JSON.stringify({ error: e.message || "删除失败" }), { status: e.status || 500, headers: jsonHeaders() }); }
  }
  if (path === "/api/sessions/compressed/purge" && req.method === "POST") {
    let b = {};
    try { b = await req.json(); } catch { return new Response(JSON.stringify({ error: "invalid body" }), { status: 400, headers: jsonHeaders() }); }
    try { purgeCompressedArchives(String(b.id || "")); return new Response(JSON.stringify({ ok: true }), { headers: jsonHeaders() }); }
    catch (e) { return new Response(JSON.stringify({ error: e.message || "删除失败" }), { status: e.status || 500, headers: jsonHeaders() }); }
  }

  // 匹配 /api/sessions/:id
  const sessionMatch = path.match(/^\/api\/sessions\/([^/]+)$/);
  if (sessionMatch) {
    const sid = decodeURIComponent(sessionMatch[1]);
    if (req.method === "GET") {
      const s = getSession(sid);
      if (!s) return new Response(JSON.stringify({ error: "not found" }), { status: 404, headers: jsonHeaders() });
      sweepZombieStreams(s); // 加载时清扫僵尸流式消息（gateway 重启/任务卡死遗留的半截消息）
      if (retainStickers(s)) atomicWriteJSON(sessionFile(sid),s);
      /* 窗口取数（2026-11-20）：长会话/多图会话一次吐全部消息，前端要新建几百个气泡、
         输入框被主线程卡住 2~3 秒。这里支持 ?tail=N（最后 N 条）与 ?from=i&limit=n（往前翻页），
         只在带了参数时才切片，无参数的老行为一字不变（其它调用方不受影响）。 */
      let _u = null;
      try { _u = new URL(req.url, "http://monitor.local"); } catch { _u = null; }
      const _q = _u ? _u.searchParams : null;
      const _total = Array.isArray(s.messages) ? s.messages.length : 0;
      const _int = (k) => { const v = parseInt((_q && _q.get(k)) || "", 10); return Number.isFinite(v) && v >= 0 ? v : null; };
      const _tail = _int("tail"), _from = _int("from"), _limit = _int("limit");
      let _start = 0, _end = _total;
      if (_tail !== null && _tail > 0 && _from === null) _start = Math.max(0, _total - _tail);
      else if (_from !== null) _start = Math.min(_from, _total);
      if (_limit !== null && _limit > 0) _end = Math.min(_total, _start + _limit);
      if (_start > 0 || _end < _total) {
        return new Response(JSON.stringify({ ...s, messages: s.messages.slice(_start, _end), _win: { total: _total, from: _start, to: _end } }), { headers: jsonHeaders() });
      }
      return new Response(JSON.stringify(s), { headers: jsonHeaders() });
    }
    if (req.method === "POST") {
      // resume：把未完成的 streaming checkpoint 消息标记为完成，便于用户继续对话
      const s = getSession(sid);
      if (!s) return new Response(JSON.stringify({ error: "not found" }), { status: 404, headers: jsonHeaders() });
      const last = s.messages[s.messages.length - 1];
      let resumed = false;
      if (last && last.role === "assistant" && last._streaming) {
        delete last._streaming;
        last.ts = Date.now();
        saveSession(s);
        resumed = true;
      }
      return new Response(JSON.stringify({ ok: true, resumed, session: s }), { headers: jsonHeaders() });
    }
    if (req.method === "DELETE") {
      try { archiveSession(sid); return new Response(JSON.stringify({ ok: true, archived: true }), { headers: jsonHeaders() }); }
      catch (e) { return new Response(JSON.stringify({ error: e.message || '归档失败' }), { status: e.status || 500, headers: jsonHeaders() }); }
    }
    if (req.method === "PATCH") {
      const s = getSession(sid);
      if (!s) return new Response(JSON.stringify({ error: "not found" }), { status: 404, headers: jsonHeaders() });
      try {
        const body = await req.json();
        if (typeof body.title === "string" && body.title.trim()) {
          s.title = body.title.trim().slice(0, 200);
          saveSession(s);
        }
      } catch { return new Response(JSON.stringify({ error: "invalid body" }), { status: 400, headers: jsonHeaders() }); }
      return new Response(JSON.stringify({ ok: true, title: s.title }), { headers: jsonHeaders() });
    }
  }


  // ─── 安全网关设置（tool_guard 开关，持久化 data/studio/security.json）──────
  if (path === "/api/studio/security" && req.method === "GET") {
    return new Response(JSON.stringify({ enabled: _toolGuardEnabled, blockRules: TOOL_GUARD_BLOCK_RULES.length, warnRules: TOOL_GUARD_WARN_RULES.length }), { headers: jsonHeaders() });
  }
  if (path === "/api/studio/security" && req.method === "PUT") {
    const body = await req.json().catch(() => ({}));
    _toolGuardEnabled = body.enabled !== false;
    toolGuardSave();
    log(`[tool-guard] 已切换为 ${_toolGuardEnabled ? "开启" : "关闭"}`);
    return new Response(JSON.stringify({ ok: true, enabled: _toolGuardEnabled }), { headers: jsonHeaders() });
  }

  // ─── 语音音色配置（TTS voice，读写 config.yaml 的 tts.edge.voice） ───
  function _readTtsVoice(){
    const yml = _readHermesConfig();
    const tm = yml.match(/^tts:\n((?:  .*\n?)+)/m);
    if (!tm) return "";
    const em = tm[1].match(/^  edge:\n((?:    .*\n?)+)/m);
    if (!em) return "";
    const vv = em[1].match(/^    voice:\s*(.+?)\s*$/m);
    return vv ? _yamlUnquote(vv[1]) : "";
  }
  function _writeTtsVoice(voice){
    const block = "tts:\n  provider: edge\n  edge:\n    voice: " + _yamlQuote(voice);
    const yml = _setTopLevelBlock(_readHermesConfig(), "tts", block);
    return _writeHermesConfig(yml);
  }
  if (path === "/api/voice/config" && req.method === "GET") {
    return new Response(JSON.stringify({ ok: true, voice: _readTtsVoice(), voices: TTS_VOICE_OPTIONS }), { headers: jsonHeaders() });
  }
  if (path === "/api/voice/config" && req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    const v = String(body.voice || "").trim();
    if (!v) return new Response(JSON.stringify({ ok: false, error: "voice 不能为空" }), { status: 400, headers: jsonHeaders() });
    if (!_writeTtsVoice(v)) return new Response(JSON.stringify({ ok: false, error: "写入配置失败" }), { status: 500, headers: jsonHeaders() });
    log(`[voice-config] TTS 音色已更新为 ${v}`);
    return new Response(JSON.stringify({ ok: true, voice: v }), { headers: jsonHeaders() });
  }

  // ─── 工作区目录列表（新建会话选择工作区文件夹） ───
  if (path === "/api/workspace/dirs" && req.method === "GET") {
    try {
      const dirs = readdirSync(WORKSPACE_DIR, { withFileTypes: true })
        .filter(e => e.isDirectory()).map(e => e.name).sort();
      return new Response(JSON.stringify({ ok: true, dirs }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: true, dirs: [] }), { headers: jsonHeaders() });
    }
  }

  // ─── 知识库（Obsidian 风格 vault：.md + [[wikilink]]，根目录优先 OBSIDIAN_VAULT_PATH） ───
  function _kbRoot(){
    const env = _readEnvFile();
    const ov = (env["OBSIDIAN_VAULT_PATH"] || "").trim();
    const root = ov || `${DATA_DIR}/knowledge`;
    try { mkdirSync(root, { recursive: true }); } catch {}
    return root;
  }
  function _kbSafe(rel){
    if (rel === undefined || rel === null) return null;
    const root = _kbRoot();
    const abs = resolvePath(root, String(rel).replace(/^\/+/, ""));
    if (abs !== root && !abs.startsWith(root + "/")) return null;
    return abs;
  }
  if (path === "/api/kb/tree" && req.method === "GET") {
    try {
      const root = _kbRoot();
      function walk(dir, prefix){
        const out = [];
        readdirSync(dir, { withFileTypes: true })
          .filter(e => !e.name.startsWith("."))
          .sort((a, b) => (a.isDirectory() === b.isDirectory() ? a.name.localeCompare(b.name) : a.isDirectory() ? -1 : 1))
          .forEach(e => {
            const rel = prefix ? prefix + "/" + e.name : e.name;
            if (e.isDirectory()) out.push({ name: e.name, type: "dir", path: rel, children: walk(`${dir}/${e.name}`, rel) });
            else if (e.name.toLowerCase().endsWith(".md")) out.push({ name: e.name, type: "file", path: rel });
          });
        return out;
      }
      return new Response(JSON.stringify({ ok: true, root, tree: walk(root, "") }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/kb/read" && req.method === "GET") {
    try {
      const abs = _kbSafe(url.searchParams.get("path") || "");
      if (!abs) return new Response(JSON.stringify({ ok: false, error: "非法路径" }), { status: 400, headers: jsonHeaders() });
      if (!existsSync(abs) || !statSync(abs).isFile()) return new Response(JSON.stringify({ ok: false, error: "笔记不存在" }), { status: 404, headers: jsonHeaders() });
      const content = readFileSync(abs, "utf8");
      return new Response(JSON.stringify({ ok: true, path: String(url.searchParams.get("path") || ""), content }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/kb/write" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      let rel = String(body.path || "").trim();
      if (!rel) return new Response(JSON.stringify({ ok: false, error: "缺少 path" }), { status: 400, headers: jsonHeaders() });
      if (!rel.toLowerCase().endsWith(".md")) rel += ".md";
      const abs = _kbSafe(rel);
      if (!abs) return new Response(JSON.stringify({ ok: false, error: "非法路径" }), { status: 400, headers: jsonHeaders() });
      mkdirSync(dirname(abs), { recursive: true });
      writeFileSync(abs, String(body.content ?? ""), "utf8");
      return new Response(JSON.stringify({ ok: true, path: rel }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/kb/settle" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const type = body.type === "skill" ? "skill" : "note";
      const content = String(body.content || "").trim();
      if (!content) return new Response(JSON.stringify({ ok: false, error: "缺少内容" }), { status: 400, headers: jsonHeaders() });
      const root = _kbRoot();
      let rel = "", full = "";
      if (type === "skill") {
        const d = new Date(); const pad = n => String(n).padStart(2, "0");
        const dateStr = `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
        rel = `技能使用/${dateStr}.md`;
        full = `${root}/${rel}`;
        mkdirSync(dirname(full), { recursive: true });
        let cur = "";
        try { cur = existsSync(full) ? readFileSync(full, "utf8") : ""; } catch {}
        if (!cur) cur = `---\ncreated: ${new Date().toISOString()}\ntags: [技能使用]\n---\n\n# 技能使用记录 ${dateStr}\n\n`;
        if (!cur.endsWith("\n")) cur += "\n";
        writeFileSync(full, cur + content + "\n", "utf8");
      } else {
        rel = "沉淀笔记.md";
        full = `${root}/${rel}`;
        let cur = "";
        try { cur = existsSync(full) ? readFileSync(full, "utf8") : ""; } catch {}
        if (!cur) cur = `---\ntags: [沉淀]\n---\n\n# 沉淀笔记\n\n`;
        if (!cur.endsWith("\n")) cur += "\n";
        writeFileSync(full, cur + content + "\n", "utf8");
      }
      return new Response(JSON.stringify({ ok: true, path: rel }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/memory/append" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const file = body.file === "memory" ? "memories/MEMORY.md" : body.file === "notes" ? "notes.md" : null;
      const content = String(body.content || "").trim();
      if (!file || !content) return new Response(JSON.stringify({ ok: false, error: "参数错误" }), { status: 400, headers: jsonHeaders() });
      // profilefix：memory 跟随激活 profile，notes 保持全局共享
      const base = file === "notes" ? DATA_DIR : _activeProfileDir();
      if (file !== "notes" && !existsSync(`${base}/memories`)) mkdirSync(`${base}/memories`, { recursive: true });
      const fp = `${base}/${file}`;
      let cur = "";
      try { cur = existsSync(fp) ? readFileSync(fp, "utf8") : ""; } catch {}
      if (!cur.endsWith("\n")) cur += "\n";
      writeFileSync(fp, cur + content + "\n", { mode: 0o644 });
      return new Response(JSON.stringify({ ok: true, profile: _getActiveProfile() }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }
  if (path === "/api/kb/new" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const name = String(body.name || "未命名").trim();
      const dir = String(body.dir || "").trim();
      const rel = dir ? `${dir}/${name.replace(/\.md$/i, "")}.md` : `${name.replace(/\.md$/i, "")}.md`;
      const abs = _kbSafe(rel);
      if (!abs) return new Response(JSON.stringify({ ok: false, error: "非法路径" }), { status: 400, headers: jsonHeaders() });
      if (existsSync(abs)) return new Response(JSON.stringify({ ok: false, error: "笔记已存在" }), { status: 409, headers: jsonHeaders() });
      mkdirSync(dirname(abs), { recursive: true });
      const ts = new Date();
      const pad = n => String(n).padStart(2, "0");
      const front = `---\ncreated: ${ts.getFullYear()}-${pad(ts.getMonth()+1)}-${pad(ts.getDate())}T${pad(ts.getHours())}:${pad(ts.getMinutes())}:00+08:00\ntags: []\n---\n\n# ${name.replace(/\.md$/i, "")}\n\n`;
      writeFileSync(abs, front, "utf8");
      return new Response(JSON.stringify({ ok: true, path: rel, content: front }), { headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 500, headers: jsonHeaders() });
    }
  }

  // ─── Clarify：面板选择卡片回传 ────────────────────────────────────────────
  // 浏览器点选后 POST {clarify_id, response}，这里带 token 转给 gateway 的
  // /api/clarify/respond，由 clarify_gateway 唤醒被阻塞的 agent 线程。
  if (path === "/api/clarify/respond" && req.method === "POST") {
    try {
      const body = await req.json().catch(() => ({}));
      const upstream = await fetch(`${GATEWAY_API.replace(/\/v1\/?$/, "").replace(/\/$/, "")}/api/clarify/respond`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${MONITOR_TOKEN}` },
        body: JSON.stringify(body),
      });
      const text = await upstream.text();
      // 答完之后把落盘的挂起卡片清掉：否则刷新页面还会弹一张已经作废的卡。
      if (upstream.ok && body && body.clarify_id) {
        try { panelChatQueue.answered(body.clarify_id); } catch (e) { log(`[Clarify] 清理挂起卡片失败 id=${body.clarify_id}: ${e.message}`); }
      }
      return new Response(text || "{}", { status: upstream.status, headers: jsonHeaders() });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false, error: e.message }), { status: 502, headers: jsonHeaders() });
    }
  }

  // ─── Chat: WebSocket 消息队列（前端先 POST 消息入队，再建 WS 连接取流）──────
  if (path === "/api/chat/ws-send" && req.method === "POST") {
    const body = await req.json();
    const { session_id, message, system, model, provider } = body;
    noteSessionReasoning(session_id, body.model_options);
    if (panelChatQueue.list(session_id).length) return new Response(JSON.stringify({error:'此会话有持久队列，请刷新面板后继续'}),{status:409,headers:jsonHeaders()});
    const guardResp = toolGuardCheckAndRespond(message);
    if (guardResp) return guardResp;
    const messageEmpty = message == null || (Array.isArray(message) && message.length === 0) || (typeof message === "string" && message.length === 0);
    if (!session_id || messageEmpty) {
      return new Response(JSON.stringify({ error: "session_id and message required" }), { status: 400, headers: jsonHeaders() });
    }
    // system 字段携带 persona / 专家团提示，由 createChatStream 注入 system prompt，
    // 避免把人格提示拼进用户消息污染对话历史
    // model/provider 为会话级模型选择，由 resolveChatProviders 优先采用
    // 关键修复：新消息到达时作废旧的已完成/失败缓存，防止重发时把上一轮的旧回复当成本轮结果返回
    // 竞态修复（2026-08-24）：同一条消息已有流 running → 不 abort、不删缓存，新 WS 连接走 running 等待复用（防双流互相覆盖）
    const _prevCache = _streamResultCache.get(session_id);
    const _newFp = _msgFp(message);
    if (_prevCache) {
      const _sameMsg = _prevCache.status === 'running' && _prevCache.msgFp && _prevCache.msgFp === _newFp;
      if (_sameMsg) {
        log(`[WS] same message already running session=${session_id}, new connection will wait`);
      } else {
        if (_prevCache.status === 'running') {
          // ②治中断（2026-09-22）：旧流仍在跑 → 不再 abort 硬中断，返回 queued 标记，
          // 前端轮询 /api/chat/active 直到旧流完成再重发本条消息。
          log(`[WS] stream running, new message queued session=${session_id}`);
          return new Response(JSON.stringify({ ok: true, queued: true }), { headers: jsonHeaders() });
        }
        _streamResultCache.delete(session_id);
        _bumpGen(session_id);
      }
    }
    wsMessageQueue.set(session_id, { message, system: system || "", model: model || "", provider: provider || "" });
    // 30秒后自动清除（防止 WS 连接未建立导致泄漏）
    setTimeout(() => wsMessageQueue.delete(session_id), 30000);
    return new Response(JSON.stringify({ ok: true }), { headers: jsonHeaders() });
  }

  // ─── 聊天：流式 API ──────────────────────────────────────────────────────
  if (path === "/api/chat/stream" && req.method === "POST") {
    const body = await req.json();
    const { session_id, message, system, model, provider } = body;
    noteSessionReasoning(session_id, body.model_options);
    if (panelChatQueue.list(session_id).length) return new Response(JSON.stringify({error:'此会话有持久队列，请刷新面板后继续'}),{status:409,headers:jsonHeaders()});
    const guardResp = toolGuardCheckAndRespond(message);
    if (guardResp) return guardResp;
    const messageEmpty = message == null || (Array.isArray(message) && message.length === 0) || (typeof message === "string" && message.length === 0);
    if (!session_id || messageEmpty) {
      return new Response(JSON.stringify({ error: "session_id and message required" }), {
        status: 400,
        headers: jsonHeaders(),
      });
    }
    // v0.30: 会话 model 回写 + trace 埋点（供用量/轨迹页）
    try {
      const _sf = sessionFile(session_id);
      if (existsSync(_sf)) {
        const _sd = JSON.parse(readFileSync(_sf, "utf8"));
        let _chg = false;
        if (model && _sd.model !== model) { _sd.model = model; _chg = true; }
        if (provider && _sd.provider !== provider) { _sd.provider = provider; _chg = true; }
        if (_chg) saveSession(_sd);
      }
    } catch (e) {}
    try {
    appendFileSync(`${DATA_DIR}/trace.jsonl`, JSON.stringify({ ts: Date.now(), kind: "chat_request", session_id, model: model || "", provider: provider || "", message_len: (message || "").length, system_len: (system || "").length }) + String.fromCharCode(10));
    } catch (e) {}
    // v0.21.103: 新消息作废旧 done 缓存（与 ws-send 语义一致，防回放旧回复）
    // 竞态修复（2026-08-24）：同一条消息已有流 running（WS 断线后 SSE 降级重发）→ 返回等待流复用，不 abort、不双流
    try {
      const _pc = _streamResultCache.get(session_id);
      if (_pc) {
        const _fp2 = _msgFp(message);
        if (_pc.status === "running" && _pc.msgFp && _pc.msgFp === _fp2) {
          log(`[SSE] same message running session=${session_id}, waiting for existing stream`);
          return new Response(createWaitStream(session_id, _pc), {
            headers: {
              "Content-Type": "text/event-stream",
              "Cache-Control": "no-cache, no-transform",
              "Connection": "keep-alive",
              "X-Accel-Buffering": "no",
              "Access-Control-Allow-Origin": corsOrigin,
            },
          });
        }
        if (_pc.status === "done" && _pc.msgFp && _pc.msgFp === _fp2 && _pc.reply) {
          // 竞态修复（2026-08-24）：同消息已完成 → 重放缓存，不删缓存不重跑 LLM（断线后 SSE 降级重发场景）
          log(`[SSE] same message done session=${session_id}, replaying cached result (len=${_pc.reply.length})`);
          return new Response(createReplayStream(_pc), {
            headers: {
              "Content-Type": "text/event-stream",
              "Cache-Control": "no-cache, no-transform",
              "Connection": "keep-alive",
              "X-Accel-Buffering": "no",
              "Access-Control-Allow-Origin": corsOrigin,
            },
          });
        }
        if (_pc.status === "running") {
          const _prevCtrl2 = activeChatStreams.get(session_id);
          if (_prevCtrl2) { try { _prevCtrl2.abort(); } catch {} }
        }
        _streamResultCache.delete(session_id);
        _bumpGen(session_id);
      }
    } catch (e) {}
    return new Response(createChatStream(session_id, message, req.signal, system, { model: model || "", provider: provider || "" }), {
      headers: {
        "Content-Type": "text/event-stream",
        "Cache-Control": "no-cache, no-transform",
        "Connection": "keep-alive",
        "X-Accel-Buffering": "no", // 告诉中间的反向代理（常见于 App 内嵌 WebView 的前置网关）不要缓冲，立即转发每个 chunk
        "Access-Control-Allow-Origin": corsOrigin,
      },
    });
  }

  // 查询某会话是否正在生成（前端刷新/切换标签页时恢复 genBar 状态用）。
  // active=true 表示后端仍有该会话的活跃流（activeChatStreams 有该 session_id）。
  if (path === "/api/chat/active" && req.method === "GET") {
    const _u = new URL(req.url, "http://localhost");
    const _sid = _u.searchParams.get("session_id");
    return new Response(JSON.stringify({ active: !!_sid && activeChatStreams.has(_sid) }),
      { headers: jsonHeaders() });
  }

  // 显式停止生成（用户主动点击"停止"按钮时调用）——和客户端连接断开是两件事，
  // 普通网络抖动/断线不会再触发这里，只有真正点了停止才会中断模型调用。
  if (path === "/api/chat/stop" && req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    const queued=panelChatQueue.list(body.session_id).find(j=>j.status==='running');
    if(queued){panelChatQueue.cancel(queued.id);return new Response(JSON.stringify({ok:true,request_id:queued.id}),{headers:jsonHeaders()});}
    const ctrl = activeChatStreams.get(body.session_id);
    if (ctrl) {
      // 改动4（2026-09-21）：abort 前先收尾当前 _streaming 消息，别让消息停在半截
      try {
        const _s = getSession(body.session_id);
        if (_s && Array.isArray(_s.messages) && _s.messages.length) {
          const _last = _s.messages[_s.messages.length - 1];
          if (_last && _last.role === "assistant" && _last._streaming) {
            if (_last._streamId) _userStopped.add(_last._streamId);
            interruptAssistantMessage(_last, {phrase: '(已中断)' });
            saveSession(_s);
          }
        }
      } catch (e) { log(`[chat/stop] finalize failed: ${e.message}`); }
      ctrl.abort();
      activeChatStreams.delete(body.session_id);
      return new Response(JSON.stringify({ ok: true }), { headers: jsonHeaders() });
    }
    return new Response(JSON.stringify({ ok: false, error: "no active stream for this session" }), { headers: jsonHeaders() });
  }

  // ─── 聊天：图片上传 API（Profile 隔离：profile 参数非空时存入 profiles/<p>/uploads）────
  if (path === "/api/chat/upload-image" && req.method === "POST") {
    // 安全：仅在 Gateway 存活时允许上传
    const gwPid = readPidSync(PID_GATEWAY);
    if (!gwPid || !pidAliveSync(gwPid)) {
      return new Response(JSON.stringify({ error: "Gateway offline, image upload disabled" }), {
        status: 503,
        headers: jsonHeaders(),
      });
    }
    // MIME 类型白名单
    const IMAGE_TYPES = ["image/jpeg", "image/png", "image/gif", "image/webp", "image/svg+xml"];
    // 扩展名白名单（MIME → 安全扩展名映射）
    const SAFE_EXT = { "image/jpeg": "jpg", "image/png": "png", "image/gif": "gif", "image/webp": "webp", "image/svg+xml": "svg" };
    const MAX_SIZE = 16 * 1024 * 1024;
    try {
      const form = await req.formData();
      const file = form.get("file");
      if (!file || typeof file === "string") {
        return new Response(JSON.stringify({ error: "No file provided" }), { status: 400, headers: jsonHeaders() });
      }
      if (!IMAGE_TYPES.includes(file.type)) {
        return new Response(JSON.stringify({ error: "Unsupported file type" }), { status: 415, headers: jsonHeaders() });
      }
      const buf = await file.arrayBuffer();
      if (buf.byteLength > MAX_SIZE) {
        return new Response(JSON.stringify({ error: "图片超过16MB，请压缩后上传，或作为文件附加" }), { status: 413, headers: jsonHeaders() });
      }
      const ext = SAFE_EXT[file.type] || "bin";
      const filename = randomBytes(16).toString("hex") + "." + ext;
      // Profile 隔离：profile 参数非空 → 存入该 profile 的 uploads 目录
      const profile = String(form.get("profile") || "");
      if(profile&&!/^[\w-]{1,100}$/.test(profile))return new Response(JSON.stringify({error:"附件环境标识不正确"}),{status:400,headers:jsonHeaders()});
      /* 会话隔离（2026-11-16）：带 session_id 时落会话自己的 uploads
       * （data/sessions/<归类>/<会话ID>/uploads），不再往全局 uploads 里堆。
       * 规则与 panel-workspace 的 session-dir 共用 ensureSessionUploadDir()。
       * 会话不存在或落盘失败就退回全局目录 —— 上传不能因为这个挂掉。 */
      const sessId = String(form.get("session_id") || "").trim();
      if (sessId && /^[\w-]{1,120}$/.test(sessId)) {
        try {
          const sdir = await ensureSessionUploadDir(sessId);
          const full = join(sdir.abs, filename);
          writeFileSync(full, Buffer.from(buf));
          return new Response(JSON.stringify({
            url: `/api/workspace-ui/session-file/${sessId}/${filename}`,
            path: full, session_id: sessId, isolated: true
          }), { headers: jsonHeaders() });
        } catch (e) { /* 落到全局，见上 */ }
      }
      let imgDir = UPLOAD_IMG_DIR, urlBase = "/uploads/images/";
      if (profile && profile !== "default") {
        imgDir = `${DATA_DIR}/profiles/${profile}/uploads/images`;
        urlBase = `/uploads/p/${profile}/images/`;
      }
      await handlePanelFiles.upload(profile, 'images', filename, Buffer.from(buf));
      return new Response(JSON.stringify({ url: `${urlBase}${filename}`, path: `${imgDir}/${filename}`, profile: profile || "default" }), { headers: jsonHeaders() });
    } catch (err) {
      return new Response(JSON.stringify({ error: err.status ? err.message : "附件上传失败，请重试" }), { status: err.status || 500, headers: jsonHeaders() });
    }
  }

  // ─── 聊天：通用文件上传 API（非图片附件，落盘到 Hermes home 下，让 Hermes
  //      自己用文件工具读取，而不是把全文本塞进 prompt 撑爆/卡死浏览器）──────────
  //      Profile 隔离：profile 参数非空时存入 profiles/<p>/uploads，保持多 Agent 完全隔离
  if (path === "/api/chat/upload-file" && req.method === "POST") {
    const gwPid = readPidSync(PID_GATEWAY);
    if (!gwPid || !pidAliveSync(gwPid)) {
      return new Response(JSON.stringify({ error: "Gateway offline, file upload disabled" }), {
        status: 503,
        headers: jsonHeaders(),
      });
    }
    const MAX_FILE_SIZE = 64 * 1024 * 1024;
    try {
      const form = await req.formData();
      const file = form.get("file");
      if (!file || typeof file === "string") {
        return new Response(JSON.stringify({ error: "No file provided" }), { status: 400, headers: jsonHeaders() });
      }
      const buf = await file.arrayBuffer();
      if (buf.byteLength > MAX_FILE_SIZE) {
        return new Response(JSON.stringify({ error: "文件超过64MB，请放入工作区后附加到对话" }), { status: 413, headers: jsonHeaders() });
      }
      // 原始文件名做安全清洗，保留可读性（方便 Hermes/用户辨认），但去掉路径分隔符等危险字符
      const origName = (file.name || "file").toString();
      const safeBase = safeFilename(origName);
      const filename = `${Date.now()}_${randomBytes(6).toString("hex")}_${safeBase}`;
      const profile = String(form.get("profile") || "");
      if(profile&&!/^[\w-]{1,100}$/.test(profile))return new Response(JSON.stringify({error:"附件环境标识不正确"}),{status:400,headers:jsonHeaders()});
      /* 会话隔离（2026-11-16）：同 upload-image，带 session_id 就落会话目录。
       * 文件名保留了原始可读名，URL 里必须 encodeURIComponent，否则中文/空格取不回来。 */
      const sessId = String(form.get("session_id") || "").trim();
      if (sessId && /^[\w-]{1,120}$/.test(sessId)) {
        try {
          const sdir = await ensureSessionUploadDir(sessId);
          const full = join(sdir.abs, filename);
          writeFileSync(full, Buffer.from(buf));
          return new Response(JSON.stringify({
            url: `/api/workspace-ui/session-file/${sessId}/${encodeURIComponent(filename)}`,
            path: full, session_id: sessId, isolated: true
          }), { headers: jsonHeaders() });
        } catch (e) { /* 落到全局，见上 */ }
      }
      let fileDir = UPLOAD_FILE_DIR, urlBase = "/uploads/files/";
      if (profile && profile !== "default") {
        fileDir = `${DATA_DIR}/profiles/${profile}/uploads/files`;
        urlBase = `/uploads/p/${profile}/files/`;
      }
      const fullPath = `${fileDir}/${filename}`;
      await handlePanelFiles.upload(profile, 'files', filename, Buffer.from(buf));
      return new Response(JSON.stringify({
        url: `${urlBase}${encodeURIComponent(filename)}`,
        path: fullPath,
        name: origName,
        size: buf.byteLength,
        profile: profile || "default",
      }), { headers: jsonHeaders() });
    } catch (err) {
      return new Response(JSON.stringify({ error: err.status ? err.message : "附件上传失败，请重试" }), { status: err.status || 500, headers: jsonHeaders() });
    }
  }

  // 门户与直接访问统一：无 BASE_PATH 前缀的 /proxy/dashboard/* 请求 302 补前缀。
  // 官方 dashboard（web 构建）用 <BrowserRouter basename={__HERMES_BASE_PATH__}>，
  // basename 必须与浏览器 URL 前缀一致，否则 React Router 拒绝渲染（黑屏）。
  if (BASE_PATH && BASE_PATH !== "/" && path.startsWith("/proxy/dashboard") && !url.pathname.startsWith(BASE_PATH + "/")) {
    return new Response(null, { status: 302, headers: { Location: BASE_PATH + url.pathname + url.search } });
  }
  if (path.startsWith("/proxy/dashboard")) {
    const subPath = path.replace(/^\/proxy\/dashboard/, "") || "/";
    if (subPath.includes("..")) return new Response("Forbidden", { status: 403 });

    // 官方 dashboard 不适配页面的拦截已全部移除：chat 与 system 页均放行渲染
    // （system 页 /api/system 在 0.20 不存在由官方页面自行处理，不再显示拦截页）。

    // Dashboard 未运行时直接返回 503，不进入 proxy 避免打错误日志
    if (!readPid(PID_DASHBOARD)) {
      return new Response(JSON.stringify({ error: "Dashboard is not running" }), {
        status: 503,
        headers: { "Content-Type": "application/json" },
      });
    }
    return proxyDashboard(req);
  }

  // 静态 UI — 根路径返回 index.html
  if (path === "/") {
    return serveFile(`${STATIC_DIR}/index.html`, "text/html; charset=utf-8", { req, cacheable: false });
  }

  // ─── PWA 根目录文件：manifest / favicon.ico 必须免鉴权（2026-11-18）───
  // iOS「添加到主屏幕」时由系统进程取 manifest，不带面板 token。这一步被 401
  // 拦掉，PWA 就退回 Safari 模式 —— 顶部那条半透明地址栏正是用户说的「磨砂玻璃」，
  // 地址栏压下来还会让人觉得「页面滚到了下方」。
  // 只按确切文件名放行，不做前缀匹配，避免扩大暴露面。
  if (path === "/manifest.webmanifest" || path === "/favicon.ico" || path === "/sw.js") {
    const fp = `${STATIC_DIR}${path}`;
    const ct = path.endsWith(".webmanifest") ? "application/manifest+json"
             : path === "/sw.js" ? "application/javascript"
             : "image/x-icon";
    return serveFile(fp, ct, { req, cacheable: false });
  }

  // /images/、/css/、/js/、/scripts/ 等路径下的静态资源
  if (path.startsWith("/images/") || path.startsWith("/css/") || path.startsWith("/js/") || path.startsWith("/scripts/")) {
    const relPath = path.slice(1);
    if (relPath.includes("..")) return new Response("Forbidden", { status: 403 });
    const fp  = `${STATIC_DIR}/${relPath}`;
    const ext = fp.split(".").pop()?.toLowerCase();
    const ct  = ext === "js"  ? "application/javascript"
              : ext === "css" ? "text/css"
              : ext === "png" ? "image/png"
              : ext === "svg" ? "image/svg+xml"
              : "text/plain";
    // 2026-11-11：静态资源曾经是 public, max-age=3600。配上 index.html 里手写的固定 ?v=，
    // 就是「改了文件、URL 没变、浏览器一小时不回头」，用户看到的是几小时前的样式。
    // 现在 ?v= 由 deploy ui 按内容 md5 自动生成，且这里改成 no-cache（走 ETag 304）：
    // 内容没变只有一次 304，内容变了立刻生效。不要再改回 max-age。
    return serveFile(fp, ct, { req, cacheable: false });
  }

  // SPA 直达：未知路径的浏览器导航请求 302 到「根路径 + hash」（如 /sessions → /#/sessions）。
  // 子路径下 index.html 的相对资源会解析错位（/sessions/js/... 404）导致黑屏，
  // 因此必须回根路径加载，页面目标用 hash 传递（前端读 location.hash 切页）。
  // 仅对浏览器导航请求（GET + Accept: text/html）生效，API/静态资源请求保持 404。
  {
    const _acc = String(req.headers.get("accept") || "");
    if (req.method === "GET" && _acc.includes("text/html") && !path.startsWith("/api/")) {
      const _root = (BASE_PATH ? BASE_PATH + "/" : "/");
      return new Response(null, { status: 302, headers: { Location: _root + "#" + path } });
    }
  }

  return new Response("Not Found", { status: 404 });
}

// ─── SIGTERM / SIGINT：优雅关闭 ─────────────────────────────────────
let shuttingDown = false;
async function gracefulShutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  log("Received SIGTERM, shutting down gateway + dashboard ...");
  await Promise.race([Promise.all([panelRoomRunner.stop(),panelChatQueue.stop(),panelLibraryReviews.stop()]),new Promise(resolve=>setTimeout(resolve,5000))]);
  await stopPid(PID_GATEWAY);
  await stopPid(PID_DASHBOARD);
  log("Shutdown complete");
  process.exit(0);
}
process.on("SIGTERM", () => gracefulShutdown());
process.on("SIGINT",  () => gracefulShutdown());

// ─── 崩溃保护：记录错误而非退出 ─────────────────────────
process.on("uncaughtException", (err) => {
  log(`[FATAL] uncaughtException: ${err?.message || err}\n${err?.stack || ""}`);
});
process.on("unhandledRejection", (err) => {
  log(`[FATAL] unhandledRejection: ${err?.message || err}\n${err?.stack || ""}`);
});

// ─── HTTP/WS 服务（unix socket），支持 socket 文件丢失后自愈重建 ───
import http from "http";

let server = null;
let wss = null;

// 将 Web Response 写回 Node ServerResponse
async function writeWebResponse(res, response) {
  res.statusCode = response.status;
  response.headers.forEach((value, key) => { if(!key.toLowerCase().startsWith('access-control-'))res.setHeader(key, value); });
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','same-origin');
  // User-authored HTML/SVG previews must not execute with panel credentials.
  const type=String(response.headers.get('content-type')||'');
  const requestPath=panelPath('http://localhost'+(res.req?.url||'/'),BASE_PATH);
  if ((/text\/html|image\/svg\+xml/.test(type)) && /^(?:\/api\/(?:preview|download)|\/(?:workspace|uploads|data|tmp)\/)/.test(requestPath)) res.setHeader('Content-Security-Policy',"sandbox; default-src 'none'; img-src data: blob:; style-src 'unsafe-inline'");
  if (response.body) {
    const reader = response.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      res.write(Buffer.from(value));
    }
  }
  res.end();
}

function startServer() {
  // ─── 热更新回滚检测：若 .hot-restart 标记超过 60 秒仍存在，说明上次热更后启动失败（crash loop），回滚 ───
  try {
    const hotFlag = `${VAR_DIR}/.hot-restart`;
    if (existsSync(hotFlag)) {
      const ts = parseInt(readFileSync(hotFlag, "utf8"), 10) || 0;
      if (Date.now() - ts > 60000) {
        // crash loop 检测：回滚所有 .hot-bak 文件
        log("[HotPatch] crash loop detected, rolling back...");
        try { execSync(`find ${APP_DIR} -name "*.hot-bak" -exec sh -c 'mv "$1" "\${1%.hot-bak}"' _ {} \;`, { timeout: 10000 }); } catch {}
        // 回滚 manifest
        const bakManifest = MANIFEST_FILE + ".hot-bak";
        if (existsSync(bakManifest)) { try { copyFileSync(bakManifest, MANIFEST_FILE); } catch {} }
      }
      // 无论是否回滚，清理标记和备份文件
      try { unlinkSync(hotFlag); } catch {}
      // 启动成功，清理 .hot-bak 文件
      try { execSync(`find ${APP_DIR} -name "*.hot-bak" -delete`, { timeout: 5000 }); } catch {}
    }
  } catch (e) { log("[HotPatch] startup check error: " + e.message); }

  // 启动前清理可能残留的旧 socket，避免 EADDRINUSE
  try { unlinkSync(SOCKET_PATH); } catch {}

  server = http.createServer(async (req, res) => {
    try {
      const response = await dispatchPanel(req,res,{auth:panelAuth,basePath:BASE_PATH,trustedUnix:true,
        maintenance:handleMaintenance,restart:handleRestartIngress,channels:handlePanelChannelIngress,custom:handleCustomRoute,main:handleFetch});
      await writeWebResponse(res, response);
    } catch (err) {
      log(`Server error: ${err?.message || err}\n${err?.stack || ""}`);
      if (!res.headersSent) {
        res.writeHead(err.status || 500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ error: err.status ? err.message : "请求处理失败，请重试" }));
      } else { try { res.end(); } catch {} }
    }
  });

  wss = new WebSocketServer({ noServer: true });

  const _handleUpgrade = (req, socket, head, trustedUnix=false) => {
    const authRequest=authorizePanelUpgrade(req,socket,{auth:panelAuth,trustedUnix});
    if(!authRequest)return;
    const url = new URL(req.url, "http://localhost");
    let wsPath = url.pathname;
    if (BASE_PATH && BASE_PATH !== "/") {
      if (wsPath.startsWith(BASE_PATH + "/")) wsPath = wsPath.slice(BASE_PATH.length);
      else if (wsPath === BASE_PATH) wsPath = "/";
    }
    // 聊天 WS：/api/chat/ws?session_id=xxx&token=xxx
    if (wsPath === "/api/chat/ws") {
      const token = url.searchParams.get("token") || "";
      if (!checkToken(authRequest)) {
        socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n"); socket.destroy(); return;
      }
      const sessionId = url.searchParams.get("session_id") || "";
      const _q = wsMessageQueue.get(sessionId);
      if (!sessionId) {
        socket.write("HTTP/1.1 400 Bad Request\r\n\r\n"); socket.destroy(); return;
      }
      // 允许无队列消息的连接（WS 断线重连场景：前端重连不会重新 POST，
      // 此时 message=null，runChatWS 会从流缓存中继续取结果）
      if (_q) wsMessageQueue.delete(sessionId);
      wss.handleUpgrade(req, socket, head, (ws) => {
        ws.data = { sessionId, message: _q ? _q.message : null, system: _q ? (_q.system || "") : "", model: _q ? (_q.model || "") : "", provider: _q ? (_q.provider || "") : "", stopCtrl: null };
        attachWsHandlers(ws);
      });
      return;
    }
    // Dashboard WebSocket 反代：/proxy/dashboard/* 以及 /proxy/hermes-agent/*
    // 0.19.0 使用 /api/ws|events|pty，但若 hermes 回退到新版可能出现 /stream 等路径；
    // 同时 fnOS 反向代理可能保留 /proxy/hermes-agent 前缀。这里泛化匹配，避免
    // 因硬编码路径导致 WebSocket 升级被直接 destroy。
    const dashboardProxyPrefixes = ["/proxy/dashboard", "/proxy/hermes-agent"];
    for (const prefix of dashboardProxyPrefixes) {
      if (wsPath.startsWith(prefix + "/")) {
        if (!readPid(PID_DASHBOARD)) {
          socket.write("HTTP/1.1 503 Service Unavailable\r\n\r\n"); socket.destroy(); return;
        }
        const subPath = wsPath.slice(prefix.length);
        // Dashboard WS 认证要求 ?token=<session_token> 查询参数（浏览器 WS 无法设 header）
        const upstreamQuery = new URLSearchParams(url.search);upstreamQuery.set('token',DASHBOARD_SESSION_TOKEN);
        const targetUrl = `ws://${DASHBOARD_BIND}:${DASHBOARD_PORT}${subPath}?${upstreamQuery}`;
        log(`[WS-UPGRADE] ${wsPath} -> dashboard`);
        wss.handleUpgrade(req, socket, head, (ws) => {
          ws.data = { type: "dashboard-proxy", targetUrl };
          attachWsHandlers(ws);
        });
        return;
      }
    }
    // 终端 WebSocket：/api/terminal/ws?token=xxx&cwd=xxx
    if (wsPath === "/api/terminal/ws") {
      const token = url.searchParams.get("token") || "";
      if (!checkToken(authRequest)) {
        socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n"); socket.destroy(); return;
      }
      let cwd = WORKSPACE_DIR;
      const requestedCwd = url.searchParams.get("cwd");
      if(requestedCwd){try{const ref=fileReference(requestedCwd+"/file-placeholder",{roots:panelFileRoots,data:DATA_DIR,varDir:VAR_DIR});cwd=dirname(ref.absolute);}catch{socket.write("HTTP/1.1 403 Forbidden\r\n\r\n");socket.destroy();return;}}
      wss.handleUpgrade(req, socket, head, (ws) => {
        log(`[TERMINAL] new session cwd=${cwd}`);
        // 真实 PTY：由 pty_bridge.py（pty.openpty + setsid + TIOCSCTTY）提供控制终端，
        // 修复 pipe spawn 下 bash -i 报 “cannot set terminal process group / no job control”，
        // Ctrl+C、前后台任务、vim 等全屏程序均可正常工作。
        const pty = spawn(`${VENV_BIN}/${PY_BIN}`, [
          `${APP_DIR}/server/pty_bridge.py`,
          "--shell", "/bin/bash",
          "--cwd", existsSync(cwd) ? cwd : WORKSPACE_DIR,
        ], {
          env: { ...process.env, TERM: "xterm-256color", LANG: "C.UTF-8" },
          stdio: ["pipe", "pipe", "inherit"], // stderr 为 pty_bridge 日志，直接进 monitor 日志
        });
        // PTY 输出可能含二进制（颜色/全屏程序），以二进制帧下发，前端做流式 UTF-8 解码
        pty.stdout.on("data", (d) => { try { ws.send(d); } catch {} });
        pty.on("close", (code) => { try { ws.send(JSON.stringify({ type: "exit", code })); ws.close(); } catch {} });
        pty.on("error", (err) => { try { ws.send(JSON.stringify({ type: "output", data: `\r\n[ERROR] ${err.message}\r\n` })); } catch {} });
        ws.on("message", (msg) => {
          try {
            const data = JSON.parse(msg.toString());
            if (data.type === "input" && pty.stdin.writable) pty.stdin.write(data.data);
            if (data.type === "resize" && pty.stdin.writable) {
              // 以控制帧透传窗口尺寸 → pty_bridge 调 TIOCSWINSZ + SIGWINCH
              const rows = Math.max(2, Math.min(parseInt(data.rows, 10) || 24, 32767));
              const cols = Math.max(2, Math.min(parseInt(data.cols, 10) || 80, 32767));
              pty.stdin.write(`\x1b[HERMES1\x1bRESIZE\x1b${rows};${cols}\x1b[HERMES2`);
            }
          } catch {
            // 纯文本输入（向后兼容旧前端）
            if (pty.stdin.writable) pty.stdin.write(msg.toString());
          }
        });
        ws.on("close", () => { try { pty.kill("SIGHUP"); } catch {} });
      });
      return;
    }
    // 其他升级请求直接拒绝
    socket.destroy();
  };
  server.on("upgrade", (req,socket,head)=>_handleUpgrade(req,socket,head,true));

  if (UNIX_MODE) {
    server.on("error", (err) => {
      log(`Server error: ${err?.message || err}`);
      if (err?.code === "EADDRINUSE") {
        log(`[FATAL] Unix socket ${SOCKET_PATH} 已被占用，可能存在另一个 monitor 实例；退出以避免多实例冲突`);
        process.exit(1);
      }
    });

    server.listen({ path: SOCKET_PATH }, () => {
      try { chmodSync(SOCKET_PATH, 0o600); } catch {}
      log(`Monitor ready — unix:${SOCKET_PATH} (base=${BASE_PATH || "/"}) | dashboard proxied at /proxy/dashboard/`);
      try { pushHub.start(); } catch (e) { log(`[push] 启动失败：${e?.message || e}`); }
      // Keep user configuration unchanged at startup; invalid YAML is surfaced.
      // 若已存在模型配置，自动启动 Gateway/Dashboard（覆盖安装/升级后无需手动点启动）
      setTimeout(() => maybeAutoStartServices(), 2500);
    });
  } else {
    // 纯 TCP 模式（跨平台 / 独立部署）：不建 unix socket，UI 走 UI_PORT
    log(`Monitor ready — TCP only (base=${BASE_PATH || "/"}) | dashboard proxied at /proxy/dashboard/`);
    setTimeout(() => maybeAutoStartServices(), 2500);
  }

  // ─── 独立 TCP 端口：浏览器直接访问（脱离飞牛框架，自定义 favicon/标签） ───
  const tcpServer = http.createServer(async (req, res) => {
    try {
      const response = await dispatchPanel(req,res,{auth:panelAuth,basePath:BASE_PATH,trustedUnix:false,
        maintenance:handleMaintenance,restart:handleRestartIngress,channels:handlePanelChannelIngress,custom:handleCustomRoute,main:handleFetch});
      await writeWebResponse(res, response);
    } catch (err) {
      log(`TCP server error: ${err?.message || err}`);
      if (!res.headersSent) { res.writeHead(err.status || 500, { "Content-Type": "application/json" }); res.end(JSON.stringify({ error: err.status ? err.message : "请求处理失败，请重试" })); }
      else { try { res.end(); } catch {} }
    }
  });
  tcpServer.on("upgrade", (req,socket,head)=>_handleUpgrade(req,socket,head,false));
  tcpServer.on("error", (err) => {
    if (err?.code === "EADDRINUSE") log(`[WARN] UI TCP port ${UI_PORT} already in use, standalone access disabled`);
    else log(`TCP server error: ${err?.message || err}`);
  });
  tcpServer.listen(UI_PORT, UI_BIND, () => {
    log(`Standalone UI available at http://${UI_BIND}:${UI_PORT}/`);
  });

  return server;
}

// Read the actual gateway configuration before normal service startup.
async function maybeAutoStartServices() {
  try {
    const configured=await panelModels.execute({action:'read'});
    if(!configured.ok||!configured.hermes_configured){log('Auto-start skipped: '+(configured.error||'default model not configured'));return;}
    if (readPid(PID_GATEWAY) || readPid(PID_DASHBOARD)) {
      log("Auto-start skipped: gateway/dashboard already running");
      return;
    }
    log("Auto-starting gateway & dashboard (provider config detected) ...");
    spawnHermes("gateway",   PID_GATEWAY,   ["gateway", "run", "--replace"]);
    spawnHermes("dashboard", PID_DASHBOARD, ["dashboard", "--host", DASHBOARD_BIND, "--port", String(DASHBOARD_PORT), "--no-open", "--insecure"]);
  } catch (err) {
    log(`Auto-start error: ${err?.message || err}`);
  }
}

// Duplicate Monitor detection runs before initialization; no takeover here.
// 启动前清理可能残留的旧 socket，避免 EADDRINUSE 导致启动失败
try { unlinkSync(SOCKET_PATH); } catch {}
// 自同步 app.pid：防止 root 手动运行 cmd/main 留下 root:root 的陈旧 PID 文件，
// 导致 fnOS 以 hermes-agent 用户调用时 chown/printf 失败 → 死 PID → 健康检查循环拉起（2026-08-14）
// 升级 0.21.149 后重打（2026-08-24）
try {
  const _pidFile = join(VAR_DIR, "app.pid");
  try { unlinkSync(_pidFile); } catch {}
  writeFileSync(_pidFile, String(process.pid));
  log(`[单实例] app.pid 已同步: ${process.pid}`);
} catch (e) { log(`[单实例] app.pid 同步失败: ${e.message}`); }

startServer();
setInterval(()=>{if(!shuttingDown)getStatus().catch(()=>{});},5000);
try { panelChatQueue.load().start(); } catch(e) { panelChatQueue.recordFault(e); }
try { panelRoomRunner.start(); } catch(e) { panelRoomRunner.fail(e); }

// ─── 自愈：socket 文件被外部清理（如 fnOS 重置 @appcenter 安装目录）后自动重建 ───
// 现象：monitor.js 进程存活，但 socket 文件被删除，fnOS 代理连不上、UI 转圈。
// 监测到文件丢失即重建监听，无需依赖 fnOS 重启进程。
// 纯 TCP 模式没有 socket 文件，这套自愈逻辑不适用（否则每 10 秒误判一次、反复重建监听）
const _sockDir = UNIX_MODE ? SOCKET_PATH.replace(/\/[^/]+$/, '') : '';
if (UNIX_MODE) setInterval(() => {
  try {
    if (!existsSync(SOCKET_PATH)) {
      log(`[self-heal] 检测到 socket 文件丢失 (${SOCKET_PATH})，正在重建监听…`);
      try { if (server) server.close(); } catch (e) {}
      try { if (wss) wss.close(); } catch (e) {}
      try { unlinkSync(SOCKET_PATH); } catch (e) {}
      try { mkdirSync(_sockDir, { recursive: true }); } catch (e) {}
      startServer();
    }
  } catch (e) {
    log(`[self-heal] 重建失败: ${e?.message || e}`);
  }
}, 10000);

// Report conflicts; never kill or take over a foreign application.
let reportedPortConflicts='';
setInterval(()=>{const conflicts=foreignHermesPortConflicts(),key=JSON.stringify(conflicts);if(key!==reportedPortConflicts){reportedPortConflicts=key;if(conflicts.length)log('[port-guard] 应用端口存在冲突：'+conflicts.map(c=>c.port).join('、')+'；其他应用保持运行');}},60000);

// 通道级模型覆盖同步（60s 一次）：把配置了模型/系统提示的平台的覆盖同步到网关路由索引中
// 新增的 chat_id（新微信/新会话出现后也能自动应用通道模型，无需重新保存配置）
setInterval(() => {
  try { _syncChannelOverrides(); } catch (e) {}
}, 60000);

// ─── 定时任务 Webhook 出站投递（monitor 侧实现，hermes 不支持出站 webhook）───
function _readCronWebhooks() {
  return panelCronHooks.readAll();
}
// 模块级轻量活跃 profile 解析（webhook 轮询用；优先 hermes profile list ◆ 标记，
// 其次 .active_profile 文件——与 handleFetch 内 _getActiveProfile 保持同一判定，
// 避免「面板读 profile store、webhook 轮询读 .active_profile」不一致导致任务两套。
// 注：_getActiveProfile 定义在 handleFetch 闭包内，模块级不可用，故此处独立解析。
function _cronProfileName() {
  if (_activeProfileCache) return _activeProfileCache;
  try {
    const r = spawnSync(HERMES_BIN, ["profile", "list"], { stdout: "pipe", stderr: "pipe", timeout: 8000, env: { ...process.env, HERMES_HOME: DATA_DIR } });
    const out = (r.stdout || "").toString();
    if (r.status === 0 && out.trim()) {
      const line = out.split("\n").find(function(l){ return l.includes("◆"); });
      if (line) {
        const name = line.replace(/^[\s◆]+/, "").trim().split(/\s+/)[0];
        if (name) { _activeProfileCache = name; return name; }
      }
    }
  } catch {}
  try {
    const raw = readFileSync(`${DATA_DIR}/.active_profile`, "utf8");
    const name = raw.trim();
    if (name) { _activeProfileCache = name; return name; }
  } catch {}
  return "default";
}
// 模块级 jobs.json 定位（profile 隔离路径优先，回退全局），供 webhook 轮询使用
function _cronProfileJobsFile() {
  try {
    const prof = _cronProfileName();
    const p = `${DATA_DIR}/profiles/${prof}/cron/jobs.json`;
    if (existsSync(p)) return p;
  } catch {}
  return `${DATA_DIR}/cron/jobs.json`;
}
// 读取任务最近一次输出（0.20.0 输出目录按 profile 隔离 profiles/<p>/cron/output/<job_id>/*.md，
// 兼容全局 cron/output/<job_id>/*.md 与旧版 cron/<id>/outputs/*.md）
function _cronLatestOutput(jobId) {
  let prof = "default";
  try { prof = _cronProfileName() || "default"; } catch {}
  const candidates = [
    `${DATA_DIR}/profiles/${prof}/cron/output/${jobId}`,
    `${DATA_DIR}/profiles/${prof}/cron/${jobId}/outputs`,
    `${DATA_DIR}/cron/output/${jobId}`,
    `${DATA_DIR}/cron/${jobId}/outputs`,
  ];
  for (const dir of candidates) {
    try {
      if (!existsSync(dir)) continue;
      const files = readdirSync(dir).filter(f => f.endsWith(".md")).sort();
      if (!files.length) continue;
      return readFileSync(`${dir}/${files[files.length - 1]}`, "utf8").slice(0, 8000);
    } catch {}
  }
  return "";
}
// POST 到 webhook：企微机器人/钉钉机器人均为 {"msgtype":"text","text":{"content":...}}，
// 失败时尝试通用 JSON 原样 POST（部分自定义 webhook 期望原始文本/JSON）
async function _postWebhookText(url, text) {
  const payload = { msgtype: "text", text: { content: text } };
  let r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(15000),
  });
  if (!r.ok) throw new Error(`HTTP ${r.status}`);
  let t = "";
  try { t = await r.text(); } catch {}
  // 企微机器人 {"errcode":0,"errmsg":"ok"}；钉钉 {"errcode":0}；其它 webhook 返回任意 2xx 均视为成功
  try {
    const j = JSON.parse(t || "{}");
    if (j.errcode && Number(j.errcode) !== 0) throw new Error(`errcode ${j.errcode}: ${j.errmsg || t}`);
  } catch (e) {
    if (e instanceof SyntaxError) return t; // 非 JSON 响应（如纯文本 ok），2xx 即成功
    throw e;
  }
  return t;
}
// 轮询一次：对配置了 webhook 的任务，检测 last_run_at 变化 → 组装消息 → POST
let cronWebhookRunning = false;
async function _cronWebhookTick() {
  if (cronWebhookRunning) return;
  cronWebhookRunning = true;
  try {
  const hooks = _readCronWebhooks();
  const ids = Object.keys(hooks).filter(id => Array.isArray(hooks[id]) && hooks[id].length);
  if (!ids.length) return;
  let jobs = [];
  try {
    const raw = readFileSync(_cronProfileJobsFile(), "utf8");
    const data = JSON.parse(raw);
    jobs = Array.isArray(data) ? data : (data.jobs || Object.values(data));
  } catch {}
  const byId = {};
  jobs.forEach(j => { const id = j.id || j.job_id || j.name || ""; if (id) byId[id] = j; });
  for (const id of ids) {
    const list = hooks[id];
    const job = byId[id];
    if (!job) continue; // 任务已删除
    const runAt = job.last_run_at || job.lastRunAt || "";
    const status = job.last_status || "ok";
    for (const h of list) {
      if (!h || !h.url) continue;
      if (!runAt || h.last_run_at === runAt) continue; // 无新执行
      const output = _cronLatestOutput(id);
      const text = webhookText(h.message, output);
      let delivery;
      try {
        await _postWebhookText(h.url, text);
        delivery = {last_run_at: runAt, last_status: 'ok', last_error: ''};
        log(`[cron-webhook] 任务 ${id} 投递成功 (${runAt})`);
      } catch (e) {
        delivery = {last_status: 'error', last_error: String(e?.message || e)};
        log(`[cron-webhook] 任务 ${id} 投递失败`);
      }
      panelCronHooks.record(id, h, delivery);
    }
  }
  } finally { cronWebhookRunning = false; }
}
// 轮询周期 20s：仅在存在 webhook 配置时才真正读 jobs.json，开销可忽略
setInterval(() => { _cronWebhookTick().catch(e => log(`[cron-webhook] tick 异常: ${e?.message || e}`)); }, 20000);

// ─── 知识库笔记扫描（2026-11-11 新增：学习轨迹图的「笔记边」数据源）───
// 缓存挂在函数属性上，避开顶层 const 的 TDZ：本函数在路由里被调用，而路由代码
// 位置在文件中部，顶层 const 声明在末尾会处于暂时性死区。
function _scanKnowledgeNotes() {
  const now = Date.now();
  const cache = _scanKnowledgeNotes._cache;
  if (cache && now - cache.at < 300000) return cache.notes;
  const root = `${DATA_DIR}/knowledge`;
  const out = [];
  const walk = (dir, depth) => {
    if (depth > 6 || out.length >= 1200) return;
    let entries = [];
    try { entries = readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const ent of entries) {
      const full = `${dir}/${ent.name}`;
      if (ent.isDirectory()) { if (!ent.name.startsWith(".")) walk(full, depth + 1); continue; }
      if (!/\.md$/i.test(ent.name)) continue;
      let text = "";
      try { text = readFileSync(full, "utf8").slice(0, 8000); } catch { continue; }
      out.push({ path: full.slice(root.length + 1), title: ent.name.replace(/\.md$/i, ""), text });
    }
  };
  walk(root, 0);
  _scanKnowledgeNotes._cache = { at: now, notes: out };
  return out;
}
